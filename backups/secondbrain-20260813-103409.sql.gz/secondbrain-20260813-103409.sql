--
-- PostgreSQL database dump
--

\restrict fKjJGxwat28OynfjAtJYYcEgCbcCWDLtF3OHKXtw03IiemJ5FGRa5fRLaifyalU

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AchievementKind; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."AchievementKind" AS ENUM (
    'streak_days',
    'cards_reviewed',
    'concepts_mastered',
    'lessons_completed',
    'exercises_correct'
);


ALTER TYPE public."AchievementKind" OWNER TO secondbrain;

--
-- Name: CardState; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."CardState" AS ENUM (
    'new',
    'learning',
    'review',
    'relearning'
);


ALTER TYPE public."CardState" OWNER TO secondbrain;

--
-- Name: ConceptRelation; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."ConceptRelation" AS ENUM (
    'prerequisite',
    'related'
);


ALTER TYPE public."ConceptRelation" OWNER TO secondbrain;

--
-- Name: DocumentSource; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."DocumentSource" AS ENUM (
    'text',
    'file',
    'url'
);


ALTER TYPE public."DocumentSource" OWNER TO secondbrain;

--
-- Name: DocumentStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."DocumentStatus" AS ENUM (
    'pending',
    'processing',
    'ready',
    'failed'
);


ALTER TYPE public."DocumentStatus" OWNER TO secondbrain;

--
-- Name: IncidentSeverity; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."IncidentSeverity" AS ENUM (
    'low',
    'medium',
    'high',
    'critical'
);


ALTER TYPE public."IncidentSeverity" OWNER TO secondbrain;

--
-- Name: IncidentStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."IncidentStatus" AS ENUM (
    'open',
    'investigating',
    'resolved'
);


ALTER TYPE public."IncidentStatus" OWNER TO secondbrain;

--
-- Name: InitiativeStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."InitiativeStatus" AS ENUM (
    'active',
    'acted',
    'dismissed'
);


ALTER TYPE public."InitiativeStatus" OWNER TO secondbrain;

--
-- Name: LanguageMode; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."LanguageMode" AS ENUM (
    'beginner',
    'intermediate',
    'advanced',
    'academic',
    'professional',
    'exam_prep',
    'immersion'
);


ALTER TYPE public."LanguageMode" OWNER TO secondbrain;

--
-- Name: OrgGroupKind; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."OrgGroupKind" AS ENUM (
    'class',
    'group'
);


ALTER TYPE public."OrgGroupKind" OWNER TO secondbrain;

--
-- Name: OrgRole; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."OrgRole" AS ENUM (
    'admin',
    'teacher',
    'student'
);


ALTER TYPE public."OrgRole" OWNER TO secondbrain;

--
-- Name: OrganizationType; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."OrganizationType" AS ENUM (
    'school',
    'university',
    'training_center',
    'enterprise'
);


ALTER TYPE public."OrganizationType" OWNER TO secondbrain;

--
-- Name: PaymentStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."PaymentStatus" AS ENUM (
    'pending',
    'succeeded',
    'failed',
    'refunded'
);


ALTER TYPE public."PaymentStatus" OWNER TO secondbrain;

--
-- Name: PlanItemKind; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."PlanItemKind" AS ENUM (
    'review',
    'lesson',
    'exercises',
    'quick_revision',
    'vocabulary'
);


ALTER TYPE public."PlanItemKind" OWNER TO secondbrain;

--
-- Name: PlanItemStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."PlanItemStatus" AS ENUM (
    'pending',
    'done',
    'skipped'
);


ALTER TYPE public."PlanItemStatus" OWNER TO secondbrain;

--
-- Name: PlanSlot; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."PlanSlot" AS ENUM (
    'morning',
    'afternoon',
    'evening',
    'night'
);


ALTER TYPE public."PlanSlot" OWNER TO secondbrain;

--
-- Name: RecommendationStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."RecommendationStatus" AS ENUM (
    'suggested',
    'accepted',
    'dismissed'
);


ALTER TYPE public."RecommendationStatus" OWNER TO secondbrain;

--
-- Name: ReportStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."ReportStatus" AS ENUM (
    'open',
    'reviewed',
    'dismissed'
);


ALTER TYPE public."ReportStatus" OWNER TO secondbrain;

--
-- Name: SubscriptionStatus; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."SubscriptionStatus" AS ENUM (
    'active',
    'trialing',
    'past_due',
    'canceled',
    'incomplete'
);


ALTER TYPE public."SubscriptionStatus" OWNER TO secondbrain;

--
-- Name: TutorRole; Type: TYPE; Schema: public; Owner: secondbrain
--

CREATE TYPE public."TutorRole" AS ENUM (
    'user',
    'assistant'
);


ALTER TYPE public."TutorRole" OWNER TO secondbrain;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


ALTER TABLE public._prisma_migrations OWNER TO secondbrain;

--
-- Name: achievements; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.achievements (
    id text NOT NULL,
    "userId" text NOT NULL,
    kind public."AchievementKind" NOT NULL,
    threshold integer NOT NULL,
    "achievedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.achievements OWNER TO secondbrain;

--
-- Name: ai_initiatives; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.ai_initiatives (
    id text NOT NULL,
    "userId" text NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    status public."InitiativeStatus" DEFAULT 'active'::public."InitiativeStatus" NOT NULL,
    payload jsonb,
    "dedupeKey" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "respondedAt" timestamp(3) without time zone
);


ALTER TABLE public.ai_initiatives OWNER TO secondbrain;

--
-- Name: assessment_submissions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.assessment_submissions (
    id text NOT NULL,
    "assessmentId" text NOT NULL,
    "userId" text NOT NULL,
    answers jsonb NOT NULL,
    score double precision NOT NULL,
    results jsonb NOT NULL,
    summary text NOT NULL,
    advice text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.assessment_submissions OWNER TO secondbrain;

--
-- Name: assessments; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.assessments (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    topic text NOT NULL,
    title text NOT NULL,
    level text,
    "conceptId" text,
    questions jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.assessments OWNER TO secondbrain;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "actorId" text,
    action text NOT NULL,
    detail text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO secondbrain;

--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.calendar_events (
    id text NOT NULL,
    "userId" text NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.calendar_events OWNER TO secondbrain;

--
-- Name: cards; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.cards (
    id text NOT NULL,
    "deckId" text NOT NULL,
    "userId" text NOT NULL,
    front text NOT NULL,
    back text NOT NULL,
    "sourceDocumentId" text,
    state public."CardState" DEFAULT 'new'::public."CardState" NOT NULL,
    stability double precision DEFAULT 0 NOT NULL,
    difficulty double precision DEFAULT 0 NOT NULL,
    due timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "elapsedDays" integer DEFAULT 0 NOT NULL,
    "scheduledDays" integer DEFAULT 0 NOT NULL,
    reps integer DEFAULT 0 NOT NULL,
    lapses integer DEFAULT 0 NOT NULL,
    "lastReview" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.cards OWNER TO secondbrain;

--
-- Name: coach_profiles; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.coach_profiles (
    id text NOT NULL,
    "userId" text NOT NULL,
    pace text NOT NULL,
    difficulty text NOT NULL,
    "sessionMinutes" integer NOT NULL,
    method text NOT NULL,
    rationale jsonb,
    "paceOverride" text,
    "difficultyOverride" text,
    "sessionMinutesOverride" integer,
    "methodOverride" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.coach_profiles OWNER TO secondbrain;

--
-- Name: collections; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.collections (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.collections OWNER TO secondbrain;

--
-- Name: concept_cards; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.concept_cards (
    id text NOT NULL,
    "conceptId" text NOT NULL,
    "cardId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.concept_cards OWNER TO secondbrain;

--
-- Name: concept_documents; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.concept_documents (
    id text NOT NULL,
    "conceptId" text NOT NULL,
    "documentId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.concept_documents OWNER TO secondbrain;

--
-- Name: concept_edges; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.concept_edges (
    id text NOT NULL,
    "userId" text NOT NULL,
    "sourceId" text NOT NULL,
    "targetId" text NOT NULL,
    relation public."ConceptRelation" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.concept_edges OWNER TO secondbrain;

--
-- Name: concepts; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.concepts (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    "normalizedName" text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.concepts OWNER TO secondbrain;

--
-- Name: consents; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.consents (
    id text NOT NULL,
    "userId" text NOT NULL,
    key text NOT NULL,
    granted boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.consents OWNER TO secondbrain;

--
-- Name: daily_plan_items; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.daily_plan_items (
    id text NOT NULL,
    "planId" text NOT NULL,
    slot public."PlanSlot" NOT NULL,
    kind public."PlanItemKind" NOT NULL,
    title text NOT NULL,
    detail text,
    status public."PlanItemStatus" DEFAULT 'pending'::public."PlanItemStatus" NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    "targetCount" integer,
    "conceptId" text,
    "deckId" text,
    "languageProfileId" text,
    "completedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.daily_plan_items OWNER TO secondbrain;

--
-- Name: daily_plans; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.daily_plans (
    id text NOT NULL,
    "userId" text NOT NULL,
    date date NOT NULL,
    timezone text NOT NULL,
    "generatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.daily_plans OWNER TO secondbrain;

--
-- Name: decks; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.decks (
    id text NOT NULL,
    "userId" text NOT NULL,
    name text NOT NULL,
    description text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.decks OWNER TO secondbrain;

--
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.document_chunks (
    id text NOT NULL,
    "documentId" text NOT NULL,
    "userId" text NOT NULL,
    "chunkIndex" integer NOT NULL,
    content text NOT NULL,
    "vectorId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.document_chunks OWNER TO secondbrain;

--
-- Name: documents; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.documents (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text NOT NULL,
    source public."DocumentSource" NOT NULL,
    "sourceRef" text,
    content text NOT NULL,
    "charCount" integer NOT NULL,
    status public."DocumentStatus" DEFAULT 'pending'::public."DocumentStatus" NOT NULL,
    error text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    author text,
    "collectionId" text,
    "deletedAt" timestamp(3) without time zone,
    difficulty text,
    "enrichedAt" timestamp(3) without time zone,
    "isFavorite" boolean DEFAULT false NOT NULL,
    language text,
    subject text,
    summary text,
    stage text
);


ALTER TABLE public.documents OWNER TO secondbrain;

--
-- Name: email_verification_tokens; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.email_verification_tokens (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tokenHash" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "consumedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.email_verification_tokens OWNER TO secondbrain;

--
-- Name: exams; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.exams (
    id text NOT NULL,
    "userId" text NOT NULL,
    subject text NOT NULL,
    date timestamp(3) without time zone NOT NULL,
    priority text DEFAULT 'medium'::text NOT NULL,
    "conceptId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.exams OWNER TO secondbrain;

--
-- Name: exercise_attempts; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.exercise_attempts (
    id text NOT NULL,
    "userId" text NOT NULL,
    "lessonId" text NOT NULL,
    "exerciseIndex" integer NOT NULL,
    question text NOT NULL,
    "expectedAnswer" text NOT NULL,
    "learnerAnswer" text NOT NULL,
    correct boolean NOT NULL,
    score double precision NOT NULL,
    correction text NOT NULL,
    feedback text NOT NULL,
    "conceptId" text,
    "rootCauseConceptId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "errorMade" text,
    how text,
    "howToAvoid" text,
    why text
);


ALTER TABLE public.exercise_attempts OWNER TO secondbrain;

--
-- Name: goals; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.goals (
    id text NOT NULL,
    "userId" text NOT NULL,
    period text NOT NULL,
    title text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.goals OWNER TO secondbrain;

--
-- Name: group_members; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.group_members (
    id text NOT NULL,
    "groupId" text NOT NULL,
    "userId" text NOT NULL,
    role public."OrgRole" DEFAULT 'student'::public."OrgRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.group_members OWNER TO secondbrain;

--
-- Name: homework; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.homework (
    id text NOT NULL,
    "userId" text NOT NULL,
    "lessonId" text NOT NULL,
    "conceptId" text,
    language text,
    focus text NOT NULL,
    exercises jsonb NOT NULL,
    questions jsonb NOT NULL,
    "masteryAtGeneration" double precision,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.homework OWNER TO secondbrain;

--
-- Name: incidents; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.incidents (
    id text NOT NULL,
    title text NOT NULL,
    description text,
    severity public."IncidentSeverity" DEFAULT 'medium'::public."IncidentSeverity" NOT NULL,
    status public."IncidentStatus" DEFAULT 'open'::public."IncidentStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "resolvedAt" timestamp(3) without time zone
);


ALTER TABLE public.incidents OWNER TO secondbrain;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.invoices (
    id text NOT NULL,
    "userId" text NOT NULL,
    number text NOT NULL,
    provider text NOT NULL,
    amount integer NOT NULL,
    currency text DEFAULT 'usd'::text NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    "periodStart" timestamp(3) without time zone,
    "periodEnd" timestamp(3) without time zone,
    url text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.invoices OWNER TO secondbrain;

--
-- Name: language_profiles; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.language_profiles (
    id text NOT NULL,
    "userId" text NOT NULL,
    language text NOT NULL,
    "normalizedLanguage" text NOT NULL,
    "nativeLanguage" text,
    mode public."LanguageMode" DEFAULT 'beginner'::public."LanguageMode" NOT NULL,
    goal text,
    "vocabDeckId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "cefrLevel" text DEFAULT 'A1'::text NOT NULL
);


ALTER TABLE public.language_profiles OWNER TO secondbrain;

--
-- Name: learning_dna; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.learning_dna (
    id text NOT NULL,
    "userId" text NOT NULL,
    traits jsonb NOT NULL,
    maturity integer NOT NULL,
    interactions integer DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.learning_dna OWNER TO secondbrain;

--
-- Name: learning_predictions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.learning_predictions (
    id text NOT NULL,
    "userId" text NOT NULL,
    kind text NOT NULL,
    probability integer NOT NULL,
    level text NOT NULL,
    cause text NOT NULL,
    action text NOT NULL,
    signals jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.learning_predictions OWNER TO secondbrain;

--
-- Name: lessons; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.lessons (
    id text NOT NULL,
    "userId" text NOT NULL,
    "tutorSessionId" text,
    "conceptId" text,
    language text,
    topic text NOT NULL,
    objective text NOT NULL,
    intro text NOT NULL,
    explanation text NOT NULL,
    examples jsonb NOT NULL,
    exercises jsonb NOT NULL,
    homework text NOT NULL,
    summary text NOT NULL,
    "revisionSheet" text NOT NULL,
    "sourceDocumentId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "languageProfileId" text,
    level text,
    questions jsonb,
    "keyPoints" jsonb
);


ALTER TABLE public.lessons OWNER TO secondbrain;

--
-- Name: memberships; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.memberships (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    "userId" text NOT NULL,
    role public."OrgRole" DEFAULT 'student'::public."OrgRole" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.memberships OWNER TO secondbrain;

--
-- Name: mentor_guidance; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.mentor_guidance (
    id text NOT NULL,
    "userId" text NOT NULL,
    headline text NOT NULL,
    focus text,
    dimensions jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.mentor_guidance OWNER TO secondbrain;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    "userId" text NOT NULL,
    date date NOT NULL,
    slot public."PlanSlot" NOT NULL,
    channel text NOT NULL,
    title text NOT NULL,
    body text NOT NULL,
    "sentAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.notifications OWNER TO secondbrain;

--
-- Name: org_groups; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.org_groups (
    id text NOT NULL,
    "organizationId" text NOT NULL,
    name text NOT NULL,
    kind public."OrgGroupKind" DEFAULT 'class'::public."OrgGroupKind" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.org_groups OWNER TO secondbrain;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.organizations (
    id text NOT NULL,
    name text NOT NULL,
    type public."OrganizationType" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.organizations OWNER TO secondbrain;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.payments (
    id text NOT NULL,
    "userId" text NOT NULL,
    provider text NOT NULL,
    "providerRef" text,
    amount integer NOT NULL,
    currency text DEFAULT 'usd'::text NOT NULL,
    status public."PaymentStatus" DEFAULT 'succeeded'::public."PaymentStatus" NOT NULL,
    purpose text DEFAULT 'subscription'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.payments OWNER TO secondbrain;

--
-- Name: plans; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.plans (
    id text NOT NULL,
    slug text NOT NULL,
    name text NOT NULL,
    tier integer DEFAULT 0 NOT NULL,
    audience text DEFAULT 'individual'::text NOT NULL,
    quotas jsonb DEFAULT '{}'::jsonb NOT NULL,
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    "priceMonthly" integer,
    "priceYearly" integer,
    currency text DEFAULT 'usd'::text NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.plans OWNER TO secondbrain;

--
-- Name: profiles; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.profiles (
    id text NOT NULL,
    "userId" text NOT NULL,
    "displayName" text,
    "preferredLanguage" text DEFAULT 'en'::text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL
);


ALTER TABLE public.profiles OWNER TO secondbrain;

--
-- Name: reading_exercises; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.reading_exercises (
    id text NOT NULL,
    "userId" text NOT NULL,
    level text NOT NULL,
    topic text,
    title text NOT NULL,
    text text NOT NULL,
    questions jsonb NOT NULL,
    score double precision,
    "adaptedLevel" text,
    result jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.reading_exercises OWNER TO secondbrain;

--
-- Name: recommendations; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.recommendations (
    id text NOT NULL,
    "userId" text NOT NULL,
    kind text NOT NULL,
    title text NOT NULL,
    reason text NOT NULL,
    "targetKind" text,
    "targetId" text,
    "dedupeKey" text NOT NULL,
    priority integer DEFAULT 0 NOT NULL,
    status public."RecommendationStatus" DEFAULT 'suggested'::public."RecommendationStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "respondedAt" timestamp(3) without time zone
);


ALTER TABLE public.recommendations OWNER TO secondbrain;

--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.recovery_codes (
    id text NOT NULL,
    "userId" text NOT NULL,
    "codeHash" text NOT NULL,
    "usedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.recovery_codes OWNER TO secondbrain;

--
-- Name: reports; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.reports (
    id text NOT NULL,
    "reporterId" text,
    category text DEFAULT 'other'::text NOT NULL,
    message text NOT NULL,
    status public."ReportStatus" DEFAULT 'open'::public."ReportStatus" NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "reviewedAt" timestamp(3) without time zone
);


ALTER TABLE public.reports OWNER TO secondbrain;

--
-- Name: review_logs; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.review_logs (
    id text NOT NULL,
    "cardId" text NOT NULL,
    "userId" text NOT NULL,
    rating integer NOT NULL,
    state public."CardState" NOT NULL,
    "scheduledDays" integer NOT NULL,
    "reviewedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.review_logs OWNER TO secondbrain;

--
-- Name: reviewables; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.reviewables (
    id text NOT NULL,
    "userId" text NOT NULL,
    kind text NOT NULL,
    "refId" text NOT NULL,
    title text NOT NULL,
    state public."CardState" DEFAULT 'new'::public."CardState" NOT NULL,
    stability double precision DEFAULT 0 NOT NULL,
    difficulty double precision DEFAULT 0 NOT NULL,
    due timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "elapsedDays" integer DEFAULT 0 NOT NULL,
    "scheduledDays" integer DEFAULT 0 NOT NULL,
    reps integer DEFAULT 0 NOT NULL,
    lapses integer DEFAULT 0 NOT NULL,
    "lastReview" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.reviewables OWNER TO secondbrain;

--
-- Name: sessions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "refreshTokenHash" text NOT NULL,
    "userAgent" text,
    "ipAddress" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.sessions OWNER TO secondbrain;

--
-- Name: study_resources; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.study_resources (
    id text NOT NULL,
    "userId" text NOT NULL,
    "documentId" text NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    content text NOT NULL,
    "deckId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.study_resources OWNER TO secondbrain;

--
-- Name: study_sessions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.study_sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "conceptId" text,
    "lessonId" text,
    subject text NOT NULL,
    status text DEFAULT 'learning'::text NOT NULL,
    "learningScoreBefore" double precision,
    "masteryBefore" double precision,
    "learningScoreAfter" double precision,
    "masteryAfter" double precision,
    "startedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "completedAt" timestamp(3) without time zone
);


ALTER TABLE public.study_sessions OWNER TO secondbrain;

--
-- Name: subscriptions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.subscriptions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "planId" text NOT NULL,
    status public."SubscriptionStatus" DEFAULT 'active'::public."SubscriptionStatus" NOT NULL,
    "currentPeriodStart" timestamp(3) without time zone,
    "currentPeriodEnd" timestamp(3) without time zone,
    "cancelAtPeriodEnd" boolean DEFAULT false NOT NULL,
    "trialEndsAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "interval" text,
    provider text,
    "providerCustomerId" text,
    "providerSubscriptionId" text
);


ALTER TABLE public.subscriptions OWNER TO secondbrain;

--
-- Name: success_predictions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.success_predictions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "examId" text NOT NULL,
    preparation integer,
    "successProbability" integer,
    confidence integer NOT NULL,
    factors jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.success_predictions OWNER TO secondbrain;

--
-- Name: tutor_messages; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.tutor_messages (
    id text NOT NULL,
    "sessionId" text NOT NULL,
    role public."TutorRole" NOT NULL,
    content text NOT NULL,
    citations jsonb,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "viaVoice" boolean DEFAULT false NOT NULL
);


ALTER TABLE public.tutor_messages OWNER TO secondbrain;

--
-- Name: tutor_sessions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.tutor_sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    title text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "focusConceptId" text,
    "languageProfileId" text,
    subject text,
    strategy text,
    "strategyReason" text
);


ALTER TABLE public.tutor_sessions OWNER TO secondbrain;

--
-- Name: usage_counters; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.usage_counters (
    id text NOT NULL,
    "userId" text NOT NULL,
    metric text NOT NULL,
    period text NOT NULL,
    used integer DEFAULT 0 NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public.usage_counters OWNER TO secondbrain;

--
-- Name: users; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.users (
    id text NOT NULL,
    email text NOT NULL,
    "passwordHash" text NOT NULL,
    "emailVerified" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "twoFactorEnabled" boolean DEFAULT false NOT NULL,
    "twoFactorSecret" text,
    "isAdmin" boolean DEFAULT false NOT NULL,
    "suspendedAt" timestamp(3) without time zone,
    "lastActiveAt" timestamp(3) without time zone
);


ALTER TABLE public.users OWNER TO secondbrain;

--
-- Name: webhook_events; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.webhook_events (
    id text NOT NULL,
    provider text NOT NULL,
    "eventId" text NOT NULL,
    type text NOT NULL,
    "processedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.webhook_events OWNER TO secondbrain;

--
-- Name: writing_submissions; Type: TABLE; Schema: public; Owner: secondbrain
--

CREATE TABLE public.writing_submissions (
    id text NOT NULL,
    "userId" text NOT NULL,
    type text NOT NULL,
    title text,
    text text NOT NULL,
    score double precision NOT NULL,
    review jsonb NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.writing_submissions OWNER TO secondbrain;

--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
4ef0a9bd-254c-4ad6-8834-0291361f3768	78d9e007b5c4ef6290e8b21a7ba6dcc967235b724ba93d3184d74d6ce0834e77	2026-08-04 16:23:03.885466+00	20260716095209_daily_journey	\N	\N	2026-08-04 16:23:03.732128+00	1
e04d88cb-fb9d-49e6-a382-d811795eb7ba	b5edb0b33295e23aec8471c890af1ad522853864cec1c1ddc279b1eeef1a9117	2026-08-04 16:23:01.961385+00	20260712210749_init	\N	\N	2026-08-04 16:23:01.090535+00	1
25781680-5552-4755-9dee-faa0ffedbbad	1ef581f508a2d0e46ed5cd5b06e4aab5205e293a0aa70ff3142692fb689c84fb	2026-08-04 16:23:02.135031+00	20260712225700_email_verification	\N	\N	2026-08-04 16:23:01.97185+00	1
8dc61805-7f41-4405-8f72-7611d5593a27	1fc0a5d24dc8f0f2bb3ad201200a65f8ef39a0e886f8df562a63b77f5ac50ad1	2026-08-04 18:48:09.040806+00	20260804184808_literacy_writing_reading	\N	\N	2026-08-04 18:48:08.526988+00	1
25a2c00a-13c5-44d3-85aa-e36f05451ef5	efc53c4b0cd71a7c2bcbafb8c69879f79f6174770aee6b0f5aeb9dd0894c2e0b	2026-08-04 16:23:02.248863+00	20260713095642_two_factor_auth	\N	\N	2026-08-04 16:23:02.150103+00	1
8343bbe1-3f92-4698-9553-eb2692e6b0b5	efeeb1cbac5aa88531a490db7a75e8742fce330b5c5a36732643fec0f33e7c73	2026-08-04 16:23:03.95983+00	20260716130754_exercise_attempts	\N	\N	2026-08-04 16:23:03.891117+00	1
ab817bed-20c1-4c20-91d6-1e11cda90561	20926e9890dafa6fbe4af43bd72eefb6a17061b50581820c38013dd0efae0521	2026-08-04 16:23:02.389862+00	20260713104255_documents	\N	\N	2026-08-04 16:23:02.264113+00	1
b9fcd089-6d78-4096-80d6-ceadfdfd778f	7d5de63fa8e33066001133249e58d4ce41b920ac3ae4d35dd5278770309f4be6	2026-08-04 16:23:02.541059+00	20260713113639_document_chunks	\N	\N	2026-08-04 16:23:02.407775+00	1
b8f11a68-551e-4001-a19c-e86b058787c0	3a8262b0745e213d5409b3aa05c15a260e95f000128c4605e34b0452ef7dc23b	2026-08-04 16:23:04.293559+00	20260727032200_study_session	\N	\N	2026-08-04 16:23:04.238219+00	1
a9f4e919-1793-4c4e-acb5-dee20d94f9b7	751b7b1cdef594a76b7287a93253a251da41892471d0b834f70e324b8f488548	2026-08-04 16:23:02.896429+00	20260713155825_decks_cards	\N	\N	2026-08-04 16:23:02.559579+00	1
d8968ab5-f63d-47c3-a3d7-c795ad9cc393	c3d200d7e71908bb4d7fa4410635517558b4384495669b4abf9f46a0c38a2acb	2026-08-04 16:23:03.983444+00	20260716132549_lesson_level	\N	\N	2026-08-04 16:23:03.966311+00	1
0d81fcc8-0595-4deb-9703-215ae7cd2412	88acd3b92baa087f94d05b0648aaa3bb86e6d0cee9d978761759c0e7152639c2	2026-08-04 16:23:03.043665+00	20260715034819_concepts	\N	\N	2026-08-04 16:23:02.905946+00	1
c42e4503-0bd5-438e-8f62-6decb0e754d2	f39e23290bac7b4d463cc539945c83a3803d6fd39ef46e05c20536d62d47e216	2026-08-04 16:23:03.162683+00	20260715035936_concept_links	\N	\N	2026-08-04 16:23:03.048636+00	1
acccce72-003d-42f3-abcf-cb38602a99ff	5ec02059fcd000a896f5f2150e2bcf1dc7bcfb5e3e3f90e3156c8a23d74d8897	2026-08-04 16:23:03.411814+00	20260715054532_tutor_sessions	\N	\N	2026-08-04 16:23:03.167583+00	1
911a3dbd-44fc-44d2-8bfd-9bfe5a5be1ac	70bdb0d573ac8db0397486167e097d960afe5f246bcee566f27cdd52a130afda	2026-08-04 16:23:04.051729+00	20260716135932_achievements	\N	\N	2026-08-04 16:23:03.988743+00	1
5be296bf-8fc0-4070-8e88-76b3908c38bd	91719badb35775df43f9b325f2314e4e2ca2b6a6b9737c6ea0b2a3d3db5c82a3	2026-08-04 16:23:03.464768+00	20260715055946_tutor_focus	\N	\N	2026-08-04 16:23:03.426059+00	1
bfad8646-18a7-463a-a6ff-11b1df40b858	c78422e2e4beb7ff7b0cf717c915d9cfe7b6cbe564361e399e1f7dd629c8fd44	2026-08-04 16:23:03.600098+00	20260715232603_lessons	\N	\N	2026-08-04 16:23:03.477055+00	1
a32a8a27-2c09-4428-95ee-65dddb6fe484	a947324c10940928c84a1c4670faf4193c417d3d48b420be09fee630e0ccabaa	2026-08-04 16:23:04.823754+00	20260730091656_study_resources	\N	\N	2026-08-04 16:23:04.754381+00	1
318c4e2b-f9af-4812-9ca6-94a75f909927	c78a17fc6b43f1fd3be550df399bf497c5d913bcde5386f6d3618632d08e4dbd	2026-08-04 16:23:03.639019+00	20260716084549_voice_messages	\N	\N	2026-08-04 16:23:03.610547+00	1
f2af9204-ac3a-472e-9b50-2d899a5c61fb	a05e8af4362d29d0c45040296c306dca948be716dc3a2ec4d913e8ab0175a068	2026-08-04 16:23:04.086656+00	20260718012804_lesson_questions	\N	\N	2026-08-04 16:23:04.056749+00	1
d4faf020-20ea-4472-8e2c-084634f8ad5b	c1a8f1d830fc819058c34369a5262de45337fb0ba38219ca73a3b3405f46113c	2026-08-04 16:23:03.726353+00	20260716092043_language_engine	\N	\N	2026-08-04 16:23:03.646707+00	1
11b796b8-3754-4526-944e-a429e24a0331	b6d8e32943868183071825ac1ecb6f3211d00b27ed9ae8457f5746a303e033f7	2026-08-04 16:23:04.366408+00	20260728004721_revision_engine	\N	\N	2026-08-04 16:23:04.300753+00	1
5c1c5e58-cc83-44a1-b6b3-4ba9810ae470	c2e215a13009fd7466a70aa1c7b301a276750d4624ba16c3dbd1180fe2ab9018	2026-08-04 16:23:04.113684+00	20260718020649_structured_correction	\N	\N	2026-08-04 16:23:04.092466+00	1
a446bec6-5f52-4bb0-9a05-57fd324a34eb	db7569875c4795fd9f87f476b0c9c7018dfe3191f0f1c1fb52e04f390e9abc63	2026-08-04 16:23:04.138646+00	20260719015521_lesson_key_points	\N	\N	2026-08-04 16:23:04.120047+00	1
10b9aba3-a3ef-4256-95d0-d8d4e8c3203e	8cc45fdf0d316e484a786c5fef8bff2dbf20a647cacd77403181a38a2c4f85aa	2026-08-04 16:23:04.437192+00	20260728162236_calendar_events	\N	\N	2026-08-04 16:23:04.373243+00	1
cf833915-c384-48ab-9cca-03ef58df5593	fed2aec689707c55083f2532e23c0a3c83c35c714318ece2358210389233668f	2026-08-04 16:23:04.206003+00	20260726223627_homework_engine	\N	\N	2026-08-04 16:23:04.143508+00	1
61947849-fa5d-45d2-b3e1-d3e8f91c2c15	112ac764a3afb8d866b7702e7f02d9e29999765a80b7df1d1e5496bbae30bf7a	2026-08-04 16:23:04.231899+00	20260727024501_tutor_subject	\N	\N	2026-08-04 16:23:04.214428+00	1
212f6f11-402e-43c9-9831-cb6e01fce531	4fb502c70b47136a0f64d45e6a06337e5f85fbec74c1a5d05fcd6b0e55ae829e	2026-08-04 16:23:04.522825+00	20260729094020_goals_exams	\N	\N	2026-08-04 16:23:04.444173+00	1
04a803a1-48f0-475d-8554-7fd7a77e0e4d	305833d4874a4ea672fabd41f62feda371b263c1194aa9f4609e616d62a89419	2026-08-04 16:23:04.851544+00	20260730214146_language_cefr	\N	\N	2026-08-04 16:23:04.830265+00	1
6960bd8b-8616-4bde-bfb4-f9bc85bf4393	fdb0235772ff9b872bda58986fa0c6daf87b2622c9d40c6789c07449954e7eef	2026-08-04 16:23:04.720288+00	20260730030639_smart_library	\N	\N	2026-08-04 16:23:04.529044+00	1
ace978e7-e9f8-469f-8b3f-ff6bd8c57f4a	00ba5636c5f06abbe70e9d1d89360515ac052748f56e540c85f18bb5e2a3cfc9	2026-08-04 16:23:04.747691+00	20260730035905_pipeline_stage	\N	\N	2026-08-04 16:23:04.726772+00	1
99ff820d-7555-4fdf-8de0-92941764ded6	3d271dbba3d6f3a06599fbec955f3d92a232151bfb6e1bc122af03109d646583	2026-08-04 17:44:26.333044+00	20260804174426_examiner_assessments	\N	\N	2026-08-04 17:44:26.084688+00	1
eba2b70e-aa9b-45fd-aea4-3bd0df466bc9	a3cc2e80c7bb4e85a9e04b45fd6f01e34785cda1ec454f2d5e6806a6d581bd35	2026-08-07 01:40:40.76244+00	20260807014040_usage_quotas	\N	\N	2026-08-07 01:40:40.346687+00	1
3f8ef5cb-2286-47d4-a544-3160b234c052	567a6b30821a64cf3f9156438d905033018264e0c4e69debdc1d68270ee92bc0	2026-08-04 20:47:47.727711+00	20260804204747_ite_teaching_strategy	\N	\N	2026-08-04 20:47:47.587044+00	1
ab1d5ed8-93e4-4724-a70f-f7fb7a732bfa	4ed7d1dabd57cf528ff22350b3fcc30731eec2d89898fc0be046dfbbd6e7d3d3	2026-08-05 14:54:57.203276+00	20260805145455_billing_payments	\N	\N	2026-08-05 14:54:55.784841+00	1
051f0ddb-3bec-4bb6-b0f2-b1353752a58c	a3bbacce8be5fe0228b0f56d1702458275c02040e431e43cedf82378fb59a3d4	2026-08-05 13:57:16.713646+00	20260805135716_subscription_engine	\N	\N	2026-08-05 13:57:16.34269+00	1
6bd1440b-0f0b-403e-bdcb-8fdf534aae96	38d2f2f57d34a19af21cd50f54045d0ca565d5c30c2ca80f73577154dbfd36d9	2026-08-07 02:24:30.285731+00	20260807022429_organizations	\N	\N	2026-08-07 02:24:29.57416+00	1
1aed3490-cefd-4f68-9ba6-aadd69da316a	6942bddee71b05215949b079c57efd4eddebdc885dd1392c90bda0f25a94ad3f	2026-08-07 11:19:01.982786+00	20260807111901_admin_backoffice	\N	\N	2026-08-07 11:19:01.759215+00	1
239a5edd-919d-41bb-a54b-b9fc57a085d7	508742154444653afb5d8ba42cfc46a62dc3cabebb4a95286d7f0877fd6c94ab	2026-08-11 16:12:00.712672+00	20260811161200_analytics_last_active	\N	\N	2026-08-11 16:12:00.547878+00	1
c7e40ef7-8e5b-4c9a-9c37-ad9603847fb1	92faa16486953872f5ed7ee74a6c0d19aa73ec58354e310d07e2e3efb7716c8a	2026-08-11 17:08:17.737299+00	20260811170816_gdpr_consent	\N	\N	2026-08-11 17:08:17.120779+00	1
8e4f8fa7-3f04-4182-afc0-ae1e93e8710c	e4ca5153a6fe4ad4cb9d77a3da2b695159856ca0349440f18c98a09130928001	2026-08-11 18:49:51.202095+00	20260811184950_ai_initiatives	\N	\N	2026-08-11 18:49:50.832647+00	1
f613327e-ae39-429d-8953-0fd3b3b2b95f	7234518dd35ba42acd84eefc19aa2c66ca2492dea247005bc09511b098bc40fa	2026-08-12 03:19:47.647694+00	20260812031946_coach_profile	\N	\N	2026-08-12 03:19:47.314517+00	1
46a15334-e424-4466-9aa9-09755a963027	0c92a801078f9c892295e84355e0f13a4b37714d820f3ccf6b1193b55ef9e30a	2026-08-12 03:59:26.666726+00	20260812035925_learning_predictions	\N	\N	2026-08-12 03:59:26.028111+00	1
da5382af-e808-4e31-bfc0-ca8b971fd8ee	9566921a820b48b84d0c0b7c91efe210d23da920979b6d559a808d9a426396ba	2026-08-12 04:19:29.571618+00	20260812041928_recommendations	\N	\N	2026-08-12 04:19:29.371356+00	1
0a680151-55af-41d2-b4ef-d0f4780cde0a	d0485269a684acf7d2fa28814e15ecba19d9b9f741dd9cbb3c5f5d7b3b2b8cb8	2026-08-12 06:34:10.593954+00	20260812063408_mentor_guidance	\N	\N	2026-08-12 06:34:08.614278+00	1
0d769568-e825-4b7a-be3e-22a1905a9453	18013bec313e63b4d57acc80b08c267c49580fca1e1a0bc8f487cb6b71f9ce0c	2026-08-12 06:53:23.601488+00	20260812065323_success_predictions	\N	\N	2026-08-12 06:53:23.446821+00	1
ef747f25-10ce-4e28-a402-c47f280150d5	10d606f94b7f7e483059799de93b6105c5d862b4535975bb2ac929bc5e292400	2026-08-12 07:32:00.818391+00	20260812073200_learning_dna	\N	\N	2026-08-12 07:32:00.552789+00	1
8178729a-a003-41e8-80ce-8c375f8fe90f	78d148a8f21d50314b6feded3677d39c32dcc47a74592f04c435e8bb76e50284	2026-08-12 12:59:15.883653+00	20260812125915_perf_indexes	\N	\N	2026-08-12 12:59:15.533002+00	1
\.


--
-- Data for Name: achievements; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.achievements (id, "userId", kind, threshold, "achievedAt") FROM stdin;
cmsf3jkw6003cvki876lxkifa	cmsezu9gz000ivks8r8x63ms4	lessons_completed	1	2026-08-04 20:14:20.55
cmspgimjr0019vk5sb9dwkhkt	cmsevaz4j0000vkmkl9u1habf	lessons_completed	1	2026-08-12 02:15:12.807
cmspst4hx001hvkwo86elnzb6	cmsevaz4j0000vkmkl9u1habf	concepts_mastered	1	2026-08-12 07:59:17.05
\.


--
-- Data for Name: ai_initiatives; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.ai_initiatives (id, "userId", kind, title, message, priority, status, payload, "dedupeKey", "createdAt", "respondedAt") FROM stdin;
cmspg96kk000jvk5sk8lapc64	cmsevaz4j0000vkmkl9u1habf	advance	Ready to start Les derivees	Russell, you've mastered what "Les derivees" builds on — I think you're ready to start it.	50	active	{"reasons": ["\\"Les derivees\\" has no unmet prerequisites.", "Its foundations are already mastered."]}	advance:cmspfogm0000fvk90shxxit2z	2026-08-12 02:07:52.196	\N
cmspss40b0013vkwocrl1cdes	cmsezu9gz000ivks8r8x63ms4	review_due	16 reviews are due	LEO, you have 16 items due for review. A short session now will lock them into long-term memory.	60	active	{"reasons": ["16 FSRS cards are at or past their review date."]}	review_due	2026-08-12 07:58:30.731	\N
cmspss43b0017vkwo13t2ygfz	cmsezu9gz000ivks8r8x63ms4	advance	Ready to start Conversation Fundamentals	LEO, you've mastered what "Conversation Fundamentals" builds on — I think you're ready to start it.	50	active	{"reasons": ["\\"Conversation Fundamentals\\" has no unmet prerequisites.", "Its foundations are already mastered."]}	advance:cmsf3anso002cvki8fyqh7d9a	2026-08-12 07:58:30.839	\N
cmsps91v9000dvkwo72tjkm03	cmsevaz4j0000vkmkl9u1habf	review_due	7 reviews are due	Russell, you have 7 items due for review. A short session now will lock them into long-term memory.	60	dismissed	{"reasons": ["7 FSRS cards are at or past their review date."]}	review_due	2026-08-12 07:43:41.493	2026-08-12 13:49:33.141
\.


--
-- Data for Name: assessment_submissions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.assessment_submissions (id, "assessmentId", "userId", answers, score, results, summary, advice, "createdAt") FROM stdin;
cmseyx8ho0007vks83m0gs2se	cmseyvvh20003vks8o6d5l7gh	cmsevaz4j0000vkmkl9u1habf	["Absorber l'énergie lumineuse pour déclencher les réactions photochimiques", "Dans le stroma des chloroplastes", "Le dioxygène (O2)"]	67	[{"how": "Pour trouver cette réponse, il faut relier 'chlorophylle' à 'lumière' (photo = lumière). C'est le point de départ de la photosynthèse.", "max": 5, "why": "Ta réponse est parfaitement exacte ! Les pigments chlorophylliens jouent effectivement le rôle fondamental de capter l'énergie lumineuse du soleil, amorçant ainsi toute la chaîne des réactions photochimiques de la photosynthèse.", "prompt": "Quel est le rôle principal des pigments chlorophylliens dans la photosynthèse ?", "awarded": 5, "verdict": "correct", "errorMade": null, "howToAvoid": null, "questionId": "0fd665bc-26b0-43f6-a98f-1edbdb2f0edc", "learnerAnswer": "Absorber l'énergie lumineuse pour déclencher les réactions photochimiques"}, {"how": "Pour ne plus te tromper, associe 'thylakoïdes' (qui contiennent la chlorophylle) à la lumière/phase claire, et 'stroma' au cycle de Calvin/phase sombre (qui n'a pas besoin directement de lumière).", "max": 5, "why": "Tu as confondu les deux grands compartiments du chloroplaste. Le stroma est le site des réactions de la phase sombre (cycle de Calvin), tandis que la phase claire (photochimique) se déroule dans la membrane des thylakoïdes.", "prompt": "Où se déroulent principalement les réactions de la phase photochimique (réactions claires) chez les plantes vertes ?", "awarded": 0, "verdict": "incorrect", "errorMade": "Confusion entre le stroma et la membrane des thylakoïdes comme lieu de la phase photochimique.", "howToAvoid": "Dessine un chloroplaste et fais un schéma clair avec ses deux parties (les piles de thylakoïdes et le liquide environnant, le stroma) en y associant la bonne phase métabolique.", "questionId": "c8cffd55-46a8-4061-b815-226a45d724f4", "learnerAnswer": "Dans le stroma des chloroplastes"}, {"how": "Pense à la formule de l'eau ($H_2O$) : lorsque la plante récupère les électrons et l'hydrogène, il reste l'oxygène, qui est libéré sous forme de gaz ($O_2$).", "max": 5, "why": "C'est exact ! La photolyse (qui signifie la casse par la lumière) de l'molécule d'eau ($H_2O$) libère du dioxygène ($O_2$), qui est le gaz indispensable que rejettent les plantes dans l'atmosphère.", "prompt": "Quel est le sous-produit gazeux majeur libéré lors de la photolyse de l'eau au cours de la photosynthèse ?", "awarded": 5, "verdict": "correct", "errorMade": null, "howToAvoid": null, "questionId": "ce383061-4381-4f9a-99ba-bf1d0ae98118", "learnerAnswer": "Le dioxygène (O2)"}]	Tu as obtenu un total de 10 points sur 15 (note : 10/15). C'est un bon résultat qui montre que tu as bien compris le rôle global de la photosynthèse, de ses pigments et de ses sous-produits. Il te reste cependant à bien ancrer la localisation précise des différentes phases à l'intérieur du chloroplaste.	Pour progresser, je te conseille de revoir la structure interne du chloroplaste (thylakoïdes vs stroma) et de bien associer chaque phase de la photosynthèse (phase claire et phase sombre) à son lieu exact de déroulement. Revois aussi le bilan global de ces deux phases !	2026-08-04 18:04:59.58
\.


--
-- Data for Name: assessments; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.assessments (id, "userId", type, topic, title, level, "conceptId", questions, "createdAt") FROM stdin;
cmseyvvh20003vks8o6d5l7gh	cmsevaz4j0000vkmkl9u1habf	mcq	la photosynthese	MCQ — la photosynthese	intermediate	\N	[{"id": "0fd665bc-26b0-43f6-a98f-1edbdb2f0edc", "format": "mcq", "points": 5, "prompt": "Quel est le rôle principal des pigments chlorophylliens dans la photosynthèse ?", "rubric": "L'élève doit identifier que la chlorophylle sert à capter la lumière, ce qui est le point de départ de la phase photochimique (claire) de la photosynthèse. Les distracteurs mélangent d'autres fonctions végétales (transpiration, respiration) ou la phase chimique (fixation du CO2).", "options": ["Absorber l'énergie lumineuse pour déclencher les réactions photochimiques", "Transpirer pour permettre la circulation de la sève brute dans la plante", "Fixer directement le dioxyde de carbone $\\\\text{CO}_2$ dans les stomates", "Produire de l'ATP par la respiration cellulaire durant la nuit"], "answerKey": "Absorber l'énergie lumineuse pour déclencher les réactions photochimiques"}, {"id": "c8cffd55-46a8-4061-b815-226a45d724f4", "format": "mcq", "points": 5, "prompt": "Où se déroulent principalement les réactions de la phase photochimique (réactions claires) chez les plantes vertes ?", "rubric": "Il est crucial de distinguer les deux compartiments du chloroplaste : les thylakoïdes abritent les photosystèmes pour la phase claire, tandis que le stroma accueille le cycle de Calvin (phase sombre). Une confusion fréquente est de placer la phase claire dans le stroma.", "options": ["Dans le stroma des chloroplastes", "Dans la membrane des thylakoïdes", "Dans la matrice mitochondriale", "Dans le cytoplasme de la cellule végétale"], "answerKey": "Dans la membrane des thylakoïdes"}, {"id": "ce383061-4381-4f9a-99ba-bf1d0ae98118", "format": "mcq", "points": 5, "prompt": "Quel est le sous-produit gazeux majeur libéré lors de la photolyse de l'eau au cours de la photosynthèse ?", "rubric": "La photolyse de l'eau (oxydation de l'eau par la lumière) libère des électrons, des protons et du dioxygène qui est rejeté dans l'atmosphère. Ne pas confondre avec le CO2, qui est quant à lui consommé et non produit lors de ce processus.", "options": ["Le dioxyde de carbone (\\\\text{CO}_2)", "Le monoxyde de carbone (\\\\text{CO})", "Le dioxygène (\\\\text{O}_2)", "L'ozone (\\\\text{O}_3)"], "answerKey": "Le dioxygène (\\\\text{O}_2)"}]	2026-08-04 18:03:55.239
cmseyygel000bvks87xqmf1gh	cmsevaz4j0000vkmkl9u1habf	mock_exam	la Revolution francaise	Mock exam — la Revolution francaise	intermediate	\N	[{"id": "72ed1677-bf34-4633-af00-3dd25399911b", "format": "mcq", "points": 2, "prompt": "Quel événement du 14 juillet 1789 est traditionnellement considéré comme le déclencheur symbolique de la Révolution française ?", "rubric": "L'étudiant doit identifier la prise de la Bastille comme le symbole populaire du début de la Révolution.", "options": ["La fuite de Varennes", "La prise de la Bastille", "L'exécution de Louis XVI", "La réunion des États généraux"], "answerKey": "La prise de la Bastille"}, {"id": "97fd6f2f-386a-4c3d-bbe2-31231f482390", "format": "mcq", "points": 3, "prompt": "Quel texte fondamental, adopté en août 1789, proclame l'égalité des droits et la souveraineté de la Nation ?", "rubric": "L'étudiant doit sélectionner la Déclaration des droits de l'homme et du citoyen (DDHC).", "options": ["Le Code civil", "La Constitution de 1791", "La Déclaration des droits de l'homme et du citoyen", "Le Contrat social"], "answerKey": "La Déclaration des droits de l'homme et du citoyen"}, {"id": "3e774bca-8143-472a-8be9-d06c6c536330", "format": "open", "points": 5, "prompt": "Expliquez brièvement le rôle et l'importance de la période connue sous le nom de \\"La Terreur\\" (1793-1794) pendant la Révolution française.", "rubric": "La réponse doit mentionner : 1) Le contexte de crise/menace (guerres, trahisons), 2) Les acteurs clés (Robespierre / Comité de salut public), et 3) Les méthodes autoritaires/répressives (guillotine, suspension des libertés).", "answerKey": "La Terreur fut une période dirigée par le Comité de salut public (notamment Robespierre) pour éliminer les ennemis intérieurs et extérieurs de la République, marquée par une forte centralisation du pouvoir et un recours massif à la guillotine, au nom du salut de la patrie en danger."}, {"id": "00fab3f4-c575-48d7-9302-bdac5bb3f339", "format": "open", "points": 10, "prompt": "Analysez les causes profondes et multiples (sociales, économiques et politiques) qui ont conduit à l'effondrement de l'Ancien Régime en 1789.", "rubric": "Une excellente réponse aborde clairement quatre dimensions : 1) Sociale (inégalités des trois ordres), 2) Économique (crise financière, mauvaise récoltes, cherté du pain), 3) Politique (crise de l'absolutisme royal et incapacité à réformer), et 4) Culturelle/Idéologique (l'impact des philosophes des Lumières). Chaque dimension compte pour l'évaluation globale.", "answerKey": "L'effondrement de l'Ancien Régime est dû à une crise financière aiguë (dette de l'État causée par la guerre d'Amérique), une crise agricole et frumentaire menaçant le peuple de famine, l'injustice de la société d'ordres (privilèges de la noblesse et du clergé face au Tiers État qui paye l'impôt), ainsi que l'influence des idées des Lumières remettant en cause l'absolutisme royal."}]	2026-08-04 18:05:56.493
cmseyyi8r000dvks88g7yl8bt	cmsevaz4j0000vkmkl9u1habf	dissertation	le libre arbitre	Dissertation — le libre arbitre	intermediate	\N	[{"id": "598c3cd9-bb49-4aec-bedf-cbc82d717e99", "format": "open", "points": 20, "prompt": "Le déterminisme scientifique remet-il nécessairement en cause l'existence du libre arbitre ?", "rubric": "Un essai fort doit : (1) Proposer une problématique claire dès l'introduction et définir rigoureusement les concepts de 'déterminisme' et de 'libre arbitre'. (2) Structurer une argumentation dialectique équilibrée (thèse, antithèse, dépassement). (3) Mobiliser des références philosophiques pertinentes (ex: Spinoza, Kant, Sartre, Frankfurt). (4) Offrir une conclusion nuancée qui répond directement au sujet sans tomber dans le sophisme.", "answerKey": "I. Thèse : Le déterminisme semble incompatible avec le libre arbitre (illusion de la liberté, causalité universelle, lois physiques). II. Antithèse : Le déterminisme est compatible avec la liberté (compatibilisme, Hobbes, Frankfurt) ou le libre arbitre s'affirme malgré/dans le déterminisme (Sartre, existentialisme, conscience). III. Synthèse : Redéfinition du libre arbitre non plus comme une absence totale de causes, mais comme une autonomie morale, une capacité de réflexion critique et d'action motivée par des raisons."}]	2026-08-04 18:05:58.875
cmsfpfyeh000dvk94x8th764x	cmsevaz4j0000vkmkl9u1habf	mcq	the water cycle	MCQ — the water cycle	intermediate	\N	[{"id": "1f05928d-2ece-42a4-aa33-76e2993a7987", "format": "mcq", "points": 5, "prompt": "Quel processus physique permet principalement à l'eau liquide des océans de se transformer en vapeur d'eau invisible pour alimenter l'atmosphère ?", "rubric": "L'élève doit identifier que l'évaporation est le passage de l'état liquide à l'état gazeux sous l'effet de la chaleur, contrairement à la condensation qui fait l'inverse.", "options": ["La condensation", "L'évaporation", "La précipitation", "L'infiltration"], "answerKey": "L'évaporation"}, {"id": "3a950cbc-a9ad-4ac5-a29a-81a28d88709a", "format": "mcq", "points": 5, "prompt": "Au cours du cycle de l'eau, que se passe-t-il lorsque la vapeur d'eau s'élève dans l'atmosphère, se refroidit et se condense autour de fines particules ?", "rubric": "L'élève doit comprendre l'étape de la condensation nuageuse, où la vapeur refroidie redevient liquide ou solide en suspension, formant les nuages.", "options": ["Elle forme des nuages constitués de minuscules gouttelettes d'eau ou de cristaux de glace.", "Elle s'infile directement dans les nappes souterraines par capillarité atmosphérique.", "Elle se solidifie instantanément pour retomber sous forme de grêle uniquement.", "Elle subit une fusion qui libère de l'oxygène dans la troposphère."], "answerKey": "Elle forme des nuages constitués de minuscules gouttelettes d'eau ou de cristaux de glace."}]	2026-08-05 06:27:22.985
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.audit_logs (id, "actorId", action, detail, "createdAt") FROM stdin;
cmsivbpv7000gvkxk5zfm6g7b	cmsevaz4j0000vkmkl9u1habf	user.suspend	cmsibrdyu000evkg8o2smybwc	2026-08-07 11:35:21.524
cmsivbq0v000jvkxklvigovlf	cmsevaz4j0000vkmkl9u1habf	user.set_plan	cmsibrdyu000evkg8o2smybwc → pro	2026-08-07 11:35:21.728
cmsivbq53000kvkxkovuvk62j	cmsevaz4j0000vkmkl9u1habf	user.reactivate	cmsibrdyu000evkg8o2smybwc	2026-08-07 11:35:21.88
cmsivbq8w000mvkxk6570dmik	cmsevaz4j0000vkmkl9u1habf	incident.create	Latence STT elevee	2026-08-07 11:35:22.016
cmsivbqaa000nvkxkj4llcufe	cmsevaz4j0000vkmkl9u1habf	incident.status	cmsivbq86000lvkxk30qf2ukm → resolved	2026-08-07 11:35:22.066
cmsivbqda000pvkxkg5te2iai	cmsevaz4j0000vkmkl9u1habf	report.resolve	cmsivbqas000ovkxkke1khdmg → reviewed	2026-08-07 11:35:22.175
cmsivxknl0015vkxk2kaju4nf	cmsevaz4j0000vkmkl9u1habf	incident.create	Pic de latence sur les paiements	2026-08-07 11:52:21.202
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.calendar_events (id, "userId", kind, title, date, "createdAt") FROM stdin;
\.


--
-- Data for Name: cards; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.cards (id, "deckId", "userId", front, back, "sourceDocumentId", state, stability, difficulty, due, "elapsedDays", "scheduledDays", reps, lapses, "lastReview", "createdAt", "updatedAt") FROM stdin;
cmsf3anhb001uvki8roao6006	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What is the primary objective of the lesson on conversation?	To enable learners to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf3anhc001wvki8yn4027by	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What are the four fundamental pillars of a conversation?	1. Initiation, 2. Active Listening, 3. Elaboration and Pacing, 4. Conclusion.	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf3anhc001yvki8a347aak8	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What is a better alternative to asking 'How are you?' when initiating a conversation?	Asking an open-ended question like 'What has been the highlight of your week so far?'	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf3anhc0020vki8usp1455w	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What is the key difference between how most people listen and how active listening works?	Most people listen with the intent to reply, whereas active listening involves giving full attention with the intent to understand.	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf3anhg0022vki8v1ulna80	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What types of questions are recommended to keep a conversation flowing and prevent it from being a monologue?	Open-ended questions starting with What, How, or Why.	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf3anhg0024vki8a3usqvhz	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What are the three essential components of concluding a conversation gracefully?	1. Acknowledging the enjoyment of the chat, 2. Providing a reason for leaving, 3. Setting the stage for future interaction (if appropriate).	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf3anhh0026vki8br1e4wkq	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What simile is used in the lesson to describe how a good conversation flows?	A tennis match (a balanced exchange of speaking and listening rather than a monologue).	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf3anhh0028vki8k8ydenu3	cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	What is stated as the golden rule of conversation in the revision sheet?	Listen to understand, not to reply.	cmsf3ajph001lvki88j6p72vk	new	0	0	2026-08-04 20:07:23.992	0	0	0	0	\N	2026-08-04 20:07:23.992	2026-08-04 20:07:23.992
cmsf6yzmd000nvk3chyeyxp7w	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	What is the primary objective of mastering conversation fundamentals?	To be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsf6yzme000pvk3c29xin0kh	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	What are the four fundamental pillars of a conversation?	1. Initiation, 2. Active Listening, 3. Elaboration and Pacing, and 4. Conclusion.	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsf6yzmg000rvk3caizlugx5	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	How can you improve the initiation phase compared to a standard 'How are you?' greeting?	Use low-stakes observations, situational remarks, or open-ended prompts, such as asking 'What has been the highlight of your week so far?'	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsf6yzmg000tvk3cm4c597xp	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	What is the difference between how most people listen and how active listeners listen?	Most people listen with the intent to reply rather than the intent to understand.	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsf6yzmh000vvk3cxoogzmtm	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	What are some techniques used in active listening?	Giving full attention, nodding, using verbal affirmations (e.g., 'I see', 'Go on'), validating feelings, and avoiding interruptions or hijacking the story.	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsf6yzml000xvk3cxvrb5gq6	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	What type of questions are recommended to keep a conversation flowing like a tennis match?	Open-ended questions starting with What, How, or Why.	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsf6yzml000zvk3c783jnhnd	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	What are the key elements of gracefully concluding a conversation?	Acknowledging the enjoyment of the chat, providing a reason for leaving, and, if appropriate, setting the stage for future interaction.	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsf6yzmm0011vk3cregtucaz	cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	What is the golden rule of conversation provided in the revision sheet?	Listen to understand, not to reply.	cmsf6ye63000jvk3cz7d814bi	new	0	0	2026-08-04 21:50:16.446	0	0	0	0	\N	2026-08-04 21:50:16.446	2026-08-04 21:50:16.446
cmsfankd20034vk3c1tjkot65	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	What is the primary objective of mastering conversation fundamentals?	To be able to initiate, maintain, and conclude engaging and effective conversations in social and professional settings using active listening and clear communication.	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmsfankd20036vk3cagyszqzh	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	What are the four fundamental pillars of a conversation?	1. Initiation, 2. Active Listening, 3. Pacing and Questioning, 4. Conclusion.	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmsfankd30038vk3crgjii4oa	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	What is the Golden Rule of conversation?	Listen to understand, not to reply.	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmsfankd3003avk3cehcoy9qh	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	How can you effectively initiate a conversation when breaking the ice?	Use low-stakes observations, situational remarks, or open-ended prompts (like commenting on someone's book).	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmsfankd4003cvk3ck4xbo2e7	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	What does active listening involve regarding the other person's story?	Focusing on understanding rather than just waiting for your turn to speak, using affirmations, and avoiding hijacking the conversation with your own stories.	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmsfankd4003evk3cg1r44lov	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	What types of questions are recommended to keep dialogue engaging and flowing during pacing?	What, How, and Why questions (open-ended questions).	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmsfankd4003gvk3c84u8mvhz	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	What are the three key elements of gracefully concluding a conversation?	1. Acknowledge the enjoyment of the chat, 2. Provide a reason for leaving, and 3. Set the stage for future interaction.	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmsfankd5003ivk3cotz9o9ny	cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	How is a conversation formally defined in the lesson?	A two-way exchange of thoughts, feelings, and ideas between two or more people.	cmsfane250030vk3ckp0grfpq	new	0	0	2026-08-04 23:33:23.108	0	0	0	0	\N	2026-08-04 23:33:23.108	2026-08-04 23:33:23.108
cmspghqni000rvk5skqxk9u9u	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Que représente graphiquement la dérivée d'une fonction en un point donné ?	La pente de la tangente à la courbe représentative de la fonction en ce point.	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspghqnj000tvk5s75xonst7	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Quel est le sens de variation d'une fonction dont la dérivée est strictement positive sur un intervalle ?	La fonction est croissante.	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspghqnj000vvk5s4v46m4jp	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Quel est le sens de variation d'une fonction dont la dérivée est strictement négative sur un intervalle ?	La fonction est décroissante.	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspghqnk000xvk5s455kyvh7	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Que vaut la dérivée d'une fonction constante $f(x) = c$ ?	Zero ($f'(x) = 0$).	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspghqnl000zvk5sm2lm58o7	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Quelle est la formule de la dérivée d'une fonction puissance $f(x) = x^n$ (avec $n$ entier naturel) ?	f'(x) = n * x^(n-1)	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspghqnm0011vk5s2qshr6ko	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Quelle est la dérivée de la fonction inverse $f(x) = \\frac{1}{x}$ ?	f'(x) = -\\frac{1}{x^2}	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspghqnm0013vk5siu969t0q	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Quelle est la dérivée de la fonction racine carrée $f(x) = \\sqrt{x}$ ?	f'(x) = \\frac{1}{2\\sqrt{x}}	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspghqnn0015vk5sx23ayge9	cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Quelle est la règle de dérivation pour la somme de deux fonctions $(f + g)'$ ?	(f + g)' = f' + g'	cmspgh6nb000nvk5sqpah351q	new	0	0	2026-08-12 02:14:30.59	0	0	0	0	\N	2026-08-12 02:14:30.59	2026-08-12 02:14:30.59
cmspqp58w0005vkwwgc1okx7s	cmspqp5640003vkwwa5z4nlzy	cmsevaz4j0000vkmkl9u1habf	Q0	A0	\N	review	12	5	2026-08-21 07:00:13.129	3	12	3	0	2026-08-09 07:00:13.129	2026-08-12 07:00:13.136	2026-08-12 07:00:13.136
cmspqp5c60009vkwwahym3su6	cmspqp5640003vkwwa5z4nlzy	cmsevaz4j0000vkmkl9u1habf	Q1	A1	\N	review	12	5	2026-08-21 07:00:13.129	3	12	3	0	2026-08-09 07:00:13.129	2026-08-12 07:00:13.254	2026-08-12 07:00:13.254
cmspqp5dc000dvkww99u19veh	cmspqp5640003vkwwa5z4nlzy	cmsevaz4j0000vkmkl9u1habf	Q2	A2	\N	review	12	5	2026-08-21 07:00:13.129	3	12	3	0	2026-08-09 07:00:13.129	2026-08-12 07:00:13.297	2026-08-12 07:00:13.297
cmspqp5e9000hvkwwv64lnzkt	cmspqp5640003vkwwa5z4nlzy	cmsevaz4j0000vkmkl9u1habf	Q3	A3	\N	review	12	5	2026-08-21 07:00:13.129	3	12	3	0	2026-08-09 07:00:13.129	2026-08-12 07:00:13.329	2026-08-12 07:00:13.329
\.


--
-- Data for Name: coach_profiles; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.coach_profiles (id, "userId", pace, difficulty, "sessionMinutes", method, rationale, "paceOverride", "difficultyOverride", "sessionMinutesOverride", "methodOverride", "createdAt", "updatedAt") FROM stdin;
cmspstkue001pvkwo7fgytdkg	cmsezu9gz000ivks8r8x63ms4	gentle	beginner	20	mixed	{"pace": "You're finding this hard right now, so I'll slow the pace and consolidate.", "method": "A mix of explanation and practice suits your current level.", "difficulty": "Your average mastery is 0% — let's rebuild the basics first.", "sessionMinutes": "Starting at 20 min until I learn your rhythm."}	\N	\N	\N	\N	2026-08-12 07:59:39.206	2026-08-12 07:59:39.206
cmspj6yaq000bvkrsa07lrou6	cmsevaz4j0000vkmkl9u1habf	gentle	beginner	20	practice	{"pace": "You're finding this hard right now, so I'll slow the pace and consolidate.", "method": "Your exercises are landing at 0% — more practice will fix that.", "difficulty": "Your average mastery is 49% — let's rebuild the basics first.", "sessionMinutes": "Starting at 20 min until I learn your rhythm."}	\N	\N	\N	\N	2026-08-12 03:30:07.01	2026-08-12 08:00:48.89
\.


--
-- Data for Name: collections; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.collections (id, "userId", name, "createdAt") FROM stdin;
\.


--
-- Data for Name: concept_cards; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.concept_cards (id, "conceptId", "cardId", "createdAt") FROM stdin;
cmsf6zmsv0013vk3cywkpf5yr	cmsf3anso002cvki8fyqh7d9a	cmsf6yzmd000nvk3chyeyxp7w	2026-08-04 21:50:48.366
cmsf6znwf001avk3c4qfwrxp1	cmsf3anso002cvki8fyqh7d9a	cmsf6yzme000pvk3c29xin0kh	2026-08-04 21:50:49.791
cmsf6zo3g001cvk3c8uuewcsl	cmsf3anso002cvki8fyqh7d9a	cmsf6yzmg000rvk3caizlugx5	2026-08-04 21:50:50.044
cmsf6zo5b001evk3c4wi0br5a	cmsf3anso002cvki8fyqh7d9a	cmsf6yzmg000tvk3cm4c597xp	2026-08-04 21:50:50.111
cmsf6zobu001gvk3cvj2fnnt3	cmsf3anso002cvki8fyqh7d9a	cmsf6yzmh000vvk3cxoogzmtm	2026-08-04 21:50:50.347
cmsf6zohb001ivk3cw4frqvie	cmsf3anso002cvki8fyqh7d9a	cmsf6yzml000xvk3cxvrb5gq6	2026-08-04 21:50:50.544
cmsf6zoj3001kvk3cr1ger4kn	cmsf3anso002cvki8fyqh7d9a	cmsf6yzml000zvk3c783jnhnd	2026-08-04 21:50:50.608
cmsf6zol0001mvk3cet9elgyx	cmsf3anso002cvki8fyqh7d9a	cmsf6yzmm0011vk3cregtucaz	2026-08-04 21:50:50.676
cmsfanmit003pvk3c7abyf6a6	cmsf3anso002cvki8fyqh7d9a	cmsfankd20034vk3c1tjkot65	2026-08-04 23:33:26.598
cmsfann0w003rvk3c6au2d3gq	cmsf3anso002cvki8fyqh7d9a	cmsfankd20036vk3cagyszqzh	2026-08-04 23:33:27.248
cmsfano21003tvk3cqku3m2p6	cmsf3anso002cvki8fyqh7d9a	cmsfankd30038vk3crgjii4oa	2026-08-04 23:33:28.585
cmsfanoyf003vvk3cutgbgi0t	cmsf3anso002cvki8fyqh7d9a	cmsfankd3003avk3cehcoy9qh	2026-08-04 23:33:29.751
cmsfanq7a003xvk3crdxltwh0	cmsf3anso002cvki8fyqh7d9a	cmsfankd4003cvk3ck4xbo2e7	2026-08-04 23:33:31.366
cmsfanrif0045vk3cr2wba5jq	cmsf3anso002cvki8fyqh7d9a	cmsfankd4003evk3cg1r44lov	2026-08-04 23:33:33.063
cmsfanrq9004dvk3c9no2pf1s	cmsf3anso002cvki8fyqh7d9a	cmsfankd4003gvk3c84u8mvhz	2026-08-04 23:33:33.345
cmsfansj4004pvk3c1s1gswef	cmsf3anso002cvki8fyqh7d9a	cmsfankd5003ivk3cotz9o9ny	2026-08-04 23:33:34.384
cmspgij8s0017vk5s1gvs6x1t	cmspfogm0000fvk90shxxit2z	cmspghqnj000tvk5s75xonst7	2026-08-12 02:15:08.504
cmspgiqkr001bvk5s571r7qhd	cmspfogm0000fvk90shxxit2z	cmspghqnj000vvk5s4v46m4jp	2026-08-12 02:15:18.027
cmspgirsk001dvk5sr09y6q1w	cmspfogm0000fvk90shxxit2z	cmspghqnk000xvk5s455kyvh7	2026-08-12 02:15:19.605
cmspgit33001fvk5savz71jt3	cmspfogm0000fvk90shxxit2z	cmspghqnl000zvk5sm2lm58o7	2026-08-12 02:15:21.279
cmspgiudc001hvk5sp60338zn	cmspfogm0000fvk90shxxit2z	cmspghqnm0011vk5s2qshr6ko	2026-08-12 02:15:22.945
cmspgivcz001jvk5sfesm2pao	cmspfogm0000fvk90shxxit2z	cmspghqnm0013vk5siu969t0q	2026-08-12 02:15:24.227
cmspgivmn001lvk5sqvxo2th7	cmspfogm0000fvk90shxxit2z	cmspghqnn0015vk5sx23ayge9	2026-08-12 02:15:24.575
cmspqp5ap0007vkwweipsfast	cmspqp5110001vkww9etn0r1h	cmspqp58w0005vkwwgc1okx7s	2026-08-12 07:00:13.202
cmspqp5cm000bvkww4qhpjxs8	cmspqp5110001vkww9etn0r1h	cmspqp5c60009vkwwahym3su6	2026-08-12 07:00:13.271
cmspqp5du000fvkww4sc9g0tu	cmspqp5110001vkww9etn0r1h	cmspqp5dc000dvkww99u19veh	2026-08-12 07:00:13.315
cmspqp5ff000jvkwwoh977c99	cmspqp5110001vkww9etn0r1h	cmspqp5e9000hvkwwv64lnzkt	2026-08-12 07:00:13.371
\.


--
-- Data for Name: concept_documents; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.concept_documents (id, "conceptId", "documentId", "createdAt") FROM stdin;
cmsf3ant2002evki88ul8jbjq	cmsf3anso002cvki8fyqh7d9a	cmsf3ajph001lvki88j6p72vk	2026-08-04 20:07:24.423
cmsf3anu1002ivki81zg6m40u	cmsf3antt002gvki88s5epfrw	cmsf3ajph001lvki88j6p72vk	2026-08-04 20:07:24.457
cmsf3anuj002mvki8ss8wdz5e	cmsf3anuc002kvki8rkd8hlz2	cmsf3ajph001lvki88j6p72vk	2026-08-04 20:07:24.475
cmsf3anv1002qvki8py60g1rx	cmsf3anuu002ovki8oozw4y9w	cmsf3ajph001lvki88j6p72vk	2026-08-04 20:07:24.493
cmsf3anvk002uvki8tbwj02ax	cmsf3anvd002svki8m71yj7py	cmsf3ajph001lvki88j6p72vk	2026-08-04 20:07:24.512
cmsf3anw2002yvki80ycjjl4f	cmsf3anvv002wvki8oj6nyb19	cmsf3ajph001lvki88j6p72vk	2026-08-04 20:07:24.53
cmsf6zomt001ovk3c1u432yyk	cmsf3anso002cvki8fyqh7d9a	cmsf6ye63000jvk3cz7d814bi	2026-08-04 21:50:50.741
cmsf6zpbb001yvk3czeffpykk	cmsf6zpac001wvk3cr4bch5is	cmsf6ye63000jvk3cz7d814bi	2026-08-04 21:50:51.623
cmsf6zpda0020vk3cotk8dmwg	cmsf3anuc002kvki8rkd8hlz2	cmsf6ye63000jvk3cz7d814bi	2026-08-04 21:50:51.694
cmsf6zph30024vk3cmxdkdx9i	cmsf6zpg10022vk3cbgawbp6s	cmsf6ye63000jvk3cz7d814bi	2026-08-04 21:50:51.832
cmsf6zphs0026vk3c9xtb9kgd	cmsf3anuu002ovki8oozw4y9w	cmsf6ye63000jvk3cz7d814bi	2026-08-04 21:50:51.856
cmsf6zpir002avk3cseqv3j30	cmsf6zpig0028vk3c84xucl0v	cmsf6ye63000jvk3cz7d814bi	2026-08-04 21:50:51.891
cmsfanqhe003zvk3cp3vgc75z	cmsf3anso002cvki8fyqh7d9a	cmsfane250030vk3ckp0grfpq	2026-08-04 23:33:31.73
cmsfanr1a0041vk3crguy4c8s	cmsf6zpac001wvk3cr4bch5is	cmsfane250030vk3ckp0grfpq	2026-08-04 23:33:32.446
cmsfanr9a0043vk3c7dt2sj85	cmsf3anuc002kvki8rkd8hlz2	cmsfane250030vk3ckp0grfpq	2026-08-04 23:33:32.734
cmsfanrlq0049vk3c6r27q50o	cmsfanrii0047vk3ckjquqk7x	cmsfane250030vk3ckp0grfpq	2026-08-04 23:33:33.182
cmsfanro8004bvk3crkbc7d4b	cmsf6zpig0028vk3c84xucl0v	cmsfane250030vk3ckp0grfpq	2026-08-04 23:33:33.273
cmsfanrz5004hvk3clxtuts6e	cmsfanrtz004fvk3cmge0u8cx	cmsfane250030vk3ckp0grfpq	2026-08-04 23:33:33.666
cmspgiy51001nvk5siy0ik2i9	cmspfogm0000fvk90shxxit2z	cmspgh6nb000nvk5sqpah351q	2026-08-12 02:15:27.829
cmsq2wdtm000rvksw291o7jgy	cmsq2wdt0000pvkswrxgr6v29	cmsq2w7uv000hvkswmabo5p9j	2026-08-12 12:41:46.235
cmsq2wdtq000tvksw2opcbnnu	cmsq2wdsz000nvksw2moxb1f1	cmsq2w7a5000dvkswdndm9jrd	2026-08-12 12:41:46.239
cmsq2wdvj000xvkswa1qkytbh	cmsq2wdv2000vvkswi5kawc49	cmsq2w7a5000dvkswdndm9jrd	2026-08-12 12:41:46.303
cmsq2we680013vksw7xzkt2g7	cmsq2wdsz000nvksw2moxb1f1	cmsq2w6lt000bvksw2opmvb9a	2026-08-12 12:41:46.689
cmsq2we7i0015vkswzh72kafr	cmsq2we680011vksw3uf5l437	cmsq2w7hj000fvkswpw0zk6m4	2026-08-12 12:41:46.732
cmsq2we8i001bvkswfbon119z	cmsq2we7n0017vksw1blvak9c	cmsq2w6lt000bvksw2opmvb9a	2026-08-12 12:41:46.77
\.


--
-- Data for Name: concept_edges; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.concept_edges (id, "userId", "sourceId", "targetId", relation, "createdAt") FROM stdin;
cmsf3anw90030vki84utgv5j8	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf3antt002gvki88s5epfrw	prerequisite	2026-08-04 20:07:24.537
cmsf3anws0032vki8axuqza6p	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf3anuc002kvki8rkd8hlz2	prerequisite	2026-08-04 20:07:24.556
cmsf3anwy0034vki88faa218e	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf3anuu002ovki8oozw4y9w	prerequisite	2026-08-04 20:07:24.562
cmsf3anx50036vki8gzjjco89	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf3anvd002svki8m71yj7py	prerequisite	2026-08-04 20:07:24.569
cmsf3anxc0038vki801j1px1s	cmsezu9gz000ivks8r8x63ms4	cmsf3anuu002ovki8oozw4y9w	cmsf3anvd002svki8m71yj7py	prerequisite	2026-08-04 20:07:24.577
cmsf3anxj003avki8y713ed2i	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf3anvv002wvki8oj6nyb19	prerequisite	2026-08-04 20:07:24.583
cmsf6zpj9002cvk3cbcw85mzo	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf6zpac001wvk3cr4bch5is	prerequisite	2026-08-04 21:50:51.909
cmsf6zpk6002gvk3ckb73ko3m	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf6zpg10022vk3cbgawbp6s	prerequisite	2026-08-04 21:50:51.942
cmsf6zpkl002ivk3ct28cm98k	cmsezu9gz000ivks8r8x63ms4	cmsf6zpg10022vk3cbgawbp6s	cmsf3anuu002ovki8oozw4y9w	prerequisite	2026-08-04 21:50:51.957
cmsf6zpky002kvk3cjkowk5r6	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf6zpig0028vk3c84xucl0v	prerequisite	2026-08-04 21:50:51.97
cmsf6zqr8002mvk3cbmyujy2z	cmsezu9gz000ivks8r8x63ms4	cmsf3antt002gvki88s5epfrw	cmsf6zpac001wvk3cr4bch5is	related	2026-08-04 21:50:53.493
cmsf6zqsi002ovk3cex75ufsf	cmsezu9gz000ivks8r8x63ms4	cmsf3anvd002svki8m71yj7py	cmsf6zpg10022vk3cbgawbp6s	related	2026-08-04 21:50:53.539
cmsf6zqt3002qvk3c5isqlhes	cmsezu9gz000ivks8r8x63ms4	cmsf3anvv002wvki8oj6nyb19	cmsf6zpig0028vk3c84xucl0v	related	2026-08-04 21:50:53.56
cmsfansi7004nvk3c0r9csutw	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsfanrii0047vk3ckjquqk7x	prerequisite	2026-08-04 23:33:34.351
cmsfansjx004rvk3cxm0b2xzx	cmsezu9gz000ivks8r8x63ms4	cmsf3anuc002kvki8rkd8hlz2	cmsfanrii0047vk3ckjquqk7x	prerequisite	2026-08-04 23:33:34.414
cmsfansnp004vvk3c5dv87voq	cmsezu9gz000ivks8r8x63ms4	cmsf3anuc002kvki8rkd8hlz2	cmsfanrtz004fvk3cmge0u8cx	prerequisite	2026-08-04 23:33:34.549
cmsfanx680055vk3cclhbr5fu	cmsezu9gz000ivks8r8x63ms4	cmsf3anvd002svki8m71yj7py	cmsfanrii0047vk3ckjquqk7x	related	2026-08-04 23:33:40.401
cmsfanxc90057vk3c2jpgc1a6	cmsezu9gz000ivks8r8x63ms4	cmsf3anuu002ovki8oozw4y9w	cmsfanrii0047vk3ckjquqk7x	prerequisite	2026-08-04 23:33:40.618
cmsq2wdw4000zvkswwx262dt7	cmsevaz4j0000vkmkl9u1habf	cmsq2wdsz000nvksw2moxb1f1	cmsq2wdv2000vvkswi5kawc49	prerequisite	2026-08-12 12:41:46.323
cmsq2weao001dvkswdcw6urw1	cmsevaz4j0000vkmkl9u1habf	cmsq2wdsz000nvksw2moxb1f1	cmsq2we7n0017vksw1blvak9c	prerequisite	2026-08-12 12:41:46.848
cmsq2weq4001fvkswz18rgqkv	cmsevaz4j0000vkmkl9u1habf	cmsq2wdt0000pvkswrxgr6v29	cmsq2wdv2000vvkswi5kawc49	related	2026-08-12 12:41:47.404
cmsq2weqg001hvkswb0cfuszf	cmsevaz4j0000vkmkl9u1habf	cmsq2wdv2000vvkswi5kawc49	cmsq2wdt0000pvkswrxgr6v29	related	2026-08-12 12:41:47.417
cmsq2wfgq001jvkswqxu62l7g	cmsevaz4j0000vkmkl9u1habf	cmsq2wdv2000vvkswi5kawc49	cmsq2we7n0017vksw1blvak9c	prerequisite	2026-08-12 12:41:48.362
cmsq2wfh8001lvkswu4ev28u0	cmsevaz4j0000vkmkl9u1habf	cmsq2wdt0000pvkswrxgr6v29	cmsq2we7n0017vksw1blvak9c	prerequisite	2026-08-12 12:41:48.381
cmsq2wfhg001nvkswafqwet28	cmsevaz4j0000vkmkl9u1habf	cmsq2we680011vksw3uf5l437	cmsq2wdsz000nvksw2moxb1f1	related	2026-08-12 12:41:48.388
\.


--
-- Data for Name: concepts; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.concepts (id, "userId", name, "normalizedName", description, "createdAt", "updatedAt") FROM stdin;
cmsf3anso002cvki8fyqh7d9a	cmsezu9gz000ivks8r8x63ms4	Conversation Fundamentals	conversation fundamentals	Conversation is a two-way exchange of thoughts, feelings, and ideas that serves as the foundation of human connection.	2026-08-04 20:07:24.408	2026-08-04 20:07:24.408
cmsf3antt002gvki88s5epfrw	cmsezu9gz000ivks8r8x63ms4	Conversation Initiation	conversation initiation	The process of breaking the ice using low-stakes observations, situational remarks, or open-ended prompts.	2026-08-04 20:07:24.45	2026-08-04 20:07:24.45
cmsf3anuc002kvki8rkd8hlz2	cmsezu9gz000ivks8r8x63ms4	Active Listening	active listening	The practice of giving full attention, validating feelings, using verbal affirmations, and listening to understand rather than to reply.	2026-08-04 20:07:24.468	2026-08-04 20:07:24.468
cmsf3anuu002ovki8oozw4y9w	cmsezu9gz000ivks8r8x63ms4	Open-Ended Questions	open-ended questions	Questions starting with What, How, or Why that invite deeper sharing and keep a conversation flowing.	2026-08-04 20:07:24.486	2026-08-04 20:07:24.486
cmsf3anvd002svki8m71yj7py	cmsezu9gz000ivks8r8x63ms4	Conversation Pacing	conversation pacing	Balancing speaking and listening like a tennis match so that neither person dominates the exchange.	2026-08-04 20:07:24.505	2026-08-04 20:07:24.505
cmsf3anvv002wvki8oj6nyb19	cmsezu9gz000ivks8r8x63ms4	Graceful Conclusion	graceful conclusion	The art of wrapping up an interaction by acknowledging enjoyment, giving a reason to leave, and setting the stage for future contact.	2026-08-04 20:07:24.523	2026-08-04 20:07:24.523
cmsf6zpac001wvk3cr4bch5is	cmsezu9gz000ivks8r8x63ms4	Initiation	initiation	Breaking the ice at the start of a conversation using low-stakes observations, situational remarks, or open-ended prompts.	2026-08-04 21:50:51.588	2026-08-04 21:50:51.588
cmsf6zpg10022vk3cbgawbp6s	cmsezu9gz000ivks8r8x63ms4	Elaboration and Pacing	elaboration and pacing	Keeping the conversation flowing like a tennis match by balancing talking and listening.	2026-08-04 21:50:51.793	2026-08-04 21:50:51.793
cmsf6zpig0028vk3c84xucl0v	cmsezu9gz000ivks8r8x63ms4	Conclusion	conclusion	Gracefully wrapping up an interaction by acknowledging enjoyment, giving a reason for leaving, and setting the stage for future contact.	2026-08-04 21:50:51.88	2026-08-04 21:50:51.88
cmsfanrii0047vk3ckjquqk7x	cmsezu9gz000ivks8r8x63ms4	Pacing and Questioning	pacing and questioning	The third pillar involves balancing speaking and listening while utilizing What, How, and Why questions to maintain dialogue flow.	2026-08-04 23:33:33.066	2026-08-04 23:33:33.066
cmsfanrtz004fvk3cmge0u8cx	cmsezu9gz000ivks8r8x63ms4	The Golden Rule	the golden rule	The core principle of conversation stating that one should listen to understand rather than to reply.	2026-08-04 23:33:33.479	2026-08-04 23:33:33.479
cmspfofg0000dvk9020iq1q49	cmsevaz4j0000vkmkl9u1habf	Les fonctions	les fonctions	\N	2026-08-12 01:51:43.92	2026-08-12 01:51:43.92
cmspfogm0000fvk90shxxit2z	cmsevaz4j0000vkmkl9u1habf	Les derivees	les derivees	\N	2026-08-12 01:51:45.432	2026-08-12 01:51:45.432
cmspqp5110001vkww9etn0r1h	cmsevaz4j0000vkmkl9u1habf	Biologie	biologie	\N	2026-08-12 07:00:12.853	2026-08-12 07:00:12.853
cmsq2wdt0000pvkswrxgr6v29	cmsevaz4j0000vkmkl9u1habf	Doc pagination 4	doc pagination 4	Test content number 4 designated for pagination purposes.	2026-08-12 12:41:46.207	2026-08-12 12:41:46.207
cmsq2wdsz000nvksw2moxb1f1	cmsevaz4j0000vkmkl9u1habf	Test Content	test content	Sample text used for evaluating document features like pagination.	2026-08-12 12:41:46.207	2026-08-12 12:41:46.207
cmsq2wdv2000vvkswi5kawc49	cmsevaz4j0000vkmkl9u1habf	Document Pagination	document pagination	The process of dividing content across multiple pages.	2026-08-12 12:41:46.286	2026-08-12 12:41:46.286
cmsq2we680011vksw3uf5l437	cmsevaz4j0000vkmkl9u1habf	Test Content Three	test content three	Specific test content designated by the number three for pagination evaluation.	2026-08-12 12:41:46.688	2026-08-12 12:41:46.688
cmsq2we7n0017vksw1blvak9c	cmsevaz4j0000vkmkl9u1habf	Pagination Testing	pagination testing	The process of evaluating how content is divided across multiple pages.	2026-08-12 12:41:46.739	2026-08-12 12:41:46.739
\.


--
-- Data for Name: consents; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.consents (id, "userId", key, granted, "createdAt", "updatedAt") FROM stdin;
\.


--
-- Data for Name: daily_plan_items; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.daily_plan_items (id, "planId", slot, kind, title, detail, status, "position", "targetCount", "conceptId", "deckId", "languageProfileId", "completedAt", "createdAt") FROM stdin;
cmsgkm67i0014vkoothfh05kz	cmsfgslz4005xvk3cxfeocm8w	morning	review	Review 24 due cards	Yesterday’s material is coming back — clear the queue first.	pending	0	24	\N	\N	\N	\N	2026-08-05 21:00:01.133
cmsgkm67k0015vkoomucj4zp1	cmsfgslz4005xvk3cxfeocm8w	afternoon	lesson	New lesson: Conversation Fundamentals	Prerequisites are mastered — this is the right next step.	pending	1	\N	cmsf3anso002cvki8fyqh7d9a	\N	\N	\N	2026-08-05 21:00:01.133
cmsgkm67k0016vkoo3qkugmp0	cmsfgslz4005xvk3cxfeocm8w	night	quick_revision	Quick revision — 10 cards	A short pass before sleep locks the day in.	pending	2	10	\N	\N	\N	\N	2026-08-05 21:00:01.133
cmsjfhvi10021vkxkhsz5tkvq	cmsib1jrb000rvk5glyoicc0h	morning	review	Review 24 due cards	Yesterday’s material is coming back — clear the queue first.	pending	0	24	\N	\N	\N	\N	2026-08-07 21:00:01.081
cmsjfhvi10022vkxke5czhsl7	cmsib1jrb000rvk5glyoicc0h	afternoon	lesson	New lesson: Conversation Fundamentals	Prerequisites are mastered — this is the right next step.	pending	1	\N	cmsf3anso002cvki8fyqh7d9a	\N	\N	\N	2026-08-07 21:00:01.081
cmsjfhvi10023vkxkb4i1wf18	cmsib1jrb000rvk5glyoicc0h	night	quick_revision	Quick revision — 10 cards	A short pass before sleep locks the day in.	pending	2	10	\N	\N	\N	\N	2026-08-07 21:00:01.081
cmsowba4c000jvk88cs5af5ci	cmsowba4a000hvk88dm80dcpm	morning	review	Review 24 due cards	Yesterday’s material is coming back — clear the queue first.	pending	0	24	\N	\N	\N	\N	2026-08-11 16:49:37.766
cmsowba4c000kvk882l4vkohi	cmsowba4a000hvk88dm80dcpm	afternoon	lesson	New lesson: Conversation Fundamentals	Prerequisites are mastered — this is the right next step.	pending	1	\N	cmsf3anso002cvki8fyqh7d9a	\N	\N	\N	2026-08-11 16:49:37.766
cmsowba4c000lvk88b1d2q95k	cmsowba4a000hvk88dm80dcpm	night	quick_revision	Quick revision — 10 cards	A short pass before sleep locks the day in.	pending	2	10	\N	\N	\N	\N	2026-08-11 16:49:37.766
cmsqkp6dg0028vkognyg3m24h	cmspg6zox000dvk5s2jg68ldb	morning	review	Review 8 due cards	Yesterday’s material is coming back — clear the queue first.	pending	0	8	\N	\N	\N	\N	2026-08-12 21:00:03.075
cmsqkp6dg0029vkogja15sscj	cmspg6zox000dvk5s2jg68ldb	afternoon	lesson	New lesson: Les derivees	Prerequisites are mastered — this is the right next step.	pending	1	\N	cmspfogm0000fvk90shxxit2z	\N	\N	\N	2026-08-12 21:00:03.075
cmsqkp6dg002avkogeigbr2sx	cmspg6zox000dvk5s2jg68ldb	night	quick_revision	Quick revision — 8 cards	A short pass before sleep locks the day in.	pending	2	8	\N	\N	\N	\N	2026-08-12 21:00:03.075
cmsqkp7lh002dvkogo2c00cur	cmspqoz5z000cvkbwd5ndxfcu	morning	review	Review 24 due cards	Yesterday’s material is coming back — clear the queue first.	pending	0	24	\N	\N	\N	\N	2026-08-12 21:00:04.661
cmsqkp7lh002evkog9erdyfbi	cmspqoz5z000cvkbwd5ndxfcu	afternoon	lesson	New lesson: Conversation Fundamentals	Prerequisites are mastered — this is the right next step.	pending	1	\N	cmsf3anso002cvki8fyqh7d9a	\N	\N	\N	2026-08-12 21:00:04.661
cmsqkp7lh002fvkog5dmcqi8p	cmspqoz5z000cvkbwd5ndxfcu	night	quick_revision	Quick revision — 10 cards	A short pass before sleep locks the day in.	pending	2	10	\N	\N	\N	\N	2026-08-12 21:00:04.661
cmsr92t4k0035vkog3eihtpn4	cmsr92t4j0033vkog6je1hc49	morning	review	Review 24 due cards	Yesterday’s material is coming back — clear the queue first.	pending	0	24	\N	\N	\N	\N	2026-08-13 08:22:29.875
cmsr92t4k0036vkogzhntry7x	cmsr92t4j0033vkog6je1hc49	afternoon	lesson	New lesson: Conversation Fundamentals	Prerequisites are mastered — this is the right next step.	pending	1	\N	cmsf3anso002cvki8fyqh7d9a	\N	\N	\N	2026-08-13 08:22:29.875
cmsr92t4k0037vkog7cwr5156	cmsr92t4j0033vkog6je1hc49	night	quick_revision	Quick revision — 10 cards	A short pass before sleep locks the day in.	pending	2	10	\N	\N	\N	\N	2026-08-13 08:22:29.875
\.


--
-- Data for Name: daily_plans; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.daily_plans (id, "userId", date, timezone, "generatedAt", "updatedAt") FROM stdin;
cmsf0vzcm000bvkwctc6n461k	cmsevaz4j0000vkmkl9u1habf	2026-08-04	UTC	2026-08-04 19:00:00.31	2026-08-04 19:00:00.31
cmsezuefq000pvks8qrlk774d	cmsezu9gz000ivks8r8x63ms4	2026-08-04	UTC	2026-08-04 18:30:46.933	2026-08-04 19:00:00.556
cmsfqlxas000pvk94jtyxd5ei	cmsevaz4j0000vkmkl9u1habf	2026-08-05	UTC	2026-08-05 07:00:01.107	2026-08-05 21:00:00.835
cmsfgslz4005xvk3cxfeocm8w	cmsezu9gz000ivks8r8x63ms4	2026-08-05	UTC	2026-08-05 02:25:16.863	2026-08-05 21:00:01.149
cmsjfhv9h0020vkxkw2rk16r9	cmsevaz4j0000vkmkl9u1habf	2026-08-07	UTC	2026-08-07 21:00:00.77	2026-08-07 21:00:00.77
cmsib1jrb000rvk5glyoicc0h	cmsezu9gz000ivks8r8x63ms4	2026-08-07	UTC	2026-08-07 02:07:34.727	2026-08-07 21:00:01.091
cmsjfhvvl0027vkxksww9ptia	cmsibrdj40008vkg88ef4wjk3	2026-08-07	UTC	2026-08-07 21:00:01.569	2026-08-07 21:00:01.569
cmsjfhwhr0029vkxka0iz9mjo	cmsibrdyu000evkg8o2smybwc	2026-08-07	UTC	2026-08-07 21:00:02.367	2026-08-07 21:00:02.367
cmsowba4a000hvk88dm80dcpm	cmsezu9gz000ivks8r8x63ms4	2026-08-11	UTC	2026-08-11 16:49:37.766	2026-08-11 16:49:37.766
cmspg6zox000dvk5s2jg68ldb	cmsevaz4j0000vkmkl9u1habf	2026-08-12	UTC	2026-08-12 02:06:09.968	2026-08-12 21:00:03.356
cmspqoz5z000cvkbwd5ndxfcu	cmsezu9gz000ivks8r8x63ms4	2026-08-12	UTC	2026-08-12 07:00:05.256	2026-08-12 21:00:04.703
cmspqozbg000kvkbw8z2l4rzq	cmsibrdj40008vkg88ef4wjk3	2026-08-12	UTC	2026-08-12 07:00:05.452	2026-08-12 21:00:06.064
cmspqozfo000mvkbwuv7scpne	cmsibrdyu000evkg8o2smybwc	2026-08-12	UTC	2026-08-12 07:00:05.605	2026-08-12 21:00:06.773
cmsr92t4j0033vkog6je1hc49	cmsezu9gz000ivks8r8x63ms4	2026-08-13	UTC	2026-08-13 08:22:29.875	2026-08-13 08:22:29.875
\.


--
-- Data for Name: decks; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.decks (id, "userId", name, description, "createdAt", "updatedAt") FROM stdin;
cmsevbo5i000bvkmkjo7hvew2	cmsevaz4j0000vkmkl9u1habf	Vocabulary — Francais	Vocabulary for Francais, reviewed with FSRS.	2026-08-04 16:24:14.598	2026-08-04 16:24:14.598
cmsf1w4mg0003vki8jj8zbuyr	cmsevaz4j0000vkmkl9u1habf	Vocabulary — Italian	Vocabulary for Italian, reviewed with FSRS.	2026-08-04 19:28:06.761	2026-08-04 19:28:06.761
cmsf3ajwj001nvki8cgxklxiv	cmsezu9gz000ivks8r8x63ms4	Lesson — Conversation	Generated from a document.	2026-08-04 20:07:19.363	2026-08-04 20:07:19.363
cmsf6ygfr000lvk3cey3li03v	cmsezu9gz000ivks8r8x63ms4	Lesson — Conversation Fundamentals	Generated from a document.	2026-08-04 21:49:53.462	2026-08-04 21:49:53.462
cmsfanfd00032vk3c479zfaxk	cmsezu9gz000ivks8r8x63ms4	Lesson — Conversation Fundamentals	Generated from a document.	2026-08-04 23:33:17.316	2026-08-04 23:33:17.316
cmspghlp2000pvk5swkmrojut	cmsevaz4j0000vkmkl9u1habf	Lesson — Les derivees	Generated from a document.	2026-08-12 02:14:25.046	2026-08-12 02:14:25.046
cmspqp5640003vkwwa5z4nlzy	cmsevaz4j0000vkmkl9u1habf	Bio deck	\N	2026-08-12 07:00:13.036	2026-08-12 07:00:13.036
cmsqinw3y0023vkogff97hmn8	cmsezu9gz000ivks8r8x63ms4	Vocabulary — Anglais	Vocabulary for Anglais, reviewed with FSRS.	2026-08-12 20:03:03.885	2026-08-12 20:03:03.885
cmsql8pd7002lvkogimh90qsi	cmsezu9gz000ivks8r8x63ms4	Vocabulary — Espagnol	Vocabulary for Espagnol, reviewed with FSRS.	2026-08-12 21:15:14.155	2026-08-12 21:15:14.155
cmsqo82ho002rvkogfy9qhy26	cmsezu9gz000ivks8r8x63ms4	Vocabulary — Japonais	Vocabulary for Japonais, reviewed with FSRS.	2026-08-12 22:38:43.356	2026-08-12 22:38:43.356
cmsqocar0002vvkogors46bj9	cmsezu9gz000ivks8r8x63ms4	Vocabulary — Portugais	Vocabulary for Portugais, reviewed with FSRS.	2026-08-12 22:42:00.684	2026-08-12 22:42:00.684
\.


--
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.document_chunks (id, "documentId", "userId", "chunkIndex", content, "vectorId", "createdAt") FROM stdin;
cmsf3alux001ovki863lh4c5z	cmsf3ajph001lvki88j6p72vk	cmsezu9gz000ivks8r8x63ms4	0	# Conversation\n\nObjective: By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.\n\nConversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.\n\n## Explanation At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended	21288d03-4a66-4bdf-a518-72ab32a137ad	2026-08-04 20:07:21.896
cmsf3alux001pvki88t6olggz	cmsf3ajph001lvki88j6p72vk	cmsezu9gz000ivks8r8x63ms4	1	ng the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended questions. Instead of asking 'How are you?' (which often prompts a rote 'Fine'), try asking 'What has been the highlight of your week so far?'\n\n2. **Active Listening (Receiving the Message):** Most people listen with the intent to reply rather than the intent to understand. Active listening involves giving your full attention, nodding, using verbal affirmations ('I see', 'Go on'), and avoiding the temptation to interrupt or hijack the story with your own experiences.\n\n3. **Elaboration and Pacing (Keeping it Flowing):** A good conversation flows like a tennis match, not a monologue. Use open-ended questions (questions starting with What, How, or Why) to invite the other person to share more. Balance talking and listening so neither person dominates.\n\n4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up a conversation	556d1ae0-1fee-42a1-bf9b-80d056546b61	2026-08-04 20:07:21.896
cmsf3alux001qvki8yfk3q03j	cmsf3ajph001lvki88j6p72vk	cmsezu9gz000ivks8r8x63ms4	2	e. Balance talking and listening so neither person dominates.\n\n4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up a conversation is just as important as starting it. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and, if appropriate, sets the stage for future interaction.\n\n## Examples Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'\n\nActive listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'\n\nConcluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'\n\n## Questions Why do you think open-ended	008d0539-c699-42cd-8c4c-78512904795a	2026-08-04 20:07:21.896
cmsf3alux001rvki8f608kcrc	cmsf3ajph001lvki88j6p72vk	cmsezu9gz000ivks8r8x63ms4	3	up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'\n\n## Questions Why do you think open-ended questions are more effective at keeping a conversation alive than closed-ended questions (questions answered with a simple yes or no)? What is the difference between hearing someone speak and actively listening to them? How can body language and non-verbal cues influence the tone of a conversation? What are some polite ways to steer a conversation back on track if it becomes uncomfortable or repetitive?\n\n## Key takeaways - Conversations require a balanced exchange of speaking and listening, much like a tennis match. - Active listening involves paying full attention, validating feelings, and avoiding premature interruptions. - Open-ended questions starting with What, How, or Why help keep a conversation engaging and flowing. - Knowing how to gracefully conclude a interaction leaves a lasting positive impression.\n\n## Summary Conversations	da925fdf-efbf-4316-a63a-5d0a54cae703	2026-08-04 20:07:21.896
cmsf3alux001svki8c1a31fb1	cmsf3ajph001lvki88j6p72vk	cmsezu9gz000ivks8r8x63ms4	4	conversation engaging and flowing. - Knowing how to gracefully conclude a interaction leaves a lasting positive impression.\n\n## Summary Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.\n\n## Revision sheet CONVERSATION REVISION SHEET:\n\n- Definition: A two-way exchange of thoughts and ideas.\n\n- Four Pillars: 1. Initiation: Break the ice using situational context or open-ended prompts. 2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking. 3. Pacing: Balance speaking and listening; use What/How/Why questions. 4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact.\n\n- Golden Rule: Listen to understand, not to reply.	f4275e22-adad-416c-a7ec-e9fc48e94735	2026-08-04 20:07:21.896
cmsfanma3003jvk3cnx09rw56	cmsfane250030vk3ckp0grfpq	cmsezu9gz000ivks8r8x63ms4	0	# Conversation Fundamentals\n\nObjective: By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.\n\nConversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.\n\n## Explanation At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks,	9fbb56b0-63b0-470b-9023-2ad75d4c8229	2026-08-04 23:33:26.283
cmsfanma3003kvk3cvcolvft4	cmsfane250030vk3ckp0grfpq	cmsezu9gz000ivks8r8x63ms4	1	iation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended prompts. 2. **Active Listening:** Focus on understanding rather than just waiting for your turn to speak. Use verbal and non-verbal affirmations, and avoid hijacking the conversation with your own stories. 3. **Pacing and Questioning:** Balance speaking and listening so neither person dominates. Use What, How, and Why questions to keep the dialogue engaging and flowing. 4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up an interaction leaves a lasting positive impression. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and sets the stage for future interaction.\n\n**The Golden Rule:** Listen to understand, not to reply.\n\n## Examples Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that	65161423-88a7-4d94-8d4c-2ac107be80ad	2026-08-04 23:33:26.283
cmsfanma3003lvk3cchesxu9w	cmsfane250030vk3ckp0grfpq	cmsezu9gz000ivks8r8x63ms4	2	## Examples Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'\n\nActive listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'\n\nConcluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'\n\n## Questions Why do you think open-ended questions are more effective than closed questions (yes/no questions) for maintaining a conversation? How does the golden rule ('Listen to understand, not to reply') change the way you react when someone is sharing a problem? What makes a situational observation an effective icebreaker compared to a generic greeting?\n\n## Key	ad9ff10d-099d-47db-b7cd-008c5ab0e8da	2026-08-04 23:33:26.283
cmsfanma3003mvk3cdiyqnhpv	cmsfane250030vk3ckp0grfpq	cmsezu9gz000ivks8r8x63ms4	3	way you react when someone is sharing a problem? What makes a situational observation an effective icebreaker compared to a generic greeting?\n\n## Key takeaways - A conversation is a two-way exchange of thoughts, feelings, and ideas. - The four pillars are Initiation, Active Listening, Pacing, and Conclusion. - Active listening means focusing on understanding rather than hijacking the story to talk about yourself. - The golden rule of conversation is: Listen to understand, not to reply.\n\n## Summary Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.\n\n## Revision sheet - Definition: A two-way exchange of thoughts and ideas. - Four Pillars: 1. Initiation: Break the ice using situational context or open-ended prompts. 2. Active	4c60edeb-60df-4eb2-868a-15ba21d86132	2026-08-04 23:33:26.283
cmsfanma3003nvk3c5ytuzcpb	cmsfane250030vk3ckp0grfpq	cmsezu9gz000ivks8r8x63ms4	4	ion: A two-way exchange of thoughts and ideas. - Four Pillars: 1. Initiation: Break the ice using situational context or open-ended prompts. 2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking. 3. Pacing: Balance speaking and listening; use What/How/Why questions. 4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact. - Golden Rule: Listen to understand, not to reply.	6a133842-86b9-4558-b48a-f7a6ea1f799a	2026-08-04 23:33:26.283
cmsq2wctb000jvkswmuditj05	cmsq2w6lt000bvksw2opmvb9a	cmsevaz4j0000vkmkl9u1habf	0	Contenu de test numero 1 pour la pagination.	6d8dbd2b-453e-499d-b7d6-7047c190e717	2026-08-12 12:41:44.925
cmsq2wcs7000ivkswy6z7b5xo	cmsq2w7hj000fvkswpw0zk6m4	cmsevaz4j0000vkmkl9u1habf	0	Contenu de test numero 3 pour la pagination.	3216dd81-6b37-42c9-ba3c-03a1ec86c4a1	2026-08-12 12:41:44.887
cmsq2wcuf000kvkswgdhl70j1	cmsq2w7uv000hvkswmabo5p9j	cmsevaz4j0000vkmkl9u1habf	0	Contenu de test numero 4 pour la pagination.	54af431b-38c6-4f8f-ae98-72115c5fd8d3	2026-08-12 12:41:44.967
cmsq2wcuh000lvkswnvwnij5s	cmsq2w7a5000dvkswdndm9jrd	cmsevaz4j0000vkmkl9u1habf	0	Contenu de test numero 2 pour la pagination.	1e100b38-878f-47fb-91a6-b7638021c2c3	2026-08-12 12:41:44.969
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.documents (id, "userId", title, source, "sourceRef", content, "charCount", status, error, "createdAt", "updatedAt", author, "collectionId", "deletedAt", difficulty, "enrichedAt", "isFavorite", language, subject, summary, stage) FROM stdin;
cmsq2w6lt000bvksw2opmvb9a	cmsevaz4j0000vkmkl9u1habf	Doc pagination 1	text	\N	Contenu de test numero 1 pour la pagination.	44	ready	\N	2026-08-12 12:41:36.624	2026-08-12 12:41:48.406	\N	\N	\N	beginner	2026-08-12 12:41:40.417	f	French	Computer Science	Ce document est un court contenu de test destiné à vérifier le fonctionnement de la pagination. Il s'agit d'un texte simple sans portée académique spécifique.	\N
cmsf6ye63000jvk3cz7d814bi	cmsezu9gz000ivks8r8x63ms4	Lesson — Conversation Fundamentals	text	\N	# Conversation Fundamentals\n\nObjective: By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.\n\nConversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.\n\n## Explanation At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended prompts. Instead of asking 'How are you?' (which often prompts a rote 'Fine'), try asking 'What has been the highlight of your week so far?'\n\n2. **Active Listening (Receiving the Message):** Most people listen with the intent to reply rather than the intent to understand. Active listening involves giving your full attention, nodding, using verbal affirmations ('I see', 'Go on'), and avoiding the temptation to interrupt or hijack the story with your own experiences.\n\n3. **Elaboration and Pacing (Keeping it Flowing):** A good conversation flows like a tennis match, not a monologue. Use open-ended questions (questions starting with What, How, or Why) to invite the other person to share more. Balance talking and listening so neither person dominates.\n\n4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up a conversation is just as important as starting it. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and, if appropriate, sets the stage for future interaction.\n\n## Examples Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'\n\nActive listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'\n\nConcluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'\n\n## Questions Why do you think open-ended questions are more effective at keeping a conversation alive than closed-ended questions (questions answered with a simple yes or no)? What is the difference between hearing someone speak and actively listening to them? How can body language and non-verbal cues influence the tone of a conversation? What are some polite ways to steer a conversation back on track if it becomes uncomfortable or repetitive?\n\n## Key takeaways - Conversations require a balanced exchange of speaking and listening, much like a tennis match. - Active listening involves paying full attention, validating feelings, and avoiding premature interruptions. - Open-ended questions starting with What, How, or Why help keep a conversation engaging and flowing. - Knowing how to gracefully conclude an interaction leaves a lasting positive impression.\n\n## Summary Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.\n\n## Revision sheet CONVERSATION REVISION SHEET:\n\n- Definition: A two-way exchange of thoughts and ideas.\n\n- Four Pillars: 1. Initiation: Break the ice using situational context or open-ended prompts. 2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking. 3. Pacing: Balance speaking and listening; use What/How/Why questions. 4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact.\n\n- Golden Rule: Listen to understand, not to reply.	4366	ready	\N	2026-08-04 21:49:50.521	2026-08-12 14:56:32.374	\N	\N	2026-08-12 14:56:32.371	beginner	2026-08-04 21:49:53.366	f	English	Communication	This lesson teaches the fundamentals of effective conversation across social and professional settings by breaking it down into four core pillars: initiation, active listening, pacing, and graceful conclusion. It emphasizes that good communication is a balanced, two-way exchange focused on genuinely understanding others rather than simply waiting for a turn to speak.	\N
cmsfane250030vk3ckp0grfpq	cmsezu9gz000ivks8r8x63ms4	Lesson — Conversation Fundamentals	text	\N	# Conversation Fundamentals\n\nObjective: By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.\n\nConversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.\n\n## Explanation At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended prompts. 2. **Active Listening:** Focus on understanding rather than just waiting for your turn to speak. Use verbal and non-verbal affirmations, and avoid hijacking the conversation with your own stories. 3. **Pacing and Questioning:** Balance speaking and listening so neither person dominates. Use What, How, and Why questions to keep the dialogue engaging and flowing. 4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up an interaction leaves a lasting positive impression. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and sets the stage for future interaction.\n\n**The Golden Rule:** Listen to understand, not to reply.\n\n## Examples Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'\n\nActive listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'\n\nConcluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'\n\n## Questions Why do you think open-ended questions are more effective than closed questions (yes/no questions) for maintaining a conversation? How does the golden rule ('Listen to understand, not to reply') change the way you react when someone is sharing a problem? What makes a situational observation an effective icebreaker compared to a generic greeting?\n\n## Key takeaways - A conversation is a two-way exchange of thoughts, feelings, and ideas. - The four pillars are Initiation, Active Listening, Pacing, and Conclusion. - Active listening means focusing on understanding rather than hijacking the story to talk about yourself. - The golden rule of conversation is: Listen to understand, not to reply.\n\n## Summary Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.\n\n## Revision sheet - Definition: A two-way exchange of thoughts and ideas. - Four Pillars: 1. Initiation: Break the ice using situational context or open-ended prompts. 2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking. 3. Pacing: Balance speaking and listening; use What/How/Why questions. 4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact. - Golden Rule: Listen to understand, not to reply.	3835	ready	\N	2026-08-04 23:33:15.618	2026-08-04 23:33:41.495	\N	\N	\N	beginner	2026-08-04 23:33:18.394	f	English	Communication	This lesson teaches the fundamentals of effective conversation in social and professional settings. It breaks communication down into four key pillars—initiation, active listening, pacing, and conclusion—and emphasizes the golden rule of listening to understand rather than to reply.	\N
cmsf3ajph001lvki88j6p72vk	cmsezu9gz000ivks8r8x63ms4	Lesson — Conversation	text	\N	# Conversation\n\nObjective: By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.\n\nConversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.\n\n## Explanation At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended questions. Instead of asking 'How are you?' (which often prompts a rote 'Fine'), try asking 'What has been the highlight of your week so far?'\n\n2. **Active Listening (Receiving the Message):** Most people listen with the intent to reply rather than the intent to understand. Active listening involves giving your full attention, nodding, using verbal affirmations ('I see', 'Go on'), and avoiding the temptation to interrupt or hijack the story with your own experiences.\n\n3. **Elaboration and Pacing (Keeping it Flowing):** A good conversation flows like a tennis match, not a monologue. Use open-ended questions (questions starting with What, How, or Why) to invite the other person to share more. Balance talking and listening so neither person dominates.\n\n4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up a conversation is just as important as starting it. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and, if appropriate, sets the stage for future interaction.\n\n## Examples Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'\n\nActive listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'\n\nConcluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'\n\n## Questions Why do you think open-ended questions are more effective at keeping a conversation alive than closed-ended questions (questions answered with a simple yes or no)? What is the difference between hearing someone speak and actively listening to them? How can body language and non-verbal cues influence the tone of a conversation? What are some polite ways to steer a conversation back on track if it becomes uncomfortable or repetitive?\n\n## Key takeaways - Conversations require a balanced exchange of speaking and listening, much like a tennis match. - Active listening involves paying full attention, validating feelings, and avoiding premature interruptions. - Open-ended questions starting with What, How, or Why help keep a conversation engaging and flowing. - Knowing how to gracefully conclude a interaction leaves a lasting positive impression.\n\n## Summary Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.\n\n## Revision sheet CONVERSATION REVISION SHEET:\n\n- Definition: A two-way exchange of thoughts and ideas.\n\n- Four Pillars: 1. Initiation: Break the ice using situational context or open-ended prompts. 2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking. 3. Pacing: Balance speaking and listening; use What/How/Why questions. 4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact.\n\n- Golden Rule: Listen to understand, not to reply.	4354	ready	\N	2026-08-04 20:07:19.109	2026-08-04 20:07:24.654	\N	\N	\N	beginner	2026-08-04 20:07:21.322	f	English	Communication	This lesson teaches the fundamental pillars of effective conversation, including initiation, active listening, pacing, and graceful conclusion. It emphasizes the importance of open-ended questions and listening to understand rather than simply waiting to reply.	\N
cmspgh6nb000nvk5sqpah351q	cmsevaz4j0000vkmkl9u1habf	Lesson — Les derivees	text	\N	# Les derivees\n\nObjective: Comprendre la notion de dérivée d'une fonction, savoir interpréter graphiquement son taux de variation instantané et calculer les dérivées des fonctions usuelles.\n\nImaginez que vous conduisiez une voiture. Votre compteur vous indique votre vitesse *à un instant précis*. Si vous regardez votre position sur un trajet, la vitesse instantanée représente la pente de la route à cet endroit précis. En mathématiques, c'est exactement ce que fait une dérivée : elle mesure la vitesse de variation d'une fonction à un moment donné.\n\n## Explanation 1. Qu'est-ce qu'une dérivée ? Soit $f$ une fonction définie sur un intervalle. La dérivée de $f$, notée $f'$ (ou $\\frac{df}{dx}$), est une nouvelle fonction qui donne, pour chaque nombre $x$, la **pente de la tangente** à la courbe représentative de $f$ en ce point.\n\n2. Interprétation géométrique - La fonction $f$ en un point $x$ a une pente. - Si $f'(x) > 0$, la fonction est croissante. - Si $f'(x) < 0$, la fonction est décroissante. - Si $f'(x) = 0$, la fonction possède un maximum, un minimum ou un palier (tangente horizontale).\n\n3. Formules des dérivées usuelles à connaître par cœur : - **Constante** : Si $f(x) = c$, alors $f'(x) = 0$. - **Fonction affine** : Si $f(x) = ax + b$, alors $f'(x) = a$. - **Puissance (règle générale)** : Si $f(x) = x^n$ (avec $n$ entier naturel), alors $f'(x) = n \\cdot x^{n-1}$. - Exemple particulier : Si $f(x) = x^2$, $f'(x) = 2x$. - Exemple particulier : Si $f(x) = x^3$, $f'(x) = 3x^2$. - **Inverse** : Si $f(x) = \\frac{1}{x}$, alors $f'(x) = -\\frac{1}{x^2}$. - **Racine carrée** : Si $f(x) = \\sqrt{x}$, alors $f'(x) = \\frac{1}{2\\sqrt{x}}$.\n\n4. Règles d'opération : - **Somme** : $(f + g)' = f' + g'$. - **Multiplication par une constante** : $(k \\cdot f)' = k \\cdot f'$.\n\n## Examples Exemple 1 : Dériver une fonction constante. Soit $f(x) = 5$. Sa dérivée est $f'(x) = 0$, car une constante ne varie jamais.\n\nExemple 2 : Dériver une fonction puissance. Soit $f(x) = x^4$. En appliquant la formule $nx^{n-1}$, on obtient $f'(x) = 4x^3.\n\nExemple 3 : Dériver une somme de termes. Soit $f(x) = 3x^2 + 5x - 7$. - La dérivée de $3x^2$ est $3 \\times (2x) = 6x$. - La dérivée de $5x$ est $5$. - La dérivée de $-7$ est $0$. Bilan : $f'(x) = 6x + 5$.\n\n## Questions Que représente géométriquement la valeur de la dérivée $f'(a)$ pour une fonction $f$ au point d'abscisse $a$ ? Si la dérivée d'une fonction est négative sur un intervalle, que peut-on dire du sens de variation de cette fonction ? Pourquoi la dérivée d'une fonction constante est-elle toujours égale à zéro ? Comment calcule-t-on la dérivée de la somme de deux fonctions ?\n\n## Key takeaways - La dérivée mesure la pente de la tangente à une courbe en un point donné. - Si la dérivée est positive, la fonction est croissante ; si elle est négative, elle est décroissante. - La dérivée d'une fonction constante est nulle. - La règle générale des puissances donne la dérivée de x^n comme étant n*x^(n-1).\n\n## Summary La dérivée est un outil mathématique fondamental qui quantifie la vitesse de variation d'une fonction et correspond à la pente de sa tangente en tout point. Grâce à des formules standard, son calcul devient systématique pour analyser les variations des courbes.\n\n## Revision sheet FICHES DE RÉVISION : LES DÉRIVÉES\n\n1. Définition : - f'(x) = Pente de la tangente à la courbe de f au point x. - Indique le sens de variation (f'>0 croissante, f'<0 décroissante).\n\n2. Formules fondamentales : - Constante (c) -> 0 - x -> 1 - x^n -> n*x^(n-1) - 1/x -> -1/x^2 - √x -> 1 / (2√x)\n\n3. Règles de calcul : - (u + v)' = u' + v' - (k * u)' = k * u'	3620	processing	\N	2026-08-12 02:14:02.098	2026-08-12 02:14:25.75	\N	\N	\N	beginner	2026-08-12 02:14:25.733	f	French	Mathematics	Ce document introduit la notion de dérivée en mathématiques, expliquant son interprétation géométrique comme pente de la tangente et son lien avec les variations d'une fonction. Il détaille ensuite les formules des dérivées usuelles (constantes, puissances, inverse, racine carrée) ainsi que les règles fondamentales de calcul.	cleaning
cmsq2w7hj000fvkswpw0zk6m4	cmsevaz4j0000vkmkl9u1habf	Doc pagination 3	text	\N	Contenu de test numero 3 pour la pagination.	44	ready	\N	2026-08-12 12:41:38.023	2026-08-12 12:41:46.848	\N	\N	\N	beginner	2026-08-12 12:41:40.367	f	French	Computer Science	Ce document est un contenu de test destiné à vérifier le fonctionnement de la pagination. Il s'agit d'un texte court sans portée académique spécifique.	\N
cmsq2w7uv000hvkswmabo5p9j	cmsevaz4j0000vkmkl9u1habf	Doc pagination 4	text	\N	Contenu de test numero 4 pour la pagination.	44	ready	\N	2026-08-12 12:41:38.14	2026-08-12 12:41:47.439	\N	\N	\N	beginner	2026-08-12 12:41:41.101	f	French	Computer Science	Ce document est un contenu de test destiné à valider le système de pagination.	\N
cmsq2w7a5000dvkswdndm9jrd	cmsevaz4j0000vkmkl9u1habf	Doc pagination 2	text	\N	Contenu de test numero 2 pour la pagination.	44	ready	\N	2026-08-12 12:41:37.188	2026-08-12 12:41:47.431	\N	\N	\N	beginner	2026-08-12 12:41:42.106	f	French	Computer Science	Ce document sert de contenu de test numérique numéro deux spécifiquement conçu pour évaluer la pagination. Il illustre le type de texte minimaliste utilisé pour vérifier le bon fonctionnement de la mise en page et de la division des pages.	\N
\.


--
-- Data for Name: email_verification_tokens; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.email_verification_tokens (id, "userId", "tokenHash", "expiresAt", "consumedAt", "createdAt") FROM stdin;
cmsevaz6x0003vkmk7q6rl6qx	cmsevaz4j0000vkmkl9u1habf	eff23bf1094de45e4e170e80dacb7cffbefd154d3f2af57b27cad5623d07b7db	2026-08-05 16:23:42.238	\N	2026-08-04 16:23:42.247
cmsezu9ks000lvks8vjm7achy	cmsezu9gz000ivks8r8x63ms4	b5548dbf299a77aa87d48248e16bd8e6fb5fe239b329a1bd9178ee8e69e90676	2026-08-05 18:30:40.63	\N	2026-08-04 18:30:40.636
cmsibrdkz000bvkg83tij8t3f	cmsibrdj40008vkg88ef4wjk3	45d23d6b01cf561f9130c53c7e5d55e799ec10f43655d606b662b2b3c65b21ca	2026-08-08 02:27:39.774	\N	2026-08-07 02:27:39.779
cmsibre1l000hvkg8hyjagnzi	cmsibrdyu000evkg8o2smybwc	105c69dbe779d0ec253fc91613776d6e46cf0d935efda2d69a18da5249cf93ec	2026-08-08 02:27:40.372	\N	2026-08-07 02:27:40.377
\.


--
-- Data for Name: exams; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.exams (id, "userId", subject, date, priority, "conceptId", "createdAt") FROM stdin;
cmspqpp62000qvkbwqbqqqzj2	cmsevaz4j0000vkmkl9u1habf	Biologie	2026-08-22 10:00:00	high	cmspqp5110001vkww9etn0r1h	2026-08-12 07:00:38.954
cmspqpp8t000svkbwyjiws265	cmsevaz4j0000vkmkl9u1habf	Les fonctions	2026-08-17 10:00:00	medium	cmspfofg0000dvk9020iq1q49	2026-08-12 07:00:39.053
\.


--
-- Data for Name: exercise_attempts; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.exercise_attempts (id, "userId", "lessonId", "exerciseIndex", question, "expectedAnswer", "learnerAnswer", correct, score, correction, feedback, "conceptId", "rootCauseConceptId", "createdAt", "errorMade", how, "howToAvoid", why) FROM stdin;
cmspq25b20001vk5keguy72z2	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	0	Q0	A0	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-12 06:42:20.111	\N	\N	\N	\N
cmspq25ch0003vk5kg9bdjylc	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	1	Q1	A1	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-12 05:42:20.111	\N	\N	\N	\N
cmspq25cx0005vk5k4x4y3sno	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	2	Q2	A2	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-12 04:42:20.111	\N	\N	\N	\N
cmspq25de0007vk5kp3ulr6xy	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	3	Q3	A3	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-12 03:42:20.111	\N	\N	\N	\N
cmspq25dw0009vk5k4wfrl355	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	4	Q4	A4	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-12 02:42:20.111	\N	\N	\N	\N
cmspq25fe000bvk5kjdzpu4fj	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	5	Q5	A5	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-12 01:42:20.111	\N	\N	\N	\N
cmspq25ga000dvk5kka745h0b	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	6	Q6	A6	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-12 00:42:20.111	\N	\N	\N	\N
cmspq25gq000fvk5kfji2egsq	cmsevaz4j0000vkmkl9u1habf	cmspgh31b000lvk5s0agsdznn	7	Q7	A7	wrong	f	0.1	Not quite.	Review the basics.	\N	\N	2026-08-11 23:42:20.111	\N	\N	\N	\N
\.


--
-- Data for Name: goals; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.goals (id, "userId", period, title, status, "createdAt", "completedAt") FROM stdin;
\.


--
-- Data for Name: group_members; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.group_members (id, "groupId", "userId", role, "createdAt") FROM stdin;
cmsibs5a60010vkg83uyqby0s	cmsibs54g000yvkg8rymajoxy	cmsibrdyu000evkg8o2smybwc	student	2026-08-07 02:28:15.679
\.


--
-- Data for Name: homework; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.homework (id, "userId", "lessonId", "conceptId", language, focus, exercises, questions, "masteryAtGeneration", "createdAt") FROM stdin;
cmsf6zs3l002svk3clpfzs9zl	cmsezu9gz000ivks8r8x63ms4	cmsf6ydru000hvk3c194futmg	cmsf3anso002cvki8fyqh7d9a	\N	Since you are just starting out with conversation fundamentals, this homework focuses on building your confidence around the core pillars: initiation, active listening, pacing, and conclusion. We will use your notes to practice these basics step-by-step so you feel prepared for any social or professional setting.	[{"type": "qcm", "answer": "Listen to understand, not to reply.", "options": ["Talk as much as possible to keep the energy high.", "Listen to understand, not to reply.", "Always ask closed-ended questions to get clear facts.", "End the conversation abruptly so the other person misses you."], "question": "According to your revision sheet, what is the Golden Rule of conversation?"}, {"type": "open", "answer": "1. Initiation, 2. Active Listening, 3. Pacing, 4. Conclusion.", "question": "Based on the lesson notes, what are the four fundamental pillars of a conversation?"}, {"type": "exercise", "answer": "Example: 'The bus seems to be running a bit late today. Do you take this route often?'", "question": "Your notes mention breaking the ice during the Initiation phase. Write a short, low-stakes situational remark or open-ended question you could use to start a conversation with someone standing next to you at a bus stop."}, {"type": "case", "answer": "Example: 'That sounds exhausting. What has been the main source of stress for you lately?' (This focuses on understanding and uses an open-ended question rather than turning the focus onto yourself.)", "question": "Your friend says, 'I am feeling really overwhelmed with my new job lately.' Using the active listening technique from your notes, write a good response instead of hijacking the conversation."}, {"type": "exercise", "answer": "1. Acknowledge enjoyment, 2. Give a reason to leave, 3. Plan future contact.", "question": "According to the revision sheet, what three elements make up a graceful conclusion to an interaction?"}]	["When you find yourself nervous about starting a conversation, which of the four pillars do you think you struggle with the most, and why?", "Think of a recent conversation where you felt the other person wasn't actively listening. How did it affect your desire to keep talking?"]	0	2026-08-04 21:50:55.233
cmsfaobe9005bvk3cdvszwh4n	cmsezu9gz000ivks8r8x63ms4	cmsfancr1002yvk3cvs6n1xqh	cmsf3anso002cvki8fyqh7d9a	\N	Since your mastery is currently starting from the basics, this homework focuses on drilling the core fundamentals of conversation: breaking the ice, active listening, and the golden rule. We will build your confidence step-by-step using your revision notes.	[{"type": "qcm", "answer": "Listen to understand, not to reply.", "options": ["Always talk about yourself to keep things interesting.", "Listen to understand, not to reply.", "Ask as many closed-ended questions as possible.", "Always keep the conversation under two minutes."], "question": "According to your revision sheet, what is the Golden Rule of conversation?"}, {"type": "exercise", "answer": "1. Initiation, 2. Active Listening, 3. Pacing, 4. Conclusion", "question": "List the four fundamental pillars of conversation mentioned in your notes."}, {"type": "open", "answer": "By breaking the ice using low-stakes observations, situational remarks, or open-ended prompts.", "question": "How should you start the hardest part of a conversation (Initiation) according to your notes?"}, {"type": "case", "answer": "You are hijacking the conversation or focusing on preparing your next statement rather than genuinely understanding your communication partner.", "question": "Your friend is telling you about a stressful day at work, but instead of focusing on their story, you are already planning what advice to give next. Which active listening pitfall are you falling into, based on your notes?"}]	[]	0	2026-08-04 23:33:58.832
\.


--
-- Data for Name: incidents; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.incidents (id, title, description, severity, status, "createdAt", "resolvedAt") FROM stdin;
cmsivbq86000lvkxk30qf2ukm	Latence STT elevee	\N	high	resolved	2026-08-07 11:35:21.99	2026-08-07 11:35:22.04
cmsivxkmi0014vkxkrphixheb	Pic de latence sur les paiements	\N	high	open	2026-08-07 11:52:21.161	\N
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.invoices (id, "userId", number, provider, amount, currency, status, "periodStart", "periodEnd", url, "createdAt") FROM stdin;
cmsg7u91n000cvkooissd47pd	cmsevaz4j0000vkmkl9u1habf	INV-2026-8CBB7454	fake	0	usd	paid	2026-08-05 15:02:22.742	2026-09-05 15:02:22.742	\N	2026-08-05 15:02:23.051
cmsg7v9j9000jvkoo4krilk3o	cmsevaz4j0000vkmkl9u1habf	INV-2026-697E98B7	fake	1900	usd	paid	\N	\N	\N	2026-08-05 15:03:10.341
cmsg8k0ia0013vkoollyq9e97	cmsevaz4j0000vkmkl9u1habf	INV-2026-BD91E586	fake	0	usd	paid	2026-08-05 15:22:23.611	2026-09-05 15:22:23.611	\N	2026-08-05 15:22:25.042
cmsq7oova001mvknklj3xs1vp	cmsezu9gz000ivks8r8x63ms4	INV-2026-104713F8	fake	0	usd	paid	2026-08-12 14:55:45.14	2026-09-12 14:55:45.14	\N	2026-08-12 14:55:45.382
\.


--
-- Data for Name: language_profiles; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.language_profiles (id, "userId", language, "normalizedLanguage", "nativeLanguage", mode, goal, "vocabDeckId", "createdAt", "updatedAt", "cefrLevel") FROM stdin;
cmsevbo5x000dvkmkziumhuo1	cmsevaz4j0000vkmkl9u1habf	Francais	francais	English	intermediate	\N	cmsevbo5i000bvkmkjo7hvew2	2026-08-04 16:24:14.613	2026-08-04 17:29:57.5	A1
cmsf1w4mz0005vki8r0ksmd9x	cmsevaz4j0000vkmkl9u1habf	Italian	italian	English	immersion	\N	cmsf1w4mg0003vki8jj8zbuyr	2026-08-04 19:28:06.779	2026-08-04 19:28:06.953	B2
cmsqinw4z0025vkogpf6y6vij	cmsezu9gz000ivks8r8x63ms4	Anglais	anglais	Français	beginner	\N	cmsqinw3y0023vkogff97hmn8	2026-08-12 20:03:03.923	2026-08-12 20:03:03.923	A1
cmsql8pdr002nvkogvzi2eak9	cmsezu9gz000ivks8r8x63ms4	Espagnol	espagnol	Français	beginner	\N	cmsql8pd7002lvkogimh90qsi	2026-08-12 21:15:14.174	2026-08-12 21:15:14.174	A1
cmsqo82jl002tvkogfcmhe8m0	cmsezu9gz000ivks8r8x63ms4	Japonais	japonais	Français	beginner	\N	cmsqo82ho002rvkogfy9qhy26	2026-08-12 22:38:43.425	2026-08-12 22:38:43.425	A1
cmsqocarn002xvkogrblgmvml	cmsezu9gz000ivks8r8x63ms4	Portugais	portugais	Français	beginner	\N	cmsqocar0002vvkogors46bj9	2026-08-12 22:42:00.707	2026-08-12 22:42:00.707	A1
\.


--
-- Data for Name: learning_dna; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.learning_dna (id, "userId", traits, maturity, interactions, "createdAt", "updatedAt") FROM stdin;
cmsps10n70009vkwosnedo1kp	cmsevaz4j0000vkmkl9u1habf	[{"key": "memory", "band": "emerging", "label": "Still learning", "summary": "Do some spaced reviews and I’ll learn how your memory holds.", "evidence": 0, "confidence": 0}, {"key": "peakTime", "band": "established", "label": "Mornings", "summary": "Your activity peaks in the morning — that’s when to schedule the hard work.", "evidence": 26, "confidence": 78}, {"key": "modality", "band": "established", "label": "Hands-on practice", "summary": "Your dominant modality: you learn fastest by doing — exercises and practice over passive reading.", "evidence": 26, "confidence": 78}, {"key": "explanation", "band": "emerging", "label": "Still learning", "summary": "As you take lessons, I’ll learn how deep your explanations should go.", "evidence": 1, "confidence": 0}, {"key": "retentionFormat", "band": "forming", "label": "Active practice", "summary": "Practising and being tested retains better for you than re-reading.", "evidence": 8, "confidence": 40}]	39	26	2026-08-12 07:37:26.659	2026-08-12 14:02:19.354
\.


--
-- Data for Name: learning_predictions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.learning_predictions (id, "userId", kind, probability, level, cause, action, signals, "createdAt", "updatedAt") FROM stdin;
cmspkgo1u000dvkr4ukyn9wad	cmsevaz4j0000vkmkl9u1habf	dropout	5	low	You're engaged and showing up regularly.	Keep the current rhythm — nothing to change.	{"atRisk": 0, "blocked": 2, "dueTotal": 1, "forecastSoon": 0, "goalsPending": 0, "studiedToday": true, "sessionsLast7": 0, "streakCurrent": 2, "streakLongest": 2, "averageMastery": 0.48595432, "daysSinceActive": 0}	2026-08-12 04:05:39.906	2026-08-12 14:02:19.756
cmspkgo1s0009vkr422futf98	cmsevaz4j0000vkmkl9u1habf	motivation	20	low	Very little activity this week.	Momentum is fine — keep going.	{"atRisk": 0, "blocked": 2, "dueTotal": 1, "forecastSoon": 0, "goalsPending": 0, "studiedToday": true, "sessionsLast7": 0, "streakCurrent": 2, "streakLongest": 2, "averageMastery": 0.48595432, "daysSinceActive": 0}	2026-08-12 04:05:39.903	2026-08-12 14:02:19.754
cmspkgo1x000gvkr4nb5dauow	cmsevaz4j0000vkmkl9u1habf	overload	4	low	1 reviews are due.	No change needed — the load is manageable.	{"atRisk": 0, "blocked": 2, "dueTotal": 1, "forecastSoon": 0, "goalsPending": 0, "studiedToday": true, "sessionsLast7": 0, "streakCurrent": 2, "streakLongest": 2, "averageMastery": 0.48595432, "daysSinceActive": 0}	2026-08-12 04:05:39.909	2026-08-12 14:02:19.757
cmsq8tebt002ovknkxcx9hgnp	cmsezu9gz000ivks8r8x63ms4	forgetting	0	low	Nothing is about to be forgotten.	Your memory is holding — no early review needed.	{"atRisk": 0, "blocked": 10, "dueTotal": 3, "forecastSoon": 0, "goalsPending": 0, "studiedToday": false, "sessionsLast7": 0, "streakCurrent": 0, "streakLongest": 1, "averageMastery": 0, "daysSinceActive": 7}	2026-08-12 15:27:24.617	2026-08-12 19:54:32.821
cmspkgo1t000bvkr4zcwmve87	cmsevaz4j0000vkmkl9u1habf	difficulty	45	moderate	0 concept(s) at risk and 2 blocked further along your path.	Consolidate the shaky concepts before opening new ground.	{"atRisk": 0, "blocked": 2, "dueTotal": 1, "forecastSoon": 0, "goalsPending": 0, "studiedToday": true, "sessionsLast7": 0, "streakCurrent": 2, "streakLongest": 2, "averageMastery": 0.48595432, "daysSinceActive": 0}	2026-08-12 04:05:39.903	2026-08-12 14:02:19.755
cmspkgo1y000hvkr4jll6ubzc	cmsevaz4j0000vkmkl9u1habf	forgetting	0	low	Nothing is about to be forgotten.	Your memory is holding — no early review needed.	{"atRisk": 0, "blocked": 2, "dueTotal": 1, "forecastSoon": 0, "goalsPending": 0, "studiedToday": true, "sessionsLast7": 0, "streakCurrent": 2, "streakLongest": 2, "averageMastery": 0.48595432, "daysSinceActive": 0}	2026-08-12 04:05:39.907	2026-08-12 14:02:19.756
cmsq8tebp002kvknktuuwglzq	cmsezu9gz000ivks8r8x63ms4	overload	12	low	3 reviews are due.	No change needed — the load is manageable.	{"atRisk": 0, "blocked": 10, "dueTotal": 3, "forecastSoon": 0, "goalsPending": 0, "studiedToday": false, "sessionsLast7": 0, "streakCurrent": 0, "streakLongest": 1, "averageMastery": 0, "daysSinceActive": 7}	2026-08-12 15:27:24.612	2026-08-12 19:54:32.82
cmsq8tebr002mvknk4w5sbsdt	cmsezu9gz000ivks8r8x63ms4	dropout	87	high	Several days without studying.	Nudge with a short, low-effort session to rebuild the habit.	{"atRisk": 0, "blocked": 10, "dueTotal": 3, "forecastSoon": 0, "goalsPending": 0, "studiedToday": false, "sessionsLast7": 0, "streakCurrent": 0, "streakLongest": 1, "averageMastery": 0, "daysSinceActive": 7}	2026-08-12 15:27:24.615	2026-08-12 19:54:32.818
cmsq8tec4002svknk3k39x2y8	cmsezu9gz000ivks8r8x63ms4	difficulty	100	high	0 concept(s) at risk and 10 blocked further along your path.	Consolidate the shaky concepts before opening new ground.	{"atRisk": 0, "blocked": 10, "dueTotal": 3, "forecastSoon": 0, "goalsPending": 0, "studiedToday": false, "sessionsLast7": 0, "streakCurrent": 0, "streakLongest": 1, "averageMastery": 0, "daysSinceActive": 7}	2026-08-12 15:27:24.611	2026-08-12 19:54:32.818
cmsq8tec1002qvknkzzlc9crl	cmsezu9gz000ivks8r8x63ms4	motivation	60	moderate	Very little activity this week.	Celebrate a recent win and set one tiny, achievable goal to restart momentum.	{"atRisk": 0, "blocked": 10, "dueTotal": 3, "forecastSoon": 0, "goalsPending": 0, "studiedToday": false, "sessionsLast7": 0, "streakCurrent": 0, "streakLongest": 1, "averageMastery": 0, "daysSinceActive": 7}	2026-08-12 15:27:24.622	2026-08-12 19:54:32.82
\.


--
-- Data for Name: lessons; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.lessons (id, "userId", "tutorSessionId", "conceptId", language, topic, objective, intro, explanation, examples, exercises, homework, summary, "revisionSheet", "sourceDocumentId", "createdAt", "languageProfileId", level, questions, "keyPoints") FROM stdin;
cmsf3ajmf001jvki8kz0o4o25	cmsezu9gz000ivks8r8x63ms4	cmsf39du7001bvki8h0ajtogq	\N	\N	Conversation	By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.	Conversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.	At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended questions. Instead of asking 'How are you?' (which often prompts a rote 'Fine'), try asking 'What has been the highlight of your week so far?'\n\n2. **Active Listening (Receiving the Message):** Most people listen with the intent to reply rather than the intent to understand. Active listening involves giving your full attention, nodding, using verbal affirmations ('I see', 'Go on'), and avoiding the temptation to interrupt or hijack the story with your own experiences.\n\n3. **Elaboration and Pacing (Keeping it Flowing):** A good conversation flows like a tennis match, not a monologue. Use open-ended questions (questions starting with What, How, or Why) to invite the other person to share more. Balance talking and listening so neither person dominates.\n\n4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up a conversation is just as important as starting it. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and, if appropriate, sets the stage for future interaction.	["Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'", "Active listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'", "Concluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'"]	[{"type": "qcm", "answer": "An open-ended question", "options": ["A closed-ended question", "An open-ended question", "A rhetorical question", "A leading question"], "question": "Which type of question is generally most effective for encouraging someone to share more details in a conversation?"}, {"type": "open", "answer": "Listening to understand means focusing entirely on absorbing and empathizing with the speaker's message without formulating your own counter-argument or personal story while they are still talking.", "question": "Explain the concept of 'listening to understand rather than listening to reply'."}, {"type": "exercise", "answer": "What was the best part of your weekend?", "question": "Rewrite the following closed-ended question into an open-ended conversation starter: 'Did you have a good weekend?'"}, {"type": "exercise", "answer": "That is totally normal to feel nervous about, big presentations are high-pressure situations. What part of the presentation are you feeling the most uncertain about? I'd be happy to listen if you want to practice it with me right now.", "question": "Draft a three-sentence response showing active listening when a colleague says: 'I'm really nervous about presenting my project to the board tomorrow.'"}, {"type": "case", "answer": "You can wait for a natural pause, summarize something they said to show you were listening ('It's really fascinating how much history is behind those stamps'), and then politely excuse yourself ('It was wonderful meeting you and hearing about your collection, but I promised myself I would introduce myself to a few more people before the night ends. Let's exchange business cards!')", "question": "You are at a networking event and find yourself trapped in a conversation with someone who has been talking uninterrupted about their stamp collection for 15 minutes. You need to circulate and meet others. How do you gracefully exit the conversation?"}]	Observe two different conversations today—one in media (like a podcast or TV show) and one in real life. Note one example of active listening and one example of conversational hijacking (someone interrupting to talk about themselves), and write a short paragraph reflecting on how each impacted the flow of the interaction.	Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.	CONVERSATION REVISION SHEET:\n\n- Definition: A two-way exchange of thoughts and ideas.\n\n- Four Pillars:\n  1. Initiation: Break the ice using situational context or open-ended prompts.\n  2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking.\n  3. Pacing: Balance speaking and listening; use What/How/Why questions.\n  4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact.\n\n- Golden Rule: Listen to understand, not to reply.	cmsf3ajph001lvki88j6p72vk	2026-08-04 20:07:18.995	\N	\N	["Why do you think open-ended questions are more effective at keeping a conversation alive than closed-ended questions (questions answered with a simple yes or no)?", "What is the difference between hearing someone speak and actively listening to them?", "How can body language and non-verbal cues influence the tone of a conversation?", "What are some polite ways to steer a conversation back on track if it becomes uncomfortable or repetitive?"]	["Conversations require a balanced exchange of speaking and listening, much like a tennis match.", "Active listening involves paying full attention, validating feelings, and avoiding premature interruptions.", "Open-ended questions starting with What, How, or Why help keep a conversation engaging and flowing.", "Knowing how to gracefully conclude a interaction leaves a lasting positive impression."]
cmsf6ydru000hvk3c194futmg	cmsezu9gz000ivks8r8x63ms4	\N	cmsf3anso002cvki8fyqh7d9a	\N	Conversation Fundamentals	By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.	Conversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.	At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended prompts. Instead of asking 'How are you?' (which often prompts a rote 'Fine'), try asking 'What has been the highlight of your week so far?'\n\n2. **Active Listening (Receiving the Message):** Most people listen with the intent to reply rather than the intent to understand. Active listening involves giving your full attention, nodding, using verbal affirmations ('I see', 'Go on'), and avoiding the temptation to interrupt or hijack the story with your own experiences.\n\n3. **Elaboration and Pacing (Keeping it Flowing):** A good conversation flows like a tennis match, not a monologue. Use open-ended questions (questions starting with What, How, or Why) to invite the other person to share more. Balance talking and listening so neither person dominates.\n\n4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up a conversation is just as important as starting it. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and, if appropriate, sets the stage for future interaction.	["Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'", "Active listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'", "Concluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'"]	[{"type": "qcm", "answer": "Listen to understand, not to reply.", "options": ["Listen to reply quickly and impress the speaker.", "Listen to understand, not to reply.", "Interrupt frequently to show enthusiasm.", "Keep the conversation entirely focused on yourself."], "question": "What is the Golden Rule of active listening mentioned in the lesson?"}, {"type": "open", "answer": "1. Initiation, 2. Active Listening, 3. Elaboration and Pacing, 4. Conclusion.", "question": "Name the four pillars of conversation in their correct order."}, {"type": "exercise", "answer": "What did you think of the movie?", "question": "Rewrite the closed-ended question 'Did you like the movie?' into an open-ended question that encourages elaboration."}, {"type": "case", "answer": "Acknowledge how much you enjoyed chatting, provide a natural reason to move on (e.g., needing to grab a drink or greet someone else), and offer future contact if appropriate. For example: 'It was so wonderful talking with you about this industry. I see my colleague waving over there, so I should head over, but let's connect on LinkedIn next week!'", "question": "You are at a networking event and have been chatting with someone for ten minutes. You notice they are glancing at their watch and shifting their weight. How would you gracefully conclude the interaction based on the four pillars?"}]	Practice initiating a conversation using a low-stakes situational observation with someone new this week (e.g., a barista, a classmate, or a colleague). Pay close attention to whether you are listening to understand or just waiting for your turn to reply.	Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.	CONVERSATION REVISION SHEET:\n\n- Definition: A two-way exchange of thoughts and ideas.\n\n- Four Pillars: 1. Initiation: Break the ice using situational context or open-ended prompts. 2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking. 3. Pacing: Balance speaking and listening; use What/How/Why questions. 4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact.\n\n- Golden Rule: Listen to understand, not to reply.	cmsf6ye63000jvk3cz7d814bi	2026-08-04 21:49:49.935	\N	\N	["Why do you think open-ended questions are more effective at keeping a conversation alive than closed-ended questions (questions answered with a simple yes or no)?", "What is the difference between hearing someone speak and actively listening to them?", "How can body language and non-verbal cues influence the tone of a conversation?", "What are some polite ways to steer a conversation back on track if it becomes uncomfortable or repetitive?"]	["Conversations require a balanced exchange of speaking and listening, much like a tennis match.", "Active listening involves paying full attention, validating feelings, and avoiding premature interruptions.", "Open-ended questions starting with What, How, or Why help keep a conversation engaging and flowing.", "Knowing how to gracefully conclude an interaction leaves a lasting positive impression."]
cmsfancr1002yvk3cvs6n1xqh	cmsezu9gz000ivks8r8x63ms4	\N	cmsf3anso002cvki8fyqh7d9a	\N	Conversation Fundamentals	By the end of this lesson, you will be able to initiate, maintain, and conclude engaging and effective conversations in various social and professional settings using active listening and clear communication techniques.	Conversation is the heartbeat of human connection. Whether you are chatting with a stranger at a bus stop, interviewing for your dream job, or catching up with a lifelong friend, the ability to converse well opens doors, builds trust, and enriches relationships. But good conversation is not just about talking—it is a delicate dance of speaking, listening, and observing.	At its core, a conversation is a two-way exchange of thoughts, feelings, and ideas between two or more people. To master conversation, we must break it down into four fundamental pillars:\n\n1. **Initiation (Starting the Conversation):** The hardest part is often the beginning. Breaking the ice requires low-stakes observations, situational remarks, or open-ended prompts.\n2. **Active Listening:** Focus on understanding rather than just waiting for your turn to speak. Use verbal and non-verbal affirmations, and avoid hijacking the conversation with your own stories.\n3. **Pacing and Questioning:** Balance speaking and listening so neither person dominates. Use What, How, and Why questions to keep the dialogue engaging and flowing.\n4. **Conclusion (Ending Gracefully):** Knowing how to gracefully wrap up an interaction leaves a lasting positive impression. A good exit acknowledges the enjoyment of the chat, provides a reason for leaving, and sets the stage for future interaction.\n\n**The Golden Rule:** Listen to understand, not to reply.	["Initiating a conversation: Instead of standing silently in an elevator, you notice someone's book and ask, 'Is that the new novel by that author? I've been meaning to check it out.'", "Active listening vs. Interrupting: Friend says, 'I'm feeling really overwhelmed with work lately.' Poor response: 'Oh, you think you're busy? Last week I had three presentations...' Good response: 'That sounds exhausting. What's been the main source of stress?'", "Concluding a conversation: 'It was so wonderful catching up with you at this event. I need to go grab my coat before I head out, but let's grab coffee next Tuesday!'"]	[{"type": "qcm", "answer": "Listen to understand, not to reply.", "options": ["Always talk more than you listen to show confidence.", "Listen to understand, not to reply.", "Keep conversations strictly professional at all times.", "Always end a conversation within five minutes."], "question": "According to the lesson, what is the golden rule of conversation?"}, {"type": "open", "answer": "1. Initiation, 2. Active Listening, 3. Pacing and Questioning, 4. Conclusion.", "question": "Name the four fundamental pillars of a conversation."}, {"type": "exercise", "answer": "That sounds really stressful, putting your art out there like that. What part of the exhibition is worrying you the most?", "question": "Rewrite the following poor response into an active listening response: Partner says, 'I am really stressed about my upcoming art exhibition.' Poor response: 'Art is easy, you'll be fine. When I had my exam last year...'"}, {"type": "case", "answer": "Acknowledge the enjoyment ('It was so wonderful talking with you about this project'), give a reason for leaving ('I need to head over to the next workshop before it starts'), and plan future contact ('Let's connect on LinkedIn next week to continue this!').", "question": "You are at a networking event and have been talking to a colleague for 15 minutes. You notice they are glancing around the room, and you need to get to your next workshop. How do you gracefully conclude the conversation using the three steps of a good exit?"}]	Observe a conversation between two people in a public space or on TV today. Identify how they initiated the talk, whether they practiced active listening, and how they eventually brought the interaction to a close. Write a short paragraph summarizing your observations.	Conversations are the foundation of human interaction, requiring a balance of initiation, active listening, thoughtful questioning, and graceful closure. By shifting our focus from preparing our next statement to genuinely understanding our communication partner, we can build deeper and more meaningful connections.	- Definition: A two-way exchange of thoughts and ideas.\n- Four Pillars: \n  1. Initiation: Break the ice using situational context or open-ended prompts.\n  2. Active Listening: Focus on understanding, use verbal/non-verbal affirmations, avoid hijacking.\n  3. Pacing: Balance speaking and listening; use What/How/Why questions.\n  4. Conclusion: Acknowledge enjoyment, give a reason to leave, and plan future contact.\n- Golden Rule: Listen to understand, not to reply.	cmsfane250030vk3ckp0grfpq	2026-08-04 23:33:13.932	\N	\N	["Why do you think open-ended questions are more effective than closed questions (yes/no questions) for maintaining a conversation?", "How does the golden rule ('Listen to understand, not to reply') change the way you react when someone is sharing a problem?", "What makes a situational observation an effective icebreaker compared to a generic greeting?"]	["A conversation is a two-way exchange of thoughts, feelings, and ideas.", "The four pillars are Initiation, Active Listening, Pacing, and Conclusion.", "Active listening means focusing on understanding rather than hijacking the story to talk about yourself.", "The golden rule of conversation is: Listen to understand, not to reply."]
cmspgh31b000lvk5s0agsdznn	cmsevaz4j0000vkmkl9u1habf	\N	cmspfogm0000fvk90shxxit2z	\N	Les derivees	Comprendre la notion de dérivée d'une fonction, savoir interpréter graphiquement son taux de variation instantané et calculer les dérivées des fonctions usuelles.	Imaginez que vous conduisiez une voiture. Votre compteur vous indique votre vitesse *à un instant précis*. Si vous regardez votre position sur un trajet, la vitesse instantanée représente la pente de la route à cet endroit précis. En mathématiques, c'est exactement ce que fait une dérivée : elle mesure la vitesse de variation d'une fonction à un moment donné.	1. Qu'est-ce qu'une dérivée ?\nSoit $f$ une fonction définie sur un intervalle. La dérivée de $f$, notée $f'$ (ou $\\frac{df}{dx}$), est une nouvelle fonction qui donne, pour chaque nombre $x$, la **pente de la tangente** à la courbe représentative de $f$ en ce point.\n\n2. Interprétation géométrique\n- La fonction $f$ en un point $x$ a une pente.\n- Si $f'(x) > 0$, la fonction est croissante.\n- Si $f'(x) < 0$, la fonction est décroissante.\n- Si $f'(x) = 0$, la fonction possède un maximum, un minimum ou un palier (tangente horizontale).\n\n3. Formules des dérivées usuelles à connaître par cœur :\n- **Constante** : Si $f(x) = c$, alors $f'(x) = 0$.\n- **Fonction affine** : Si $f(x) = ax + b$, alors $f'(x) = a$.\n- **Puissance (règle générale)** : Si $f(x) = x^n$ (avec $n$ entier naturel), alors $f'(x) = n \\cdot x^{n-1}$.\n  - Exemple particulier : Si $f(x) = x^2$, $f'(x) = 2x$.\n  - Exemple particulier : Si $f(x) = x^3$, $f'(x) = 3x^2$.\n- **Inverse** : Si $f(x) = \\frac{1}{x}$, alors $f'(x) = -\\frac{1}{x^2}$.\n- **Racine carrée** : Si $f(x) = \\sqrt{x}$, alors $f'(x) = \\frac{1}{2\\sqrt{x}}$.\n\n4. Règles d'opération :\n- **Somme** : $(f + g)' = f' + g'$.\n- **Multiplication par une constante** : $(k \\cdot f)' = k \\cdot f'$.	["Exemple 1 : Dériver une fonction constante. Soit $f(x) = 5$. Sa dérivée est $f'(x) = 0$, car une constante ne varie jamais.", "Exemple 2 : Dériver une fonction puissance. Soit $f(x) = x^4$. En appliquant la formule $nx^{n-1}$, on obtient $f'(x) = 4x^3.", "Exemple 3 : Dériver une somme de termes. Soit $f(x) = 3x^2 + 5x - 7$. \\n- La dérivée de $3x^2$ est $3 \\\\times (2x) = 6x$.\\n- La dérivée de $5x$ est $5$.\\n- La dérivée de $-7$ est $0$.\\nBilan : $f'(x) = 6x + 5$."]	[{"type": "qcm", "answer": "3x^2", "options": ["3x^2", "x^2", "3x^3", "2x^3"], "question": "Quelle est la dérivée de la fonction $f(x) = x^3$ ?"}, {"type": "open", "answer": "La dérivée est -4.", "question": "Quelle est la dérivée de la fonction affine $f(x) = -4x + 7$ ?"}, {"type": "exercise", "answer": "f'(x) = 10x - 3", "question": "Calculez la fonction dérivée de $f(x) = 5x^2 - 3x + 9$."}, {"type": "qcm", "answer": "-1 / x^2", "options": ["1 / x^2", "-1 / x^2", "-1 / x", "2 / x"], "question": "Si $f(x) = \\\\frac{1}{x}$, quelle est sa dérivée $f'(x)$ ?"}, {"type": "exercise", "answer": "La dérivée est f'(x) = 2x. Pour x = 3, f'(3) = 2 * 3 = 6.", "question": "Déterminez la valeur de la dérivée de $f(x) = x^2$ au point d'abscisse $x = 3$."}, {"type": "case", "answer": "La vitesse instantanée est la dérivée de la position par rapport au temps : f'(t) = 2t + 2. À l'instant t = 4, f'(4) = 2(4) + 2 = 10 unités par seconde.", "question": "Un mobile se déplace de sorte que sa position à l'instant $t$ est donnée par la fonction $f(t) = t^2 + 2t$. Calculez sa vitesse instantanée à l'instant $t = 4$ secondes."}]	Apprenez par cœur les dérivées usuelles (constante, x^n, 1/x, √x) et calculez la dérivée de la fonction g(x) = 4x^3 - 2x^2 + x - 5 pour la prochaine séance.	La dérivée est un outil mathématique fondamental qui quantifie la vitesse de variation d'une fonction et correspond à la pente de sa tangente en tout point. Grâce à des formules standard, son calcul devient systématique pour analyser les variations des courbes.	FICHES DE RÉVISION : LES DÉRIVÉES\n\n1. Définition :\n- f'(x) = Pente de la tangente à la courbe de f au point x.\n- Indique le sens de variation (f'>0 croissante, f'<0 décroissante).\n\n2. Formules fondamentales :\n- Constante (c) -> 0\n- x -> 1\n- x^n -> n*x^(n-1)\n- 1/x -> -1/x^2\n- √x -> 1 / (2√x)\n\n3. Règles de calcul :\n- (u + v)' = u' + v'\n- (k * u)' = k * u'	cmspgh6nb000nvk5sqpah351q	2026-08-04 04:07:00.015	\N	\N	["Que représente géométriquement la valeur de la dérivée $f'(a)$ pour une fonction $f$ au point d'abscisse $a$ ?", "Si la dérivée d'une fonction est négative sur un intervalle, que peut-on dire du sens de variation de cette fonction ?", "Pourquoi la dérivée d'une fonction constante est-elle toujours égale à zéro ?", "Comment calcule-t-on la dérivée de la somme de deux fonctions ?"]	["La dérivée mesure la pente de la tangente à une courbe en un point donné.", "Si la dérivée est positive, la fonction est croissante ; si elle est négative, elle est décroissante.", "La dérivée d'une fonction constante est nulle.", "La règle générale des puissances donne la dérivée de x^n comme étant n*x^(n-1)."]
\.


--
-- Data for Name: memberships; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.memberships (id, "organizationId", "userId", role, "createdAt") FROM stdin;
cmsibredm000mvkg8x2fj2a7g	cmsibredl000kvkg86agr5skt	cmsevaz4j0000vkmkl9u1habf	admin	2026-08-07 02:27:40.81
cmsibrezj000ovkg84jyy8okm	cmsibredl000kvkg86agr5skt	cmsibrdj40008vkg88ef4wjk3	teacher	2026-08-07 02:27:41.6
cmsibrf16000qvkg80nzt7e9k	cmsibredl000kvkg86agr5skt	cmsibrdyu000evkg8o2smybwc	student	2026-08-07 02:27:41.657
\.


--
-- Data for Name: mentor_guidance; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.mentor_guidance (id, "userId", headline, focus, dimensions, "createdAt", "updatedAt") FROM stdin;
cmspq18vo0009vkxkzkwd0lwa	cmsevaz4j0000vkmkl9u1habf	I think you're working a lot, but not in the most effective way — the effort isn't converting into mastery. The fix isn't studying more, it's studying differently: shorter active-recall sessions on your weak spots instead of re-reading.	method	[{"key": "method", "rating": "concern", "insight": "I think you're working a lot, but not in the most effective way — the effort isn't converting into mastery. The fix isn't studying more, it's studying differently: shorter active-recall sessions on your weak spots instead of re-reading.", "reasons": ["Effort (14d): 9 study actions.", "Average mastery 49%.", "Exercise accuracy 0% over 8 attempt(s)."]}, {"key": "success", "rating": "concern", "insight": "Your current grasp is fragile — we should shore up the fundamentals before pushing ahead.", "reasons": ["1 strong / 1 weak of 2 tracked concept(s).", "Average mastery 49%."]}, {"key": "exams", "rating": "building", "insight": "Link \\"Les fonctions\\" to its concepts so I can track your readiness for the exam in 5 day(s).", "reasons": ["Nearest exam \\"Les fonctions\\" in 5 day(s).", "Preparation untracked."]}, {"key": "organization", "rating": "building", "insight": "You're forming a rhythm — protect a fixed daily slot so it becomes automatic.", "reasons": ["Current streak 2 day(s), longest 2.", "0 session(s) this week."]}, {"key": "confidence", "rating": "concern", "insight": "Recent struggles can dent confidence — remember you've already mastered 1 concept(s); we build from there, not from zero.", "reasons": ["1 mastered vs 1 weak concept(s).", "Recent accuracy 0%."]}]	2026-08-12 06:41:38.1	2026-08-12 08:01:22.034
cmsptbnkx002jvkwov3y7w3wo	cmsezu9gz000ivks8r8x63ms4	Your current grasp is fragile — we should shore up the fundamentals before pushing ahead.	success	[{"key": "method", "rating": "building", "insight": "Your approach is roughly on track; keep favouring active recall over passive review.", "reasons": ["Effort (14d): 5 study actions.", "Average mastery 0%.", "Exercise accuracy n/a over 0 attempt(s)."]}, {"key": "success", "rating": "concern", "insight": "Your current grasp is fragile — we should shore up the fundamentals before pushing ahead.", "reasons": ["0 strong / 1 weak of 1 tracked concept(s).", "Average mastery 0%."]}, {"key": "exams", "rating": "good", "insight": "No exams on the horizon — steady, unhurried progress is the goal.", "reasons": ["No upcoming exams scheduled."]}, {"key": "organization", "rating": "concern", "insight": "Your study rhythm is irregular — one small, fixed daily session beats occasional long ones.", "reasons": ["Current streak 0 day(s), longest 1.", "0 session(s) this week."]}, {"key": "confidence", "rating": "concern", "insight": "Recent struggles can dent confidence — remember you've already mastered 0 concept(s); we build from there, not from zero.", "reasons": ["0 mastered vs 1 weak concept(s).", "Recent accuracy n/a."]}]	2026-08-12 08:13:42.561	2026-08-12 08:13:42.561
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.notifications (id, "userId", date, slot, channel, title, body, "sentAt") FROM stdin;
cmsfqlxxf000uvk94ktl6fpmf	cmsezu9gz000ivks8r8x63ms4	2026-08-05	morning	log	Your morning review is ready	Start the day by bringing yesterday back:\n• Review 24 due cards	2026-08-05 07:00:01.923
cmsgkm6ap0018vkoojkwwjgjy	cmsezu9gz000ivks8r8x63ms4	2026-08-05	night	log	One quick pass before sleep	A short revision locks the day in:\n• Quick revision — 10 cards	2026-08-05 21:00:01.249
cmsjfhvl60025vkxkul012sm4	cmsezu9gz000ivks8r8x63ms4	2026-08-07	night	log	One quick pass before sleep	A short revision locks the day in:\n• Quick revision — 10 cards	2026-08-07 21:00:01.194
cmspqoz0c000avkbwo7rpnsle	cmsevaz4j0000vkmkl9u1habf	2026-08-12	morning	log	Your morning review is ready	Start the day by bringing yesterday back:\n• Review 8 due cards\n\n2-day streak — today is already in the bag.	2026-08-12 07:00:05.052
cmspqoz9b000ivkbwr6uzkoo0	cmsezu9gz000ivks8r8x63ms4	2026-08-12	morning	log	Your morning review is ready	Start the day by bringing yesterday back:\n• Review 24 due cards	2026-08-12 07:00:05.375
cmsq5p67y0010vkckv325o1a0	cmsevaz4j0000vkmkl9u1habf	2026-08-12	afternoon	log	Today's lesson is waiting	Time for something new:\n• New lesson: Les derivees\n\n2-day streak — today is already in the bag.	2026-08-12 14:00:08.638
cmsq5p6ur0015vkckhllezgag	cmsezu9gz000ivks8r8x63ms4	2026-08-12	afternoon	log	Today's lesson is waiting	Time for something new:\n• New lesson: Conversation Fundamentals	2026-08-12 14:00:09.459
cmsqkp72y002cvkog1vqxc2cj	cmsevaz4j0000vkmkl9u1habf	2026-08-12	night	log	One quick pass before sleep	A short revision locks the day in:\n• Quick revision — 8 cards\n\n2-day streak — today is already in the bag.	2026-08-12 21:00:03.993
cmsqkp8fm002hvkoga40dg8fz	cmsezu9gz000ivks8r8x63ms4	2026-08-12	night	log	One quick pass before sleep	A short revision locks the day in:\n• Quick revision — 10 cards	2026-08-12 21:00:05.747
\.


--
-- Data for Name: org_groups; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.org_groups (id, "organizationId", name, kind, "createdAt") FROM stdin;
cmsibs54g000yvkg8rymajoxy	cmsibredl000kvkg86agr5skt	Terminale S1	class	2026-08-07 02:28:15.472
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.organizations (id, name, type, "createdAt", "updatedAt") FROM stdin;
cmsibredl000kvkg86agr5skt	Lycee Victor Hugo	school	2026-08-07 02:27:40.81	2026-08-07 02:27:40.81
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.payments (id, "userId", provider, "providerRef", amount, currency, status, purpose, "createdAt") FROM stdin;
cmsg7u8zs000avkooek63w05f	cmsevaz4j0000vkmkl9u1habf	fake	fake_sub_c619e2e9	0	usd	succeeded	subscription	2026-08-05 15:02:22.985
cmsg7v9gi000hvkoox2mu4nn4	cmsevaz4j0000vkmkl9u1habf	fake	fake_sub_x	1900	usd	succeeded	renewal	2026-08-05 15:03:10.242
cmsg8k0400011vkoo1tx1xbks	cmsevaz4j0000vkmkl9u1habf	fake	fake_sub_95998d92	0	usd	succeeded	subscription	2026-08-05 15:22:24.528
cmsq7oory001kvknk9mqzb4xp	cmsezu9gz000ivks8r8x63ms4	fake	fake_sub_04cb1c2e	0	usd	succeeded	subscription	2026-08-12 14:55:45.262
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.plans (id, slug, name, tier, audience, quotas, features, "priceMonthly", "priceYearly", currency, "isActive", "createdAt", "updatedAt") FROM stdin;
cmsg5oxjh0000vkzo1hf3arpc	free	Free	0	individual	{"storage": 10737418240, "documents": 100, "ai_questions": 1000, "voice_minutes": 300}	{}	\N	\N	usd	t	2026-08-05 14:02:15.625	2026-08-12 18:51:05.37
cmsg5oxqv0001vkzoxr7gnihs	pro	Pro	10	individual	{"storage": 107374182400, "documents": 1000, "ai_questions": 10000, "voice_minutes": 3000}	{}	\N	\N	usd	t	2026-08-05 14:02:15.895	2026-08-12 18:51:05.776
cmsg5oxti0002vkzo5eu2hbv5	pro_max	Pro Max	20	individual	{"storage": 536870912000, "documents": 5000, "ai_questions": 50000, "voice_minutes": 10000}	{}	\N	\N	usd	t	2026-08-05 14:02:15.99	2026-08-12 18:51:05.803
cmsg5oybc0003vkzojeiajw8o	team	Team / Business	30	organization	{"storage": -1, "documents": -1, "ai_questions": -1, "voice_minutes": -1}	{}	\N	\N	usd	t	2026-08-05 14:02:16.632	2026-08-12 18:51:05.845
cmsg5oyc40004vkzoogoxhx9x	school	School	40	organization	{"storage": -1, "documents": -1, "ai_questions": -1, "voice_minutes": -1}	{}	\N	\N	usd	t	2026-08-05 14:02:16.66	2026-08-12 18:51:05.878
cmsg5oyij0005vkzovzub6uim	enterprise	Enterprise	50	organization	{"storage": -1, "documents": -1, "ai_questions": -1, "voice_minutes": -1}	{}	\N	\N	usd	t	2026-08-05 14:02:16.891	2026-08-12 18:51:05.896
\.


--
-- Data for Name: profiles; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.profiles (id, "userId", "displayName", "preferredLanguage", "createdAt", "updatedAt", timezone) FROM stdin;
cmsevaz4n0001vkmkbkdq9bcj	cmsevaz4j0000vkmkl9u1habf	Russell	fr	2026-08-04 16:23:42.158	2026-08-05 06:27:27.303	UTC
cmsibrdj40009vkg8bw9g1e6g	cmsibrdj40008vkg88ef4wjk3	prof	en	2026-08-07 02:27:39.712	2026-08-07 02:27:39.712	UTC
cmsibrdyu000fvkg80yc0r35h	cmsibrdyu000evkg8o2smybwc	eleve	en	2026-08-07 02:27:40.278	2026-08-07 02:27:40.278	UTC
cmsezu9h1000jvks8kgfsq9rx	cmsezu9gz000ivks8r8x63ms4	LEO	fr	2026-08-04 18:30:40.32	2026-08-12 19:55:55.242	UTC
\.


--
-- Data for Name: reading_exercises; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.reading_exercises (id, "userId", level, topic, title, text, questions, score, "adaptedLevel", result, "createdAt") FROM stdin;
cmsf0nzvm0007vkwckyqfsolz	cmsevaz4j0000vkmkl9u1habf	intermediate	les volcans	Le réveil de la Terre : Comprendre les volcans	Un volcan est une ouverture dans la croûte terrestre qui permet à du magma, des gaz et des cendres de s'échapper des profondeurs de la Terre. Quand la pression souterraine devient trop forte, le volcan entre en éruption. Le magma, qui s'appelle alors de la lave une fois à la surface, coule le long de la pente et peut détruire tout sur son passage. \n\nIl existe deux grands types de volcans. D'un côté, les volcans explosifs projettent des nuages de cendres brûlantes et des roches à des kilomètres d'altitude, ce qui les rend très dangereux pour les populations locales. De l'autre, les volcans effusifs produisent des rivières de lave fluide qui coulent plus lentement, offrant un spectacle impressionnant mais souvent moins destructeur pour les vies humaines.\n\nHeureusement, les scientifiques, appelés volcanologues, surveillent ces géants de la nature grâce à des instruments modernes. Ils mesurent les vibrations de la terre et l'émission de gaz pour prédire les éruptions et évacuer les zones à risque à temps. Malgré leur danger, les volcans ont aussi un rôle important : la cendre volcanique rend les sols autour d'eux extrêmement fertiles pour l'agriculture.	[{"id": "3814c1d6-c68c-4522-b448-164d7382b17c", "format": "mcq", "points": 1, "prompt": "Comment appelle-t-on le magma lorsqu'il arrive à la surface de la Terre ?", "rubric": "L'élève doit identifier que le magma prend le nom de 'lave' une fois qu'il atteint la surface.", "options": ["Des cendres", "De la lave", "De la roche solide", "Du gaz"], "answerKey": "De la lave"}, {"id": "3c226af8-48c9-4e10-9072-89b88d33cc8b", "format": "open", "points": 2, "prompt": "Quelle est la principale différence entre un volcan explosif et un volcan effusif selon le texte ?", "rubric": "L'élève doit mentionner que les volcans explosifs projettent des cendres/roches (et sont très dangereux) alors que les volcans effusifs font des coulées de lave (qui coulent plus lentement).", "answerKey": "Les volcans explosifs projettent des cendres et des roches dans l'air de manière très dangereuse, tandis que les volcans effusifs produisent des coulées de lave fluides et plus lentes."}, {"id": "e671a99d-f5ea-40b2-a84e-1b054d7635f5", "format": "mcq", "points": 1, "prompt": "Quel est le rôle des volcanologues ?", "rubric": "L'élève doit comprendre que les volcanologues surveillent l'activité des volcans afin de prévenir les dangers.", "options": ["Construire des maisons près des volcans", "Surveiller les volcans pour prédire les éruptions", "Provoquer des éruptions contrôlées", "Cultiver la terre autour des volcans"], "answerKey": "Surveiller les volcans pour prédire les éruptions"}, {"id": "5a4c3b11-73c6-4607-bd24-a5b4c117dee4", "format": "open", "points": 2, "prompt": "D'après le texte, est-ce que les volcans ont uniquement des aspects négatifs ? Justifie ta réponse.", "rubric": "L'élève doit répondre 'non' et expliquer le point positif mentionné dans le texte, à savoir la fertilité des sols grâce aux cendres volcaniques.", "answerKey": "Non, les volcans n'ont pas que des aspects négatifs. Même s'ils sont dangereux, leurs cendres rendent les sols extrêmement fertiles pour l'agriculture."}]	100	advanced	{"score": 100, "results": [{"how": "Pour trouver la bonne réponse, il suffit de se rappeler la définition du mot 'lave' par rapport au 'magma'.", "max": 1, "why": "Ta réponse est tout à fait exacte. Le magma qui sort à la surface de la Terre s'appelle bien de la lave.", "prompt": "Comment appelle-t-on le magma lorsqu'il arrive à la surface de la Terre ?", "awarded": 1, "verdict": "correct", "errorMade": null, "howToAvoid": null, "questionId": "3814c1d6-c68c-4522-b448-164d7382b17c", "learnerAnswer": "De la lave"}, {"how": "Il faut comparer les deux types de volcans en observant leur mode d'éruption (explosions/projections de cendres vs coulées douces).", "max": 2, "why": "Ta réponse est excellente et très complète. Tu as bien identifié la violence et les projections du volcan explosif par rapport à l'écoulement plus calme du volcan effusif.", "prompt": "Quelle est la principale différence entre un volcan explosif et un volcan effusif selon le texte ?", "awarded": 2, "verdict": "correct", "errorMade": null, "howToAvoid": null, "questionId": "3c226af8-48c9-4e10-9072-89b88d33cc8b", "learnerAnswer": "Un volcan explosif projette violemment de la lave, des cendres et des gaz sous haute pression, tandis qu'un volcan effusif laisse la lave s'ecouler doucement et calmement."}, {"how": "Il fallait choisir l'option qui correspond au métier de scientifique étudiant les volcans.", "max": 1, "why": "C'est exact. Les volcanologues étudient et surveillent les volcans pour anticiper les éruptions et protéger les populations.", "prompt": "Quel est le rôle des volcanologues ?", "awarded": 1, "verdict": "correct", "errorMade": null, "howToAvoid": null, "questionId": "e671a99d-f5ea-40b2-a84e-1b054d7635f5", "learnerAnswer": "Surveiller les volcans pour predire les eruptions"}, {"how": "Pour répondre, il fallait chercher dans le texte les aspects bénéfiques des volcans, comme la fertilité des terres agricoles grâce aux cendres.", "max": 2, "why": "Parfait ! Tu as répondu correctement 'non' et tu as très bien justifié en mentionnant la fertilité des sols et la création de nouvelles terres.", "prompt": "D'après le texte, est-ce que les volcans ont uniquement des aspects négatifs ? Justifie ta réponse.", "awarded": 2, "verdict": "correct", "errorMade": null, "howToAvoid": null, "questionId": "5a4c3b11-73c6-4607-bd24-a5b4c117dee4", "learnerAnswer": "Non, les volcans ont aussi des aspects positifs : ils enrichissent les sols en mineraux, ce qui rend les terres agricoles tres fertiles, et ils peuvent creer de nouvelles terres."}], "summary": "Excellent travail ! Tu as obtenu le maximum de points (6/6). Tes réponses sont précises, bien argumentées et montrent une excellente compréhension du texte.", "newLevel": "advanced", "levelChange": "up", "previousLevel": "intermediate"}	2026-08-04 18:53:47.747
\.


--
-- Data for Name: recommendations; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.recommendations (id, "userId", kind, title, reason, "targetKind", "targetId", "dedupeKey", priority, status, "createdAt", "respondedAt") FROM stdin;
cmspl62ch000bvkdsprrak7fw	cmsevaz4j0000vkmkl9u1habf	lesson	New lesson: Les derivees	You've mastered what "Les derivees" builds on — you're ready to start it.	concept	cmspfogm0000fvk90shxxit2z	lesson:cmspfogm0000fvk90shxxit2z	50	suggested	2026-08-12 04:25:24.834	\N
cmspl62cy000dvkdsysyp2rx9	cmsevaz4j0000vkmkl9u1habf	lesson	New lesson: Les fonctions	You've mastered what "Les fonctions" builds on — you're ready to start it.	concept	cmspfofg0000dvk9020iq1q49	lesson:cmspfofg0000dvk9020iq1q49	50	suggested	2026-08-12 04:25:24.85	\N
cmspl62be0009vkdsvscmaaxt	cmsevaz4j0000vkmkl9u1habf	review	Review 1 item	1 item is due — a short review locks them in.	route	/revision	review	60	accepted	2026-08-12 04:25:24.794	2026-08-12 04:26:09.034
cmspl62de000fvkdsi3swueaz	cmsevaz4j0000vkmkl9u1habf	reading	Read: Lesson — Les derivees	This supports "Les derivees", which is on your path right now.	document	cmspgh6nb000nvk5sqpah351q	reading:cmspgh6nb000nvk5sqpah351q	40	dismissed	2026-08-12 04:25:24.866	2026-08-12 04:26:09.081
cmsps92xf000rvkwoddjtlrlh	cmsevaz4j0000vkmkl9u1habf	practical	Try a practical on Biologie	You've mastered "Biologie" — applying it in practice makes it permanent.	concept	cmspqp5110001vkww9etn0r1h	practical:cmspqp5110001vkww9etn0r1h	30	suggested	2026-08-12 07:43:42.863	\N
cmspsspc10019vkwotu8js682	cmsezu9gz000ivks8r8x63ms4	review	Review 3 items	3 items are due — a short review locks them in.	route	/revision	review	60	suggested	2026-08-12 07:58:58.368	\N
cmspsspjy001bvkwoolkoxpz2	cmsezu9gz000ivks8r8x63ms4	lesson	New lesson: Conversation Fundamentals	You've mastered what "Conversation Fundamentals" builds on — you're ready to start it.	concept	cmsf3anso002cvki8fyqh7d9a	lesson:cmsf3anso002cvki8fyqh7d9a	50	suggested	2026-08-12 07:58:58.655	\N
cmspsspxe001dvkwo3t72c354	cmsezu9gz000ivks8r8x63ms4	reading	Read: Lesson — Conversation	This supports "Conversation Fundamentals", which is on your path right now.	document	cmsf3ajph001lvki88j6p72vk	reading:cmsf3ajph001lvki88j6p72vk	40	suggested	2026-08-12 07:58:59.138	\N
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.recovery_codes (id, "userId", "codeHash", "usedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.reports (id, "reporterId", category, message, status, "createdAt", "reviewedAt") FROM stdin;
cmsivbqas000ovkxkke1khdmg	cmsibrdyu000evkg8o2smybwc	content	Contenu inapproprie dans une lecon	reviewed	2026-08-07 11:35:22.084	2026-08-07 11:35:22.15
cmsivxkpp0016vkxkziiptwf4	cmsibrdyu000evkg8o2smybwc	bug	Le bouton de revision ne repond pas	open	2026-08-07 11:52:21.277	\N
\.


--
-- Data for Name: review_logs; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.review_logs (id, "cardId", "userId", rating, state, "scheduledDays", "reviewedAt") FROM stdin;
\.


--
-- Data for Name: reviewables; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.reviewables (id, "userId", kind, "refId", title, state, stability, difficulty, due, "elapsedDays", "scheduledDays", reps, lapses, "lastReview", "createdAt", "updatedAt") FROM stdin;
cmsf3ankr002avki8x1dkli3x	cmsezu9gz000ivks8r8x63ms4	lesson	cmsf3ajmf001jvki8kz0o4o25	Lesson — Conversation	new	0	0	2026-08-04 20:07:24.122	0	0	0	0	\N	2026-08-04 20:07:24.122	2026-08-04 20:07:24.122
cmsf6zooi001qvk3csrqurzec	cmsezu9gz000ivks8r8x63ms4	lesson	cmsf6ydru000hvk3c194futmg	Lesson — Conversation Fundamentals	new	0	0	2026-08-04 21:50:50.8	0	0	0	0	\N	2026-08-04 21:50:50.8	2026-08-04 21:50:50.8
cmsfant3d004zvk3clloi3rwv	cmsezu9gz000ivks8r8x63ms4	lesson	cmsfancr1002yvk3cvs6n1xqh	Lesson — Conversation Fundamentals	new	0	0	2026-08-04 23:33:35.101	0	0	0	0	\N	2026-08-04 23:33:35.101	2026-08-04 23:33:35.101
cmspgizb1001pvk5sioexkh9o	cmsevaz4j0000vkmkl9u1habf	lesson	cmspgh31b000lvk5s0agsdznn	Lesson — Les derivees	new	0	0	2026-08-12 02:15:29.341	0	0	0	0	\N	2026-08-12 02:15:29.341	2026-08-12 02:15:29.341
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.sessions (id, "userId", "refreshTokenHash", "userAgent", "ipAddress", "expiresAt", "revokedAt", "createdAt") FROM stdin;
cmsevazbl0005vkmkvpxyeg0f	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$tJpriknKy0j78po3NuaZWg$TyZhDKVV8a8ehA6qAPsvjMA5rC9IOZhXi5OIYupY4kQ	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 16:23:42.41	\N	2026-08-04 16:23:42.418
cmsevazrj0007vkmklx1jfuct	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$kkcYDFeJXfSgx2hNDD08Eg$qvyKU+zpRHW8NsPYa+dLGYWrok861MeLhNWnkxwgBY8	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 16:23:42.984	\N	2026-08-04 16:23:42.991
cmsevbo010009vkmktljj7zhj	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$eaXV8PrJ2USsIy44fTkPpg$EyduH/wXEH7a3KymmUKDzpRZrDIswOkbFfxuJB5ujx8	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 16:24:14.394	\N	2026-08-04 16:24:14.401
cmsexilqd000jvkmkdvf57c0t	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$RNNmbOzSNIgtGsI3ZpICvg$RsIjG1/CzOHQ17fawzhKNMtxDxBUroh8Jysq3pSYMjk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-18 17:25:36.997	\N	2026-08-04 17:25:37.078
cmseviiwb000fvkmka5rj0cke	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$O+2VbFm/RiPjcgWz81kvQg$ZbVAp+J0iOLTbG2u5B/eOuc7z8XK5rVkK57JQUXsQnc	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 16:29:34.377	2026-08-04 17:25:36.907	2026-08-04 16:29:34.38
cmseyvjl50001vks81ti3m5xh	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$0ByfXOwQamrwkR3M5FjxXw$uqkEf7UI1l/JrXTE3C4hRCV5X7q+v7Ucmlk6Ie2CWRQ	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 18:03:40.617	\N	2026-08-04 18:03:40.637
cmseyx4in0005vks8kz9cgidt	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$kvMxN4i9pBZMDgpykGda8A$pcG98/h4bj9vOFaIDvU32DVYs8/Le+Up0c3hOSnvRLQ	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 18:04:54.429	\N	2026-08-04 18:04:54.432
cmseyycwe0009vks82rfpjgwz	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$FALlzNqdPzmmvcZ2NINPfw$0I9zc9R6tq4Vtu9tVwpUl2hthoLHcKFRZAbXlNJW7wM	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 18:05:51.934	\N	2026-08-04 18:05:51.95
cmsf15kg1000fvkwcjkd3quhg	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$5dR8eHuoMQxz8QId0vDSaw$zhFXT9GK8jLb7s/TVNjvL+sRZV62xNWYFk6dDUY64ws	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 19:07:27.377	2026-08-04 19:35:02.828	2026-08-04 19:07:27.415
cmsezhcbc000hvks8nfx7v81u	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$bpCV+WTKfHQyV9nQgEsXmw$EVPl+9/M0xSeFqIIuzt8+J447sTUhrkzp05uiFWJg6A	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-18 18:20:37.55	\N	2026-08-04 18:20:37.613
cmsexilq8000hvkmkgnnw7ahr	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$ej45cd2sq19NY50TNjsqfw$V+Rh+1L2EChc0xpJvQsI8hQ2806HkIfEC5FhyOr7nyk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-18 17:25:36.908	2026-08-04 18:20:37.606	2026-08-04 17:25:37.072
cmsezhcb1000fvks8xju2ppkr	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$RI4isrRvMjVLQCU+fhUr/g$ZnYdNGYnwiNwiJzUHNF6Pn8Awg1UgzayogqId60xDHU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-18 18:20:37.607	\N	2026-08-04 18:20:37.613
cmsezvazv000rvks8653uq54e	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$0urQ9DiuRya054uvX31Upw$AdT4QyU9H0t1Uw6q674HRknyyJFiq8ltyGT0msMcvys	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 18:31:29.126	\N	2026-08-04 18:31:29.131
cmsf0mtp60001vkwcuhtlyn8j	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$dkjNawZt5rLsFRDtnXEmYw$vdwIztJzSqKRlDbx6wBPEHOXGsyMZQbKzQdbd1Ye+GQ	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 18:52:53.074	\N	2026-08-04 18:52:53.08
cmsf0nwia0005vkwcsva5wrtf	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$Kcwf6OWc+/7V7w2/a/cvHw$zz1iCWMff4Y+MBwO2HCTb9GyWYwR2skgrBbsSjjFSi0	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 18:53:43.376	\N	2026-08-04 18:53:43.378
cmsf0oqc10009vkwchbq99mkh	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$8Ev1vuMLPFwSsXa2zUp11g$LCt1jHrUy5j4HUzIuKNGlm61TP0CxFT5XHMxQeZtwTw	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 18:54:22.031	\N	2026-08-04 18:54:22.034
cmsf1226z000dvkwcrc4hi0m2	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$TjPMlb5M8/W/Z6txaUD2+g$RHRH5VIRcPLgTxWzqZu9nsszg4X9PRunhRY3DqQ3cLA	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:04:43.921	\N	2026-08-04 19:04:43.931
cmsezu9wa000nvks8sfdvvvam	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$96cO4VMpobae7W/BpT6HZA$R37D0kRflvxbJ5TsgMnA/7zjcrrlLo06W6/DIT/MzG4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 18:30:41.021	2026-08-04 19:07:27.376	2026-08-04 18:30:41.04
cmsf1w49l0001vki8ktq3ea39	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$amcAhQcASjQ4/dcdG1vWTQ$aZkeckzHak7+LAw5664deM7Sp/PBEw/D9MclYSEz4OE	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:28:06.283	\N	2026-08-04 19:28:06.294
cmsf1wvwv000bvki8u35qfeel	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$GABvizkzasdsPP/9jIyjxg$VYOgTB94CFmGctOFGtkkHaz7YBlOyzfmUPOr1Y8tN34	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:28:42.12	\N	2026-08-04 19:28:42.127
cmsf1xvhe000dvki8j76tco4t	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$Mw/z5PaQInYG3gUFm2tI9g$UiQXIvtU0Pnb/lLmztsHgFenmvFTSSVo2rRN+38m0l8	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:29:28.221	\N	2026-08-04 19:29:28.226
cmsqdx3hc002uvknk0jeu9ajl	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$sAqKY4z8zey5tOJkZndWMw$E7YGlKa2K/iRzR8/zLKdAg6/lGxnInEQcUpy+iDRaKw	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 17:50:15.221	2026-08-12 18:17:47.945	2026-08-12 17:50:15.243
cmsf24uii000fvki8oizlg812	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$nPF0EZ0gco8zRIdCWqAkaw$G4KXvgBG5AZorgCykl8h0EcfcJ1H3v/acp7ENqKY8P0	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:34:53.559	\N	2026-08-04 19:34:53.563
cmsf261wz000lvki8sfr1kjbm	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$IvN0+hIlww3XxyvFzPoRTg$SvHpbHLnpEf+aA8utM4RgW5+TRX2ZgPo1dpoWMbu+94	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:35:49.807	\N	2026-08-04 19:35:49.811
cmsf271z3000rvki8vmns3l33	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$6nHevWr0Rp/khBrXG9Q4LQ$pqMMA1G2DS2mnCanxgM8hdm55uow0wzstz8HCo33q1k	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:36:36.538	\N	2026-08-04 19:36:36.543
cmsf2hjfc000xvki8bf36zotn	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$h4iVZtsiNexA6hL/gmLJtg$O60BavmjEwM2m4Q5dq41QTW6S0sjddWmNmFpk11BeF4	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 19:44:45.442	\N	2026-08-04 19:44:45.445
cmsf251oa000hvki8p157u260	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$ODrOU7mqu5jYEsoRd87q5g$hHyjrWw0Pgf3gcXN+UOUt7Bcv00/ZXIXFpQaIwZEgYY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 19:35:02.795	2026-08-05 02:23:26.401	2026-08-04 19:35:02.815
cmsf6y2x3000fvk3ceybgjp33	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$IPGcCaEZt8iY8nMSOXSf1A$nrGjSZSKxg9FQnin1EraUd746hgGYNm+merlCKDp/7E	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 21:49:35.843	2026-08-04 23:32:57.41	2026-08-04 21:49:35.869
cmsqdy1jv002yvknkuyi0njoq	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$/5S/j8LVgHjdmxl7yzrVxw$kDH9VHgVmPfQzLVoPuifIWsoZxJDxCAitbdttk7Yzsw	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 17:50:59.405	\N	2026-08-12 17:50:59.419
cmsf390570011vki8kjq90dy0	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$klVn6DJbwYDVIyQi8O+CLg$WkExvpGX1jT7Ml6h+Cjo8Ye21+zFkXHNmMQnw200P2U	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 20:06:07.036	2026-08-05 02:23:26.401	2026-08-04 20:06:07.051
cmsf251of000jvki8ja6uf0ho	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$ikH/AZEosP0CtmkAWaX37Q$nDG43vtQYZF+OPwKDyaLlVwRdtonVFsa4XkfNgayFHs	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 19:35:02.828	2026-08-04 20:06:07.317	2026-08-04 19:35:02.839
cmsf546si0001vky8ou3upj4a	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$jl+B5n66Oo8fxpgMYjCIJA$9m0fzmlgikhRC0YMnJl9VRjI1zD2/KdBA6J/UcXXN/A	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 20:58:21.657	\N	2026-08-04 20:58:21.663
cmsf5cuuh0001vk3cjd9y3sc5	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$kFFfuDK4k1xyK86e0N5GqA$McS3LQmEt24bopj47i5z8JdmoiJNhFiI6zWDzbvxCrM	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 21:05:06.056	\N	2026-08-04 21:05:06.085
cmsf5x34g0009vk3c6xfa2bj3	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$NHZWlz2JRQXkai1Xf2ArkQ$jwCC2OzoC6MHDMeZFMQlLVNsDCwiBBSOo8nEzZUcv1Q	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-18 21:20:49.849	\N	2026-08-04 21:20:49.934
cmsf390bw0017vki87jjsjv37	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$bdCt1SK4x+68Y831cZXH4Q$ffsIKwtgFo0lYxeiKzDKRgIEPOufB8J+Srt1gNsXdAc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 20:06:07.317	2026-08-04 21:20:51.295	2026-08-04 20:06:07.326
cmsf5x46v000bvk3cfbki9ptz	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$l+kWThHroPoa+xLdEUhJAw$gSq7ssP/1gHdcRFsSB4UBZ4skAXus247JXJNYcxwHZ4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 21:20:51.295	2026-08-04 21:49:35.842	2026-08-04 21:20:51.309
cmsfan0ht002wvk3cr0q4iwou	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$7FAv5To4OfPu1pNtk1811A$L5Ptg/iuke/caygS9vdr+5cw4waKucHw1EqdIOtzW1I	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 23:32:57.446	2026-08-05 02:23:26.401	2026-08-04 23:32:57.479
cmsf390fs0019vki8orrloa2q	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Cf5ww6s3jAD2BHJSVRZCXQ$/8VH4MtTnRgpu5hJnoO4XNPcl6HhieziCiccZLl5ZAY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 20:06:07.32	2026-08-05 02:23:26.401	2026-08-04 20:06:07.33
cmsf390580013vki846fxqhv5	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$tZ6+3W5JPwbQXUuavEkmTg$QFriEeJLN8YaQ1hc00+eshvDWtd32U5DcNx3Y/ENMm8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 20:06:07.046	2026-08-05 02:23:26.401	2026-08-04 20:06:07.054
cmsfan0he002uvk3chgil8j91	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Oe4vCZVBdi/QoI0bIHxQbw$yAIiA5Im/QLUNDfSrns439yy9RutCa/ZJm8eAyc0r9A	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 23:32:57.411	2026-08-04 23:53:06.788	2026-08-04 23:32:57.469
cmsfnp224006bvk3cv9mstwde	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$o9WGoy/cz1g1EajpH6S7LQ$IuRIC/D9hi7DnQko751bPKAgvp3j2Ks4Ri96fkxF4xc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 05:38:28.335	2026-08-05 07:26:18.734	2026-08-05 05:38:28.363
cmsfbcx6p005lvk3cf8xcyiki	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$lLKKDd+zRgL7MeW5fEtJVA$wI2uP8CxAHZrm1YWQw4WSEav13Bh8ACUQ5XWf5TG5R8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 23:53:06.789	2026-08-05 02:23:25.958	2026-08-04 23:53:06.801
cmsf39053000zvki8i8ogihf6	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$7Eoqw4grSHJ+Cxl8H/HX0g$FJIX3rmVu95tU7bFZnZ+lKaqBssZsHjApjOJUrSu9jY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 20:06:07.07	2026-08-05 02:23:26.401	2026-08-04 20:06:07.078
cmsf3905h0015vki8jyuvtsmc	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$mc1j+yMHeKyS82f3RVOzJg$MpZypsnNKAJhpHLHUigT4m8u+U0J6d0K93u28HZSr2E	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 20:06:07.08	2026-08-05 02:23:26.401	2026-08-04 20:06:07.089
cmsfbcx6o005jvk3cvtwzxqi8	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$hKL/jPFBEHc4id4e9QAopg$Foo0bEbN050PpI5iBqUqAaX9rR3x1P125gfZgvg47W4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 23:53:06.782	2026-08-05 02:23:26.401	2026-08-04 23:53:06.786
cmsfbcx6b005dvk3cweqx4st3	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$8VqvF49daIO4gqmPG/2zww$LYgmTny6nTHjN22OxRHhEemE1LkPYjePPONUqAhh6+Q	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 23:53:06.532	2026-08-05 02:23:26.401	2026-08-04 23:53:06.558
cmsfbcx6f005fvk3c85qz2x4h	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$clS+EgB+2Ypvn9dRDY7w+Q$FK8RaBUhETqs1lwAmgoIY2dK19vrNXwyLUsFbhJgpjo	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 23:53:06.663	2026-08-05 02:23:26.401	2026-08-04 23:53:06.667
cmsfbcx6h005hvk3cdsjxsyhs	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$hXU9oxSyiQb9S7T9+fOP3g$cKSP9rUY9SELyip0/Krj/KWGK8iMTa72EACG1nYRhpE	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-18 23:53:06.55	2026-08-05 02:23:26.401	2026-08-04 23:53:06.559
cmsfgq87v005nvk3cukyni51a	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$MNLOnwT/iRiCWaV4pbQzDA$FJ7vMDVr/5e0ym2qtEo4SPGKGPDcV1+YcINaYetbqTw	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 02:23:25.491	2026-08-05 02:23:26.401	2026-08-05 02:23:25.52
cmsfgq8a9005rvk3c2fz7agjt	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$1sVH4vnJg+U069R84yKFeQ$WuoHmYg3ylikOvx5DZtgA8pHmGjh5Wqf2cvcYkCyK0o	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 02:23:25.737	2026-08-05 02:23:26.401	2026-08-05 02:23:25.74
cmsfgq887005pvk3cs9qr0985	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$lEVfGjUVyuNod86lo6/qsQ$qnYHK1FuOlLit5bofDu1yK9ZWrrP9OgbrTEdM3ZxbdM	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 02:23:25.602	2026-08-05 02:23:26.401	2026-08-05 02:23:25.605
cmsfgq8hy005tvk3cxetpp0tt	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$JDInYHnhYYOJ+DBjHtSpng$XB4IQIHgd8gTy3ysd4LH4JIxirAAEiT8kI6rk21QLY0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 02:23:25.958	2026-08-05 02:23:26.401	2026-08-05 02:23:25.961
cmsqew4cl0030vknkl7gub0b0	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$upbVEn90qJwJzBX3Pulqrg$sSuVREJh/N8cUsnNCm+SNJ1cN2cHxBGYueWred/l+Rs	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 18:17:29.328	\N	2026-08-12 18:17:29.345
cmsfhkw6g0065vk3ch84it3ez	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$AMNcGmnAS/LesV7v3Av+tg$Fyd00dWSmVG7ygM0Y/MmYcksxP0hMsYIgouifF4tkqk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 02:47:16.449	2026-08-05 05:38:28.334	2026-08-05 02:47:16.456
cmsfpej8w0001vk94pg0e35mn	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$g2OV9OU+nLgONzr2sUWDUA$5NF+NYMds9BQAzGWu++9aZsAZwY/N0E2FUCoFMOUXlc	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-19 06:26:16.667	\N	2026-08-05 06:26:16.685
cmsfpfst8000bvk94qmhz0m7w	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$JIhZjX5I64i0jAz1N0+8KQ$lMs/dVprXncCZ0t+jdTnxSz2F10WHHiHN7NSnTqcemg	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-19 06:27:15.737	\N	2026-08-05 06:27:15.74
cmsfrjhm3000wvk94e3pokezg	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$I4R1to5SDgZlk50rIfkPTw$qAoZjrJDEVHWOQlergqrSGayKLU/cuyFoZeySz5/bKA	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::1	2026-08-19 07:26:07.078	\N	2026-08-05 07:26:07.082
cmsfstq820014vk9430rvwc2r	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$wPy4w9fx+/MfjlpKOu81Rw$eJNTY4j1R2xJZbsK8MY4JR3XRw3hi2tji10blxcG13o	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 08:02:04.341	\N	2026-08-05 08:02:04.383
cmsfrjqm7000yvk94sns740tt	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Z5QqDkerfUBjmpbo6YiDkQ$q7cnz/+oQAvdAq6+WktNNnf2Vf56zHk/USEjJPYi0Aw	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 07:26:18.735	2026-08-05 08:03:38.596	2026-08-05 07:26:18.746
cmsfnp22w006dvk3ct4g1fhes	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$QovCDX91l37CiVNopNbdVw$Bsd61pTqF9a3fuIm3R2LUlkxxVMVktN+ItW+B7WU27M	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 05:38:28.365	2026-08-11 18:45:45.956	2026-08-05 05:38:28.38
cmsfnp23y006hvk3ckvv91yfk	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$NkeaeGUIkjjK2q4fXoSccA$CmQ7e/KRArm9l8xeZfVJvYjbuFViQy6ObrcoEbqe1LI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 05:38:28.42	2026-08-11 18:45:45.956	2026-08-05 05:38:28.433
cmsfnp22x006fvk3cqrj3whyc	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$V3AMuQGliT5ipziD3r4Sww$4POZfJ2haqwzFykykpUBW7aw0j3fFgZwhEvh5k34z9U	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 05:38:28.347	2026-08-11 18:45:45.956	2026-08-05 05:38:28.377
cmsfsxgv3001avk9411spgnr4	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$fPTuewQEJGJ1DtdVuQhq6Q$h3Y/vScX1+cgA3j+YoPTlpYD4+j2mY7zUuIfRStJRN0	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 08:04:58.906	\N	2026-08-05 08:04:58.912
cmsftpkvy001ivk949ucunypv	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$3QzMTlIsHgKbNH/Q3p6bgA$fHMh9fm/e1AmhNZPhzfIftCOsA3tAocaD0giBOpqKcI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 08:26:50.398	2026-08-11 18:45:45.956	2026-08-05 08:26:50.414
cmsfsvqwt0016vk94iefqs42y	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$MBC9mWBSahw5j8O1bVTV7A$CvHsK3XQxXLaXVrznXLMYG0WDrzlXk8/7HONVEZqDbI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 08:03:38.596	2026-08-05 08:26:51.095	2026-08-05 08:03:38.612
cmsg5q4ic0007vkzo69d7zj2y	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$AhI5LLFpsWKNpzH8uqJcwQ$Nwc0hVW0R5t2sn1BAhI+rMLRLoW5h/0iqUc2G6Wy1js	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 14:03:11.287	\N	2026-08-05 14:03:11.312
cmsg646h1000bvkzo79uygmr2	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$3BQW5VpN1kH3xgmmwEQWEw$5yzB8vBzdp+V1S17F1+2bHW3MWl5zcZfQo0toyvizGY	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 14:14:07.031	\N	2026-08-05 14:14:07.044
cmsg7u7uz0007vkookrm38ks1	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$7ayobQ/GbMFzsTsS9u4CcA$9KSLNFXuW3XXmBb+Y9PSMKHjmJs3xxGG+ATMlrkgNDY	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 15:02:21.496	\N	2026-08-05 15:02:21.513
cmsg7v7vh000evkoow8jwztzg	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$sNcjdN6YVwVteUKKLO+qIg$4Xr2/EdPvppvizvgrEVnPtwTSTX0xIBoTFo1dn55sBY	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 15:03:08.18	\N	2026-08-05 15:03:08.189
cmsg8b9sd000mvkoow457n4e8	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$IlG0qy7+cJ0iKJHngbFuDA$MDiS16nlmpyM2PgwWJhExrk5VXQXxKOmdtbZtG3I9ts	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 15:15:37.15	\N	2026-08-05 15:15:37.163
cmsg8cx7g000ovkoo8nhk4kcg	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$1pvKl+6Chn94v2tiz4iUKw$SyF08PLMtkEDvErMShUNrVO3Z51udAJ/gJkOI4DhySE	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-19 15:16:52.512	\N	2026-08-05 15:16:52.532
cmsg8cxxj000qvkoo0ih4fkop	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$RWrn74lu/1ExP0ZNkchzaQ$RFRw8ot6iRXuCpIviAn60T28k7Q6F06x4jzeZfc5b1I	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-19 15:16:52.432	\N	2026-08-05 15:16:52.635
cmsg8d0w8000uvkoo3fnydb5w	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$HK2J7apElSouCFKnxmlGqw$COldXUmEveme1P6ZHFfdsVeRMPUa9PUbXcUBamevda4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-19 15:16:55.683	\N	2026-08-05 15:16:55.696
cmsfrmit00012vk94jmoioxaz	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$2A60jspNJZ0EubQbVQwoTQ$c7n/7xleRIXKJiGYKwTaVs1tq2v71/5YYb+kq17PRkY	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 07:28:28.591	2026-08-05 15:16:55.679	2026-08-05 07:28:28.596
cmsg8d0w1000svkoo2iobmj51	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$Ozt5ygU3VYH0UthYRWWdLA$jFaKoMp0AWI75/DOAtl/yKF18lzhUidlJ+0+9uWQ5Kc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.24012.11 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-19 15:16:55.679	\N	2026-08-05 15:16:55.692
cmsg6tsnf000dvkzoyy3ys6d6	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$zqPhg61+zMACUYgcjlzNgA$z8+DrV7jMKKq6yj4fQKzrul1uk5hbHmqdsadiIHodQU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 14:34:02.162	2026-08-05 15:17:12.435	2026-08-05 14:34:02.179
cmsqganz70007vkogv7m0fn4y	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$m+P0hcSq2J57+QfxODOaHQ$Tb5Qmmvg3zGBcH128giEnjL+6o4MWc7bUNVQKZhBgZo	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 18:56:47.555	\N	2026-08-12 18:56:47.581
cmsg8fn16000yvkoof933q11h	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$v1nFJFCrvZ/RqO1n4llUpg$rQQj0KvhMmogoLF+ZVumN5xcoT3N+Ih+fXhfQh7k0bc	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-19 15:19:00.953	\N	2026-08-05 15:19:00.955
cmsqgc1cw0009vkogwtiqcqp9	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$UWRuwnNH2f7ES6NK62meSg$C577NMA5kn3dac9ofxrvxeyWXFT7E/CAmJOLOPcV8xQ	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 18:57:51.582	\N	2026-08-12 18:57:51.585
cmsftpkvx001gvk94iw3g4mqj	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$8aDuUUsTmFpsCu/37I18UQ$6Ya2Todo9z41+sv2zzIIYL4rKxpGynHYbu1in39UI5c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 08:26:50.467	2026-08-11 18:45:45.956	2026-08-05 08:26:50.476
cmsqgc5iq000jvkogovv6ypa7	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$dVhxHeCP/YdQSKZ7v3IMyg$q37tiVk+SrVL9rdKH2vLATYTMn+iaLOySC1vJ9r/8eg	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 18:57:56.976	\N	2026-08-12 18:57:56.978
cmsftpkvt001evk946get2z20	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$e2UXtLPZTVnkWrYxyCPHtA$e6awKHpXxjgA5l474u6xTgjw6wGBvOttYtG2o91NDpI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 08:26:50.401	2026-08-11 18:45:45.956	2026-08-05 08:26:50.457
cmsftpldc001kvk9484y4kq69	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$qmRvupQguNHakDNA/XLycw$pNchvI9htsDWc7aTr6X+rpHEzcY2rkz+OmTHSKwH83E	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 08:26:51.096	2026-08-11 18:45:45.956	2026-08-05 08:26:51.105
cmsg8dbct000wvkoolb9tclld	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$mkY34iVZga6iKZtDJKQy4g$hrkA3Vmu3oTYuxAt3DLdJenIj0OZg933CnD+le5VPcQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 15:17:12.435	2026-08-05 21:44:39.241	2026-08-05 15:17:12.446
cmsgptdna001mvkooe7way1nu	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$bwStwqtW1srh4aGYZBDBWw$CxoTrPwYsJgawTuC822NwRjy1yRGJsB0akbyJAXNv3g	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 23:25:35.281	2026-08-11 18:45:45.956	2026-08-05 23:25:35.383
cmsgptdh6001kvkoohaacznns	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$moztHGaXvk/6DiA1kVssVQ$Kg5hAT70bU/sP4uVp9hkmojaEbOgGOJ4QJQ7cHdo0Fw	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 23:25:35.144	2026-08-11 18:45:45.956	2026-08-05 23:25:35.172
cmsgm7knw001avkooi8s9jkwk	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Zau4LxKmizhbBKniejNqKw$6b2Bjo4SeXQitYDMdet0wBV72aKQmCQzQBRDJp1UtMI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 21:44:39.241	2026-08-05 23:25:35.162	2026-08-05 21:44:39.246
cmsgvd92u001qvkoouvihxqz9	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$ZcvqJcLONCYYFNLjFMX1pw$mEdFImireFSemWIqjgLAKFhDZkjOQMkKbT1asSWj8iY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:01:00.653	2026-08-11 18:45:45.956	2026-08-06 02:01:00.658
cmsgvd933001svkoogapbejf6	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$91UhQqmRweSdAUgiQzdXJg$r/evUEU1G19w20izXmMWWFa/Ig8h+AWYPmOStTBrQ5Q	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:01:00.522	2026-08-11 18:45:45.956	2026-08-06 02:01:00.573
cmsgvd92t001pvkoo76301zcd	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$SvD0Iuqf9IdWsSkEU4Sv9w$2L/UzCdKeW7XgjEte3OmRy9uxIXps9aUIL7uJIV+wxY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:01:00.676	2026-08-11 18:45:45.956	2026-08-06 02:01:00.681
cmsgvd99z001uvkooqeql6n3b	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$1S0G/2b5XEoPa3IGoES6/g$T0eLdRBVYEaTWQNIrp7n95ezlS7qLobHcrOF/PyENRc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:01:00.873	2026-08-11 18:45:45.956	2026-08-06 02:01:00.878
cmsgvd9ef001wvkoozvk6lgvh	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$f2mQs4NhDznTNtXFdcztqw$MpkHrjSFKoXGBevhZYP814Q8s//aKP72U9j3dQ4RleM	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:01:01.123	2026-08-11 18:45:45.956	2026-08-06 02:01:01.13
cmsgptdgx001ivkoot26a4l7w	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$zz9kBgbEZGup/GIUGi4/3w$M/ZxPNZRFZhm/mxdOYIjHZLDCeQjC6/uNY59bdd8EsE	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 23:25:35.162	2026-08-06 02:01:01.127	2026-08-05 23:25:35.176
cmsgwyjko0022vkoosbj9bn64	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$exVNTFSlbIWPSQk08UUytw$jZwMnoDFyPDivd5vN8rcfninbJls1864eZ/MyG/DnoE	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:45:33.696	2026-08-11 18:45:45.956	2026-08-06 02:45:33.706
cmsgwyjkm0020vkooyahsaepa	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$XI3DdVTqAIwm6gWS0y5n/g$n7CfoMxsv8yZU1QB123n26RsJda1arCyQJIrDpmfbP8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:45:33.678	2026-08-11 18:45:45.956	2026-08-06 02:45:33.68
cmsqhqe18000vvkogwqa5vsb3	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$VuMLSbgVglrhwA8YL3mpbw$RgEX8ud19Dj5pWKWFsMA9L3vIEZ7nH9cJbOhVxPqktc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 19:37:00.788	\N	2026-08-12 19:37:00.79
cmsqewitw0032vknk25m769dx	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$qq9I3T0X0OdGjxg2mPWqXQ$8R+YbqjkMjbTFWM+L6OV+bRmXvjk78UR2D79C44uzE4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 18:17:47.945	2026-08-12 19:37:00.792	2026-08-12 18:17:47.98
cmsqhqe3u0011vkoggfdf89uv	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Pj1eXvFSUIiO/5F31M27FA$0c6F89ufL7u4OUUjnSSLBhfAGaVKJXEr7d0X8vCc5HY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 19:37:00.793	2026-08-12 19:52:18.658	2026-08-12 19:37:00.812
cmsgvd9gr001yvkooy89puls6	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$yuWYGNMXrJLwRdQzaAhc0Q$5KHmXFf4DS878odH4lZ/CZHeqbKo6d3zRThUfRFNoPk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:01:01.127	2026-08-06 02:45:33.635	2026-08-06 02:01:01.135
cmsqhqe1b000xvkogmz4hwn30	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$RB2xO9wNZCQIkrQBEnYe3A$k2AJvi8o0OxlX/4yV+eML59fAsqd1RrDVX5kKFcG1o0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 19:37:00.794	\N	2026-08-12 19:37:00.812
cmsib50sl000xvk5ghwqh44n9	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$9iQXG+9WwIgBWet1Q0NeCQ$ZSU1qN2ivCjrDE9q+OZ8JTSkiNjGbwfSsNz+J37S5Ro	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:10:16.771	2026-08-07 02:35:45.282	2026-08-07 02:10:16.773
cmsgwyjkq0026vkooegq6mmu9	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$fuoaT72cxpqqoaEV5ZIj/g$Qfeq1o+wXSFVOeDWFQP5s93VzDuso8NrMxWjxBIA6ec	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:45:33.704	2026-08-11 18:45:45.956	2026-08-06 02:45:33.71
cmsgwyjkp0024vkooji2s29rc	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$sk8QJjv6ipkuQ68uvoh9ig$fJZT5mO0w1s2pPoNXbTLyDhZphkMuy2jmGQxEEhzEgo	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 02:45:33.635	2026-08-06 04:13:50.905	2026-08-06 02:45:33.651
cmsiark6g0007vk5gicjsswsn	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$gg4Y7Nxj36cn+MAXAkbKpw$SWaGy7qo7OJSKg4EMw5+zLvH48mAGB7fSW3heJf3yos	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 01:59:48.696	\N	2026-08-07 01:59:48.71
cmsiasdlq0009vk5g24va69bb	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$rmv4NE03HV6iV8uC35BnUQ$QpKqX/6W9erwxLe3s4/qGGw6RDDXVtO5e6ZBe2oJgo8	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:00:26.839	\N	2026-08-07 02:00:26.847
cmsiay7gz000lvk5g6hzivr7r	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$9MS3uXjOCuPwpWNuqJYKqw$pbpbunhgtVAtcMibJyoeJ0hHKgWvrMQZC5AE1SUI9nA	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:04:58.826	\N	2026-08-07 02:04:58.835
cmsh0431m002ivkoo1e55pzt7	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$QMk+PiW7JcmV4k8bOZmkvw$iH09o2vCMbLuU9PfXVltdhUdnib9+JtIad0/vy6hD3M	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 04:13:50.905	2026-08-07 02:07:26.176	2026-08-06 04:13:50.932
cmsh04334002kvkoogvnqi3y2	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$HPun6cSLY6JumqTLVkKcuA$PZbJD1GpYQvBsLMUXschBheMSQl59VhQYsIVp0lt8D0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 04:13:51.031	2026-08-11 18:45:45.956	2026-08-06 04:13:51.051
cmsh04339002mvkoosjp64h8y	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$7jQH+lxpPnT6go6UdSmxNQ$qvnt/j0baGrr0dd9XFTg9DKdXh6K/hqawfIjuN8G2bo	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 04:13:51.03	2026-08-11 18:45:45.956	2026-08-06 04:13:51.047
cmsh0433l002ovkoomplc32xu	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$FcuXTzI6tI7p9IENqzM++Q$kcMfOxv1Wz+cdzWFZdxgy3nKh0RjlZ4ieBNWM16Ac9U	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-20 04:13:51.077	2026-08-11 18:45:45.956	2026-08-06 04:13:51.094
cmsibleml001fvk5gvqcowexc	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$VGGNoCkaktPEjSxqvqEqNg$cPj9KjiTqLENUodbFVxnWjyTjLFeZbJSrd9AlBBnCwk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:00.186	2026-08-11 18:45:45.956	2026-08-07 02:23:00.576
cmsiblfhy001nvk5gpe2flniq	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Dw6KOdn27IqxoTOkpmNYKw$gkmIUfNVYaErYvZ/R7J+3Ce8M7PeBJsu4Ciy6bsdvV8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:02.033	2026-08-11 18:45:45.956	2026-08-07 02:23:02.044
cmsiblemq001hvk5g28022tgw	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$qUsj+fjUltlFO2yb4STUMA$+EhYjTu3E56NMn7OIYcHiUhsTO518pirs9NnWLZYx6Y	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:00.202	2026-08-07 02:23:16.728	2026-08-07 02:23:00.575
cmsiblooh001rvk5go5euqaa5	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$A2XvJ7aPIDtkrQlA8bdDPg$yB4FNdjLdnopGiDYBXHhd0lws++apvbKWfGaSZFtA6c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:13.249	2026-08-11 18:45:45.956	2026-08-07 02:23:13.26
cmsqhqe10000tvkogubzdpnjk	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$79Bg6MyzIa/42ZbnNLxB1A$xPpF6kQR4hcy4kHd4567lN7T6rHZX7Fc5HCjZqYqnWg	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 19:37:00.631	\N	2026-08-12 19:37:00.655
cmsibleuu001lvk5gm9g08ssh	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$YujiulVRAua6r42Pp43Gxw$G8GTKi9T3WpIBD7n2YGbNOlxSkuIMSY/PRkwWwGRz88	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:00.964	2026-08-11 18:45:45.956	2026-08-07 02:23:00.976
cmsqhqe10000svkog1x4ih8io	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$L0JrfzBk1CgRXRQx1bqZfw$aQErseWffKSUHr4kaMev6vE0hJfApU0j747FRXOGbDo	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 19:37:00.626	\N	2026-08-12 19:37:00.688
cmsib1dfw000nvk5gnort97ve	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Y3C2KImb5SfzgEmp+astHg$qxBwlCh3K26OswioTFvULKE39nbnCXcWYj3lPLX8m/E	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:07:26.176	2026-08-07 02:23:00.969	2026-08-07 02:07:26.189
cmsibrd3q0007vkg8upt562dm	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$aivFF7aWhuqelfyCsMzNqg$SKw8gwqbIBNbhXDUkvov+QxGbznbo0vvUI+QC8H5Rfk	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:27:39.144	\N	2026-08-07 02:27:39.157
cmsibrdqz000dvkg8p2a1kunu	cmsibrdj40008vkg88ef4wjk3	$argon2id$v=19$m=19456,t=2,p=1$rtTXSLtNv62E0v78pynZsA$tp7aqbn7+cc7to6/9MEH0qR+DmnrsZY1MG5uoUiUS6k	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:27:39.99	\N	2026-08-07 02:27:39.995
cmsibreag000jvkg8kgw7u4yn	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$qD2fPvAyRWtI0xA+pmbeZQ$A9TXYdMSU62cA4drWhek63WEzYX4S+W7/MUVssDrr6I	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:27:40.691	\N	2026-08-07 02:27:40.696
cmsibs3q4000svkg8folfnidz	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$Qag1glvluZORglyoVQsTIw$tiDtYcZmKjXHDHbHWLIb0Tx4JPUhWgvQ+h/Avd5fxVE	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:28:13.658	\N	2026-08-07 02:28:13.66
cmsibs4b0000uvkg8vvgcdbof	cmsibrdj40008vkg88ef4wjk3	$argon2id$v=19$m=19456,t=2,p=1$LuynNWAZ50mPMdnKlBJWtw$D9ppG+/rH+CViSc9UFpsfgd4BGAE1hgKpd3EFIny+rs	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:28:14.411	\N	2026-08-07 02:28:14.413
cmsibs4tm000wvkg8l50uyoor	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$iaUQSZPOmNWQjEYvMY/wCg$t3HLEtVHaomKdIUZ2exIIePDghOMn4ltlxJ+OdfrSP4	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:28:14.977	\N	2026-08-07 02:28:15.082
cmsic1sak0012vkg8jpzcskf0	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$cQXTi/5w6pxuG/MtYK75ew$yTIhS4Lrlw0MTamLoQxqGftEP21Rpxfr9pWUeq4HrUA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.25927.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-21 02:35:45.261	\N	2026-08-07 02:35:45.284
cmsic1sb50014vkg8byyab8y2	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$4kcqIyBfg8C1mnwD+CujHQ$Df5HmUh+G7FbeJOL9FoGQezeACqQA2YDxf3O9UxFotE	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.25927.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-21 02:35:45.283	\N	2026-08-07 02:35:45.285
cmsiblrpf001tvk5gz4g2yh0v	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$f5AcfJh/jASPHkbrZYpQwA$vLXXw9qH6OprFgYsMS4NRvk72FxBP2bLH0J2uPnazqY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:16.728	2026-08-07 02:42:06.44	2026-08-07 02:23:16.738
cmsic2vwx0018vkg8wnc2c5ef	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$nI0yVM1Y3VOxvWIuJGTeiQ$TWx443+4sBGPI53LFQrEUCUNFVE7CNLmrM7c2j7qkK8	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 02:36:36.751	2026-08-07 02:53:05.148	2026-08-07 02:36:36.753
cmsico2kn001evkg8ym01wztf	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$6SY2+glpOzV98PzGOuWCXg$YpwvIN+Q520YQqo8RMPTUPggicQp6sKjyN00o2SSDLA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.25927.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-21 02:53:05.149	\N	2026-08-07 02:53:05.152
cmsic9yb1001cvkg8vzv7ol93	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$7ZUkMsKLQ/fXopnargKFuA$upItMk5QiWU8W/wDmd4cL0sTWfH54+/RnLAloUb5cSM	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:42:06.44	2026-08-07 11:32:52.432	2026-08-07 02:42:06.443
cmsqhqe1d000zvkogypftoosd	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$6IQGtRrnxz+ghPUqM87ZrQ$YBKZ8Jl12yeejk3UeoA4nFEYDdku/iSX4CFA53LnQvc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 19:37:00.79	\N	2026-08-12 19:37:00.812
cmsiv9bg60009vkxkrq2obz8c	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$tACquWIKoBcy3F3hsVETHA$imSPU3b9rASVF4/gqPnbd+cErUrupqJsmDcRsefI094	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 11:33:29.514	\N	2026-08-07 11:33:29.526
cmsiv9bym000bvkxkaceo1n5y	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$gqJ+lsV6Inqx4D0f+AiF7Q$6MU4ZdBiE0IZ8+QwudU+0YxXPUQB9MsIzrCKeamGEME	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 11:33:30.179	\N	2026-08-07 11:33:30.19
cmsivboe2000dvkxkpcrt75cf	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$9nmRy3BeIRVOIFOCCRZ+XA$k3BDCOfLDypelSi8Nx+dyVSN60UzeP1duIm7HaX+aFE	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 11:35:19.597	\N	2026-08-07 11:35:19.61
cmsivbp48000fvkxk7vpiqum5	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$7dCQJgbtMvfu7I03nLbuyg$lbsbSXC2PY/WTnhXMkN/4ICFfRDKxgSirPme6mm4NQA	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 11:35:20.54	\N	2026-08-07 11:35:20.552
cmsiblh8i001pvk5g2zceub9h	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$LgO+HBWHRhvNLseZV2rffg$VjaoHA6DHfsr2zEUYZn3ow2wpoh/09/KVMDgXViThH8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:02.863	2026-08-11 18:45:45.956	2026-08-07 02:23:02.874
cmsibleut001jvk5gd3tl7dqd	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$VrKTthVCe/J8/QD8JGZ1Cg$esNb7QOE2gUJjVHaEtOlCHsSuZwh5ZbOksQWGXLgtxs	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 02:23:00.969	2026-08-11 18:45:45.956	2026-08-07 02:23:01.125
cmsivuryo000rvkxkjaf82z9b	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$3UhlSe/E6ozqQzl1OXozNg$M56wTbA7w2F6kD105TpY1ioXS7ZeoS/z+G1OVI6cCXo	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 11:50:10.623	2026-08-11 18:45:45.956	2026-08-07 11:50:10.631
cmsivuryt000tvkxkfd6z069y	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$EYqFYgltWMIazohiB0YE5g$8wpL5A/V48MhKd9cV0DgXJEKIj61nqwIGZr2fQchIL8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 11:50:10.619	2026-08-11 18:45:45.956	2026-08-07 11:50:10.628
cmsiv8j090007vkxkrjnkkyt6	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$21Xm8cgOixENTB08FfdcGw$FZotEg1oljOw5MZadr7oKP0SDgPc3saVbjBQZhdc73Y	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 11:32:52.432	2026-08-07 11:50:10.708	2026-08-07 11:32:52.532
cmsivxjdp0011vkxkvzbkfye8	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$iV+m5fVwk0G/n+L6oQtt/Q$4UeHmvaEjypVDaJmL7HwAbF2acAd/xnKZj0QKi8tPi8	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 11:52:19.546	\N	2026-08-07 11:52:19.549
cmsivxkkb0013vkxk2pi9zl4d	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$uL5zSEZxdLy8rR2pgULeSQ$Zon0TYJfD5ybdiMAVRhpT1Yr+KwFUA49YYTa4+UMdeg	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 11:52:21.08	\N	2026-08-07 11:52:21.083
cmsivuryx000vvkxku12fhek2	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Ei+TXWxipKrdjuAZR4v43Q$GbnvhKGF7CLJwxIDtUjcR997bj2FQ5+DICLhCwzHbFQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 11:50:10.698	2026-08-11 18:45:45.956	2026-08-07 11:50:10.706
cmsiwe37z001avkxkvdxbtyhi	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$PoSr25lKeqL0Y4bfsy6BvA$RvgL1RLUvDtxJDt2VTUjegD0PCuWmWHc0lR9GRpoQ2Y	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:05:11.581	2026-08-11 18:45:45.956	2026-08-07 12:05:11.641
cmsiwe38j001gvkxkoq335yps	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$A8Tg9O93FkTmN2e3G2ekRg$4MWMgnJicdUJBcsC5KxEC0sOT5AfKzaHgajmAu2NsHQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:05:11.755	2026-08-11 18:45:45.956	2026-08-07 12:05:11.76
cmsiwe38q001ivkxk981zlnxp	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$6JPbHG3zJgPogUNF+5MtLA$8wQS3T4Lm/1hqq60cyqnKBVvLiH/hbTawGKSmvMhNY4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:05:11.763	2026-08-11 18:45:45.956	2026-08-07 12:05:11.769
cmsiwe3ad001kvkxkrd6602fq	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$QyXR2fWQQsTU791S80RUSA$w4YEAVsZ9Qc9HuLC+9l7h+B5K+FEAn0f/tQA++8GJ9w	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:05:11.779	2026-08-11 18:45:45.956	2026-08-07 12:05:11.783
cmsivurz5000xvkxkl9wlgejx	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$dIJaCBtoM840OYZ4dtCI0Q$32tOVRX1gME2EXJ6LWzZkZQau2WCDQenfMH2HpM0vGc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 11:50:10.708	2026-08-07 12:05:11.759	2026-08-07 11:50:10.716
cmsiwi2li001mvkxkzcvfrv9n	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$DZ9VgpX+55gk+f4XmgGOZA$O8g3wEIOlbc4Kaj2uKarIUrj4m/l4cjt0qvyLmAtigs	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-21 12:08:17.567	\N	2026-08-07 12:08:17.574
cmsiwe380001cvkxky6ofb5ne	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$fwHZ6qNc9fsobuPwmXNMNQ$uH9x1UZakCFe3k41BdDEFt1k38L+89tvOSz2Ty3iXJc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:05:11.584	2026-08-11 18:45:45.956	2026-08-07 12:05:11.591
cmsix9wr9001svkxkscgwlj8e	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$YzoswyhUZp/OLfKAvZlEBQ$MBRXDSWnSv1x8qu4puheDDgGK6OGPlJdFLmE9md3vNU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:29:56.35	2026-08-11 18:45:45.956	2026-08-07 12:29:56.354
cmsix9wr7001ovkxkvimcygon	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Vyufw9KWR8C8W1KehGX2IQ$qa9FymTgGbkeJcrigZr/c0tiaXERNtXUUngCLu8Ktk0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:29:56.098	2026-08-11 18:45:45.956	2026-08-07 12:29:56.107
cmsix9wr9001qvkxkd9hsag09	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$p2xYXf8hvEdKFOZ/Vr4Baw$u4yK+iPEiM6jPojRtmObUl50lAK3JaVC1t7sk/zTHcU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:29:56.229	2026-08-11 18:45:45.956	2026-08-07 12:29:56.302
cmsqia2950013vkog2oabgsy4	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$kISDcIaSY0x7Os+xAiYdcA$TZyhHdR7ub3iFJbgToE3qr23qXNAysn9xk8SGq97EqY	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 19:52:18.658	2026-08-12 20:09:43.941	2026-08-12 19:52:18.66
cmsix9ws6001uvkxk4lqmexih	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$AkYXy44z4YVzAW8/Y4SztQ$d/dYm4Hvzx9Dkd7e3qkIXkw6LqZ1OoivcMQA9tr9WDU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:29:56.351	2026-08-11 18:45:45.956	2026-08-07 12:29:56.369
cmsqiwgtg0027vkogatv94k8r	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$t2YZjW0ecx7GDJzgEKqqvw$eBwhiNL+erjT1OdSMNBeNNlGcK5UuWO/BIqgbpahJRI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 20:09:43.941	2026-08-12 21:09:53.015	2026-08-12 20:09:43.944
cmsiwe38i001evkxkeb8p6hpo	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Hq2/C6ZyLFARSyWPZE5lUg$tcBFSN0YDpIqeUf8LGCE60l7pWEvhSCJE/9n7mnkYQk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:05:11.759	2026-08-07 12:29:56.399	2026-08-07 12:05:11.764
cmsove5nx0007vk885lvf4q1q	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$U2rQfqNe7afIgwohIJHmUQ$YMsYjnnTD7E01LuKEgebI6loLww4caVL6zbRLIoTuLk	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-25 16:23:52.343	\N	2026-08-11 16:23:52.361
cmsoymasr0007vkko4adu030c	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$SB0UUOgRzOPC4+eclyvA4g$uAPDAJXCiataP7MmxEK+wKxebEZ1tiMLz+4uep2j6/Y	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-25 17:54:11.1	\N	2026-08-11 17:54:11.108
cmsoymbmv0009vkko6nbdu2kr	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$H+sUfM+h+dyUidI3aIc+Ag$Ny23lI1ZnSFEFuagyA8d4YVPTHzphbXOM2W3b0GPh60	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-25 17:54:12.197	\N	2026-08-11 17:54:12.199
cmsowazwo000dvk883ag5ny56	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$/qFQ5lLk/xWaU0pf+sSIXQ$ubgKkKDnODA4L6Zi2/LKa7+gJSwm4gOH5ALVg1zYIFA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-25 16:49:24.549	2026-08-11 18:04:27.464	2026-08-11 16:49:24.552
cmsovx4an0009vk88rvu4jqpw	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$XvnUrmw5PkF8yIB6aVkqVA$dqKbZEKDogxMTpWAqOYXjDWhs8cRRZEjnmP9ycA0QiE	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-25 16:38:37.047	2026-08-11 18:09:03.42	2026-08-11 16:38:37.052
cmsoz5foe000hvkkonf1vg9sb	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$13Tw/58oXnh7BRevwCGJpw$lUTyofUO/o+yoFG1nvkoQYKfrIQrzndvIO809/4A14M	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-25 18:09:03.42	\N	2026-08-11 18:09:03.436
cmsoyzilv000bvkko0oba6d2i	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$2QGDkoJf59E8KaU8+hFSUg$RlsBEkJ/J1GA9F0FFazsccAsdUITfCpy9aReD4ovENg	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-25 18:04:27.465	2026-08-11 18:20:05.715	2026-08-11 18:04:27.588
cmsgm7ko0001gvkoo3ji2tjcr	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$u/Uzx1YkXxk1Gsb9BDvHTA$jOb0Z3uJYDPZygx/YwsA0J+M/Gp0Z7kl8leI71l4uMA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 21:44:39.211	2026-08-11 18:45:45.956	2026-08-05 21:44:39.247
cmsgm7kny001evkoonv9tgivz	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$HJ01oJE3Rx0TJekE3whKPA$K84d+QcuuiWCoa7D0/dpVHwg0Ver9gA/LaXAMT70CqE	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 21:44:39.229	2026-08-11 18:45:45.956	2026-08-05 21:44:39.236
cmsgm7kny001cvkoo4gbfmcra	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$zi8Jl54o1skd/AAEmsOSmg$Zw/yhgEpIqyFeRn7w4r+iLi7ta/ZGWRf9E7ddV38ABM	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-19 21:44:39.227	2026-08-11 18:45:45.956	2026-08-05 21:44:39.234
cmsix9wvg001yvkxkocm5way4	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$26m8HKNaoGHwrtcQMKVVaA$B1tL8htvU40Sd+67uy92DPcEogpV6xSZQKm20GbiJNE	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:29:56.405	2026-08-11 18:45:45.956	2026-08-07 12:29:56.41
cmsix9wsf001wvkxkvm8gh30g	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$Hcna8TgENmSwX5HLM+/JtA$7V23ZFcyOvNUUJpWKhMwpIxXStFb5ygqBjJVxf/Aa1E	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-21 12:29:56.4	2026-08-11 18:45:45.956	2026-08-07 12:29:56.404
cmsozjmis000jvkkodezpgnth	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$a9Ku5/7LOlMQtrU1LXAcWA$Rm34AfgkCqdm25WnKooHNRxZK86T/XK8SP6tgpbcWFU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-25 18:20:05.726	2026-08-11 18:45:45.956	2026-08-11 18:20:05.77
cmspflt670007vk90lwbhzac4	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$xd1CV2bYfxHYuPBj20s14g$a82vK+X4JvRIB067AHm8f9MR47uVcPWsBJ8sWSdwYQM	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 01:49:41.733	\N	2026-08-12 01:49:41.742
cmspfmu010009vk9086nxspey	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$nNI8QXZeCIk4kcQ/rma4wQ$r23zdTM49dEpc5deULxnNZfL3ptYaNfIirXt0HZpvgo	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 01:50:29.471	\N	2026-08-12 01:50:29.473
cmsoz444h000fvkko9qgcyaue	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$h50ZDcUCP/oAAIoThqGt7g$wpgUE7RlS/hFj4U2NfddgqLMsv5jP/OClTvUefDgVEI	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-25 18:08:02.271	2026-08-12 02:05:49.037	2026-08-11 18:08:02.272
cmsql1tkt002jvkogvc88z07n	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$D0oXp4fUkUUAJdonk174nw$lgNV9nOnxlbKxbAAvxs3H7j4bBaiClF94tW5ipzeiR4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 21:09:53.015	2026-08-12 22:36:59.016	2026-08-12 21:09:53.018
cmspfoezd000bvk90sdfz6ej9	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$nO5kRjOtdw/+UQ3pllL0jQ$tW+PyDzJCSBkpiiw6J6ehUq2o+PIEj29WvRgFQmumIU	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 01:51:43.32	\N	2026-08-12 01:51:43.322
cmspfpukz000hvk90tde9y102	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$rwhRqfBe5S5jV2rRqo6/mg$m1ULelHFBeIYlw2EOD9VR2TKEdtLW3F+j+ZkjIuMNAQ	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 01:52:50.182	\N	2026-08-12 01:52:50.186
cmspg29mc0007vk5sq0k7z4z2	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$/7Tlq5JM6keKjGK81xy2OQ$/PHlg27nJsmCKj1u4laahrO4PTQWOOGHfXAmp9iD1Sw	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 02:02:29.538	\N	2026-08-12 02:02:29.546
cmspg6jwc0009vk5scj4ef8te	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$EO584jcJNgqWRAUehXN4IA$hVHsK4HQlR3FFh6xHg6etOP6JEhhNcDZoDBAAOCLzFI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-26 02:05:49.048	\N	2026-08-12 02:05:49.102
cmspg6kzp000bvk5swq3xwu8m	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$za0H8RZq0nbPbpW3rpDPAA$agHa/Tfy6rQwYg5mM5son2KhrYdVnKRk0uvGv+Yz7wI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 02:05:50.915	\N	2026-08-12 02:05:50.917
cmspj5tk40007vkrsa0deva51	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$nXUeKSpbvF2cOLVvaWW7mA$0T1QgzNBPZN9ysYQF6wKQcDtTDizrSfVrJ6nHeYUYFA	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 03:29:14.176	\N	2026-08-12 03:29:14.206
cmspj6w1l0009vkrsowlnshp8	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$hcm6/eGsXuXIEYucv+3XxQ$atfGxmI/VhlB0lIpMqPLTmtLPNBjTjv+U6e7UjZSfk0	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 03:30:04.087	\N	2026-08-12 03:30:04.089
cmspj9l48000dvkrsfysfv3dw	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$RQUqJznSy/qyI7ktICNO7Q$6Nh9WRuJPMt1ZoMz2LplE3XJ93oIFC0AdqndpLrWqtI	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 03:32:09.894	\N	2026-08-12 03:32:09.896
cmspkgn900007vkr4zu9atbnx	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$7rsNAWg4hHKWwxqXMqMiXw$Wn3sBrpa07pE/v9C4NGD9DAh5OsdfSDpWyG//RyOMx4	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 04:05:38.857	\N	2026-08-12 04:05:38.866
cmspkjzhc000jvkr4b58ryshn	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$VIy98IEKajg393HM0z3dwg$AwF6MP5aQSIai6I4xA6Mdy7lG3vTq0ttYwT62RKhOvI	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 04:08:14.685	\N	2026-08-12 04:08:14.688
cmspl61n70007vkdsa8euqgsv	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$3dzJQdnJDOKCTURvz6vgdQ$+PV0hCmQTYMq4MkYj9JXbGmdDSmCknr4DHOyrGmFgEU	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 04:25:23.913	\N	2026-08-12 04:25:23.921
cmspl6zw3000hvkdsg2wis23u	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$t4UAO6BgHTmwGEGB2LQFmw$BcGUFVVUTALB/qEJI5CwBJ7pH8JpyoQEX6UA/exyiZc	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 04:26:08.305	\N	2026-08-12 04:26:08.307
cmspq183u0007vkxkqw7i8s7n	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$H2CTiLCLpvAWGDVf+o0BUQ$gyXhd2WamD8Daaql2VFP4EjzKNLSCi+OWjY4HMtinOw	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 06:41:37.093	\N	2026-08-12 06:41:37.098
cmspq2nv4000bvkxk3lzgxbgz	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$cB/13lCVuEYbL1/cFxiokA$KBKHPDDXDudTIkrjcgpSUmNowgQI7bc49XkyO4hn4JY	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 06:42:44.175	\N	2026-08-12 06:42:44.177
cmspqpoo7000ovkbwd965mfaa	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$rosDrVF4l9jLax4h6i2OtQ$adAsBfxzwitTrARxZqzMIZvU99VdJXAy2RWcnCNwTAc	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 07:00:38.302	\N	2026-08-12 07:00:38.305
cmspqukw20007vku45r4bjxe0	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$+q0n3J0/ZMs6ZCkhx7w2MQ$Dc8vztH10z9oeg7SsBYndvU2IlwdYnvB/4gl6uUxe9A	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 07:04:26.687	\N	2026-08-12 07:04:26.69
cmsprfxu0000dvku4ghqo5uhx	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$Oudnlgmld8Im4OMG2YnP0w$WPWwzeT6T9khOreCy6j2UHTZUMrIptZto+QN0hHrZUg	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 07:21:03.228	\N	2026-08-12 07:21:03.24
cmspri5ga0007vkyo8c0jbm7z	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$3cIrQIjFCRGkZMolCWDukg$yYe53DN+mdwaOdp8rK3wbGzU3yF9Z+8MJK8Z9DkvOo8	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 07:22:46.416	\N	2026-08-12 07:22:46.422
cmsps0z4e0007vkwoug94sz6b	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$OQ69Ih4nY2sTgi57gH08XA$DOsLJ19jomlpnyFv985FX1JgiWMweJ9C/YyfsXxjaxo	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 07:37:24.668	\N	2026-08-12 07:37:24.68
cmsps90j1000bvkwofs3jytmf	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$rdYINFJzYmf4mL6/MBk/bA$1uByRISFLghvOzeCql+Z8h7TNZSahN9pwmiTe+FiL2U	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 07:43:39.755	\N	2026-08-12 07:43:39.757
cmspg7yd1000hvk5s30ptz7tt	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$cK+WimUhrpXfpdS5b91R4w$GfyjhsTXeFXPeRV/DCT+MaSWh/ofWJkYhsZ2Z7zffh0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 02:06:54.899	2026-08-12 07:59:12.265	2026-08-12 02:06:54.901
cmspst03x001fvkwon4vb8vsc	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$eK96wK10E35vpvH5+y84cg$MW6C6uiIp8geUYjabGhP5Bb9Ya9srhRhwsO7u6C+J9Q	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-26 07:59:12.266	\N	2026-08-12 07:59:12.317
cmspst4ws001jvkwox0prbwdr	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$bw5n/8Kix/UPR90Y8fpSPg$OMiat8myPC/ACBLyDxTPOJcY7O8xDpfNZdzQ8hHfgk8	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 07:59:18.418	\N	2026-08-12 07:59:18.422
cmspss1bn0011vkwonu92di4q	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$UFCVY3/xB0zt9PTSz6el7w$GUZeKyaPgee4+HA6ZHWW/Km43x911GeLdMEg6z5W1Js	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 07:58:27.238	2026-08-12 08:13:41.485	2026-08-12 07:58:27.25
cmsptvll30007vkyg47m06e1y	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$bUe79s1l1m6I6DN6yS3vDw$PwDPepimdslb3mi2OSBDD8ZdzrD8NieN34Idy/RRs94	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 08:29:13.082	\N	2026-08-12 08:29:13.094
cmsptxv68000bvkygsmn3a87n	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$wjJf8ZmS8eaPK6CWCA+d+Q$1FRPBvR4OJwbcuNx3DPHUFmkZglUj+X1z/1nJlO7M2k	node	::ffff:127.0.0.1	2026-08-26 08:30:58.819	\N	2026-08-12 08:30:58.832
cmspv6vof0007vkswepjoubb7	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$BaDjMl7YL6/UVNpRbLvrnw$fp+86neEyXhjkcfefSh/s6JBDIVXsu3gmdPWjaUfL28	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 09:05:58.985	\N	2026-08-12 09:05:59.005
cmsq2w57u0009vksw9lpig6t7	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$qk1MyUF10v18hFvrNrOpBg$UQisscDIkQY16PEmU/EesNxCnZo8xLSnAEY4H9U3zC4	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 12:41:35.04	\N	2026-08-12 12:41:35.066
cmsptbms1002hvkwotqbk5e94	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$MQTHkcBrPfUs3IGIMkv/tg$RGgTeRUgTWlmzfqlVvVDZ1pz3FDQRJwbjc3G9lZZ3p0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 08:13:41.485	2026-08-12 13:08:41.3	2026-08-12 08:13:41.498
cmsq3v08l0007vkcko1ha5xn1	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$WUEPKEtjyAEpOSe63b5miA$MyDI2ddygWvhXk8WOydm2UCS+MN65EBZF+TsTXnGqSQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 13:08:41.301	2026-08-12 13:27:18.442	2026-08-12 13:08:41.408
cmsq3wqdr000bvkcklkea5ixq	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$dynWSh2uOHyPTyOy/18J/A$mPt/nIeud7EwXlL8PqhcSXSExUvFwSrI71oaxZ+a7nk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 13:10:02.125	2026-08-12 13:28:51.849	2026-08-12 13:10:02.127
cmsq4ky34000lvkckm1y2bopr	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$3DPf7P9ZND09JDXqf0O92w$xhXGvmoOWMBlZARlV24BD+vaGovKNlc6MtXWl4jmoXc	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::1	2026-08-26 13:28:51.849	\N	2026-08-12 13:28:51.852
cmsq4lteu000nvkck7onxaz2v	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$8/ZNIDqTg77mOEK8GkEKvA$2kENqDAiFXpZLT8dyli7ehSk8cn2orNCxuMA7I0s2zw	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 13:29:32.452	\N	2026-08-12 13:29:32.454
cmsq4iy2k000hvkckmkgig7pi	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$SZknKIGQ8U93DMDjMiSy5g$VmvjhX49NiyRHkZNDJvor+QTuPWxQY9hdJwdFtbPxO4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 13:27:18.442	2026-08-12 13:47:31.517	2026-08-12 13:27:18.478
cmsqo5u0a002pvkog5occm0h6	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$gSUBwSMDhQhwngEpjYXiwQ$Fxq6RJt9pvmGFwkZrY8Z9ZMIKRrbbn3tbN2zWGy+z6w	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 22:36:59.016	2026-08-13 08:22:26.603	2026-08-12 22:36:59.036
cmsq5964t000tvkck25gyjpp9	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$lPdbg59SxKZSd53fqzOyyA$uGrdMFi0cPCJDMDGHMGlYDW7oPGReT6lg1V0Vin2e6U	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-26 13:47:42.027	\N	2026-08-12 13:47:42.029
cmsq5rxov0007vknkvw00uv26	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$/CZEZueI0Ia+JfMJb5nh6Q$gBcozT+X3Tzf61QTUZcqlFtoI/9HkbIiELDTnec+zsM	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 14:02:17.547	\N	2026-08-12 14:02:17.552
cmsq5slos000lvknkj3fabxdl	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$cX/j0CVZ5L7/TWUR8O93bQ$51H9rVUfnfROaDCZgI048wIvFcKgpu37FrTivZjs+ss	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 14:02:48.651	\N	2026-08-12 14:02:48.652
cmsq5smwd000nvknk4yhsmjn2	cmsibrdyu000evkg8o2smybwc	$argon2id$v=19$m=19456,t=2,p=1$I3XBIJNVM7AUBYwKUx1T1g$0TlQrwjKV15zCKcJOcNcG238EPcRlCoTAQ7aMBR2GvA	Mozilla/5.0 (Windows NT; Windows NT 10.0; fr-FR) WindowsPowerShell/5.1.19041.6456	::ffff:127.0.0.1	2026-08-26 14:02:50.219	\N	2026-08-12 14:02:50.222
cmsr92qq4002zvkog1avw0gcj	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$bPzUH87O9JZCmLtVoDYO9A$3e51HvfCffc0cRMBA3JonZtPQNcEA7f4C64B/SWYk9E	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-27 08:22:26.605	\N	2026-08-13 08:22:26.655
cmsq5u50j000pvknk26vy3h62	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$wW5h0ZcDxBnUGD0CzcpY7Q$66YUCMsCCGwnTX7QFgJWIZE/jnMHo3NGgeatPbu4WJ0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 14:03:59.602	\N	2026-08-12 14:03:59.717
cmsq5u58v000tvknkulx3995g	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$E7Fttww5VAWRWrtymcordA$BAK0IMQMxUdO3Gy+SzuxNa3eGujCUSjSD2KBbmQTpdA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 14:04:00.017	\N	2026-08-12 14:04:00.02
cmsq5u58t000rvknk0b2bmrjg	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$x9XYLipYB6gzbm7lVg3edg$0GI2vv6iM5spHFH7JQBmDDFnydAjqDVYqcV/3P3DRrQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 14:04:00.037	\N	2026-08-12 14:04:00.305
cmsq5u5b2000xvknk1j3mmn90	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$LuVSDruC3DgXDWF3VzxzbA$M64tx3Yh3azKlJJ+7gp/GQe41k5cmymxgEhSAirtvDI	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 14:04:00.669	\N	2026-08-12 14:04:00.671
cmsr93bmi0039vkog99yxsok5	cmsevaz4j0000vkmkl9u1habf	$argon2id$v=19$m=19456,t=2,p=1$znoyfvuIBFjzTbh1Gi98kA$/AdPWAOhnlqeujkHDQGT2TWt3m/VrR9MrlFa95w86nk	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Claude/1.26832.0 Chrome/148.0.7778.280 Electron/42.7.0 Safari/537.36 MSIX	::ffff:127.0.0.1	2026-08-27 08:22:53.839	\N	2026-08-13 08:22:53.85
cmsq5u5a4000vvknkehgh6cqc	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$tqucC00cnXpsTEFQBWh/nQ$jSC7p/HQv/s2owsLvM1n6ZhcUTLMX21Ru5KO8x/+wMA	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 14:04:00.45	\N	2026-08-12 14:04:00.452
cmsq58y29000pvkckbbyeiueh	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$GwM0WyuW8ZjvGjtvaqezbg$lkqlDRGxVI1VXsov/YOovDyVVF3f5a/VxYzq2ifyMRg	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 13:47:31.518	2026-08-12 14:04:00.767	2026-08-12 13:47:31.535
cmsq5u5ci000zvknkvuu1e2ym	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$IY/7+jioRpdW0Yt+vIXdRw$RKD3i2C9jHmG8lfEjkJAVqy4ZCLhndh7GxJkVjHK5MQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 14:04:00.768	2026-08-12 14:51:09.554	2026-08-12 14:04:00.77
cmsq8qhl0002gvknk9dcnmiw0	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$5oSXOL6g9IbhROHxkIL1PA$1oJWe+91/9iO2Z6imOd8dCeKVNJrSkrapoqi6VKxgqo	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:25:08.788	2026-08-12 17:50:15.22	2026-08-12 15:25:08.801
cmsq828vi001qvknkd7b0q8q2	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$oRCS4ZXP3tZvm182rNnqAw$T37CtI7lSe49m6QqCdKBzGhpMywweLPGGYpLBuJopy4	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:06:17.732	\N	2026-08-12 15:06:17.735
cmsq828vk001svknk9m3oxus6	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$eV3XMPWmlxlu5uPp/X9U2A$9Y5pJLneuZKb+22KzP4CbwVOmmO4IORvCMOf9yh9a7M	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:06:17.726	\N	2026-08-12 15:06:17.735
cmsq8290f001uvknkiq2lkrmg	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$+XSj/LW+Z9VRw6VPzJtv4w$i4HuF57mQn/PfsyASteaCL4uZQKJOTQDkMYypSSVN/w	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:06:17.941	\N	2026-08-12 15:06:17.959
cmsq7is2h0017vknktmlqbarg	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$S2O0FjdemGItac6cD4yfNA$/VUF0GuLw3OCkRQHJUT+CEIfzry2cIQaRiax7w6SXPM	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 14:51:09.555	2026-08-12 15:06:17.636	2026-08-12 14:51:09.565
cmsq8qh8e0028vknkxhh6889z	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$XyodVOdR6ZEjsGRxMMQWcg$DEkjwsmGJOs7V9lCMiN9lZCGEASPdoKCtltZXMEoksQ	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:25:08.053	\N	2026-08-12 15:25:08.055
cmsq8qhg0002cvknkpws0hifj	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$bgxHCTtr7/4ZBxAKZrFNPQ$QFMMz/p2wgMYtBZbCvfez3R48d70sDeDa6zL9fakygs	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:25:08.47	\N	2026-08-12 15:25:08.477
cmsq8qhfy002avknk7lehvwbp	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$+tQdY5k/6rqfaYLsvl9KCA$1aCiLLrZyDm0t8/guv5QBN7xiEldh5Kg08TmPKyBue0	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:25:08.484	\N	2026-08-12 15:25:08.488
cmsq8qhk6002evknkh6beqa8i	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$eID0CWy8ReXa8G3nVKbxwg$W5KPjZfQsmA3TGM2J1Ar2chWW/WVbPTNzK4+sTxb6UU	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:25:08.721	\N	2026-08-12 15:25:08.726
cmsq828u8001ovknk5cu9wurz	cmsezu9gz000ivks8r8x63ms4	$argon2id$v=19$m=19456,t=2,p=1$+/HYLGnVAuu9sNZqn2sYOg$gHFRRrR2LxRsvK9Fu/wuBmkw4+vW9F9uGbZW/pz/v2c	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0	::1	2026-08-26 15:06:17.637	2026-08-12 15:25:08.788	2026-08-12 15:06:17.639
\.


--
-- Data for Name: study_resources; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.study_resources (id, "userId", "documentId", type, title, content, "deckId", "createdAt") FROM stdin;
\.


--
-- Data for Name: study_sessions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.study_sessions (id, "userId", "conceptId", "lessonId", subject, status, "learningScoreBefore", "masteryBefore", "learningScoreAfter", "masteryAfter", "startedAt", "completedAt") FROM stdin;
cmsf6zopa001svk3cke0tveuz	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsf6ydru000hvk3c194futmg	Conversation Fundamentals	learning	\N	\N	\N	\N	2026-08-04 21:50:50.83	\N
cmsfantaf0051vk3cz0j08747	cmsezu9gz000ivks8r8x63ms4	cmsf3anso002cvki8fyqh7d9a	cmsfancr1002yvk3cvs6n1xqh	Conversation Fundamentals	learning	0	0	\N	\N	2026-08-04 23:33:35.367	\N
\.


--
-- Data for Name: subscriptions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.subscriptions (id, "userId", "planId", status, "currentPeriodStart", "currentPeriodEnd", "cancelAtPeriodEnd", "trialEndsAt", "createdAt", "updatedAt", "interval", provider, "providerCustomerId", "providerSubscriptionId") FROM stdin;
cmsg5q6260009vkzo01suzdl9	cmsevaz4j0000vkmkl9u1habf	cmsg5oxjh0000vkzo1hf3arpc	active	2026-08-05 15:22:23.611	2026-09-05 15:22:23.611	f	\N	2026-08-05 14:03:13.326	2026-08-07 02:00:34.675	month	fake	fake_cus_cmsevaz4	fake_sub_95998d92
cmsivbpxy000ivkxktawjtwfr	cmsibrdyu000evkg8o2smybwc	cmsg5oxqv0001vkzoxr7gnihs	active	\N	\N	f	\N	2026-08-07 11:35:21.622	2026-08-07 11:35:21.692	\N	\N	\N	\N
cmsg6u7jh000hvkzozzupui2u	cmsezu9gz000ivks8r8x63ms4	cmsg5oxqv0001vkzoxr7gnihs	active	2026-08-12 14:55:45.14	2026-09-12 14:55:45.14	f	\N	2026-08-05 14:34:21.485	2026-08-12 14:55:45.211	month	fake	fake_cus_cmsezu9g	fake_sub_04cb1c2e
\.


--
-- Data for Name: success_predictions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.success_predictions (id, "userId", "examId", preparation, "successProbability", confidence, factors, "createdAt", "updatedAt") FROM stdin;
cmspqppdt000wvkbw52geya0c	cmsevaz4j0000vkmkl9u1habf	cmspqpp62000qvkbwqbqqqzj2	97	92	82	["Preparation 97% from mastery of \\"Biologie\\".", "4 reviewed card(s) of 4 — the evidence base for this estimate.", "10 day(s) until the exam.", "Model confidence 82% (high)."]	2026-08-12 07:00:39.233	2026-08-12 08:01:51.271
cmspqppdt000vvkbw0wafyynz	cmsevaz4j0000vkmkl9u1habf	cmspqpp8t000svkbwyjiws265	\N	\N	10	["\\"Les fonctions\\" is linked but has no reviewed cards yet — preparation can't be measured.", "0 reviewed card(s) of 0 — the evidence base for this estimate.", "5 day(s) until the exam.", "Model confidence 10% (low)."]	2026-08-12 07:00:39.233	2026-08-12 08:01:51.271
\.


--
-- Data for Name: tutor_messages; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.tutor_messages (id, "sessionId", role, content, citations, "createdAt", "viaVoice") FROM stdin;
cmsf1w6lq0009vki800lpp4lv	cmsf1w4uc0007vki8ouvrw0p7	assistant	Benvenuto! Immagina di essere seduto a un tavolino in un bar storico nel centro di Roma, mentre l'aroma del caffè tostato riempie l'aria. \n\n*Buonasera!* Cosa ti porto per cominciare?	\N	2026-08-04 19:28:09.326	f
cmsf264lz000pvki8ozpgxq2f	cmsf262j1000nvki8lel6j4m2	assistant	Buongiorno! Immagina di essere seduto a un tavolino fuori in un bar soleggiato a Roma. *Imagine you are sitting at an outdoor table at a sunny cafe in Rome.* \n\nDimmi, cosa desideri ordinare oggi? *Tell me, what would you like to order today?*	\N	2026-08-04 19:35:53.296	f
cmsf275xs000tvki869j1ayiu	cmsf262j1000nvki8lel6j4m2	user	Sorry, I don't understand. What does 'desideri ordinare' mean? I'm a bit lost.	\N	2026-08-04 19:36:41.668	f
cmsf275xs000vvki8vvkaogvz	cmsf262j1000nvki8lel6j4m2	assistant	Nessun problema, capita a tutti! *Desiderare* significa "to want" o "to wish for", e *ordinare* significa "to order" (al ristorante o al bar). Quindi, "cosa desideri ordinare?" vuol dire semplicemente: *what would you like to order?*\n\nOra torniamo a noi, nel nostro bar a Roma. \n\nUn caffè espresso, un cappuccino, o magari una spremuta d'arancia fresca? Cosa prendi?	\N	2026-08-04 19:36:41.668	f
cmsf39lwe001dvki8xnssbcsl	cmsf39du7001bvki8h0ajtogq	assistant	Hello LEO! It's wonderful to see you today for our lesson. \n\nWhat would you like to dive into and work on together?	\N	2026-08-04 20:06:35.294	f
cmsf3adsk001fvki8jx6x8uo1	cmsf39du7001bvki8h0ajtogq	user	Je vais prendre l'anglais.	\N	2026-08-04 20:07:11.435	t
cmsf3adsl001hvki8159prkti	cmsf39du7001bvki8h0ajtogq	assistant	C'est une excellente décision ! Let's do that! (C'est parti !) \n\nSince we are starting our English journey together, I'd love to know: is there a specific situation where you need English (like for traveling, work, or just for fun), or would you prefer we start with the basics of everyday conversation? \n\nTell me a little bit about your goal, or just try to say hello to me in English! What do you think?	\N	2026-08-04 20:07:11.435	t
cmsf54dj40005vky8h0glzxsx	cmsf547470003vky8km6rvvx2	user	Can you teach me how recursion works in Python?	\N	2026-08-04 20:58:30.396	f
cmsf54dj40007vky813im7b19	cmsf547470003vky8km6rvvx2	assistant	Hello! Welcome to our lesson. I'm really glad you're here to dive into this. \n\nRecursion can feel a bit mind-bending at first, but once it clicks, it's one of the most elegant tools in programming. Today, our goal is to understand what recursion is, how it works under the hood in Python, and how to write your very first recursive function.\n\nTo put it simply, recursion is just a function that **calls itself** to solve a smaller piece of the exact same problem. \n\nThink of it like standing between two parallel mirrors: you see an infinite reflection of yourself, where each reflection is a smaller version of the one before it. But, of course, there has to be a stopping point, otherwise those reflections would go on forever!\n\nLet's look at the classic Computer Science analogy for this: **counting down**. \n\nImagine you want to write a function called `countdown(n)` that prints numbers from `n` down to 1. \n\nIf we were to think about this recursively, how would you describe the very first step of counting down from, say, 3? What do you do *before* you call the function again for the next number?	\N	2026-08-04 20:58:30.396	f
cmsf54gfs000bvky80lh2lvlu	cmsf54dl80009vky8qernvt1b	user	I want to learn to solve quadratic equations.	\N	2026-08-04 20:58:34.164	f
cmsf54gft000dvky8uirs6rbs	cmsf54dl80009vky8qernvt1b	assistant	Hello there! I am so glad you're here. Learning to solve quadratic equations is a fantastic milestone in mathematics — it opens the door to understanding how things curve, how objects fly through the air, and so much more. \n\nTake a deep breath and leave any past worries about math at the door. We are going to take this completely step by step, at your own pace, and work through it together.\n\nTo start us off, let's look at what a quadratic equation actually *is*. \n\nUnlike a simple linear equation like $2x + 3 = 7$ (where $x$ just has an exponent of 1), a **quadratic equation** always has a squared term. The standard way we write it looks like this:\n\n$$ax^2 + bx + c = 0$$\n\n(Where $a$, $b$, and $c$ are just numbers, and $a$ cannot be zero).\n\nFor example, an equation you might see looks like this:\n$$x^2 - 5x + 6 = 0$$\n\nBefore we dive into *solving* one, I want to check just one small thing to make sure we're on the same page. Looking at that example ($x^2 - 5x + 6 = 0$), can you tell me what number is playing the role of **$a$** (the number in front of $x^2$), **$b$** (the number in front of $x$), and **$c$** (the plain number at the end)? \n\nGive it your best shot, and we'll take our next tiny step from there!	\N	2026-08-04 20:58:34.164	f
cmsf54jj4000hvky8eme9x80r	cmsf54gi0000fvky88sjttf7p	user	Explain Descartes' cogito and what it means.	\N	2026-08-04 20:58:38.173	f
cmsf54jj5000jvky8tynikktb	cmsf54gi0000fvky88sjttf7p	assistant	Hello! Welcome to our philosophy lesson today. I'm so glad you're here. \n\nToday, we are going to dive into one of the most famous ideas in the entire history of philosophy: René Descartes' **"Cogito, ergo sum"**—usually translated as *"I think, therefore I am."* \n\nTo understand what it means, we have to put ourselves in Descartes' shoes. Imagine you want to be completely certain about everything you know. Descartes looked around and realized that our senses can trick us (like optical illusions, or even vivid dreams where you feel like you're awake, but you're actually asleep). He decided to doubt *everything* he possibly could—his eyes, his hands, even whether the physical world exists at all—just to see if any rock-solid certainty remained.\n\nHe imagined an all-powerful "evil demon" whose sole purpose was to trick him about everything. But as Descartes sat there doubting everything, he realized something profound: *In order to be deceived, or to doubt in the first place, he had to exist.* \n\nThink of it like this: If I am doubting, I am thinking. If I am thinking, something must be doing the thinking. \n\nTo help us take our very first step into this, let me ask you a quick question: \n\nIf you try to doubt your own existence right now, what is the one thing you have to be doing in order to carry out that doubt?	\N	2026-08-04 20:58:38.173	f
cmsf5d7ze0005vk3cq24cr5cb	cmsf5cwan0003vk3cvnkb4vmr	user	Teach me how recursion works in Python.	\N	2026-08-04 21:05:22.93	f
cmsq86x4e001yvknko7e672s3	cmsgwzfn60028vkoosxhptu82	user	J’ai compris — peux-tu aller un peu plus vite ?	\N	2026-08-12 15:09:55.834	f
cmsf5d7zf0007vk3ct1vhyklc	cmsf5cwan0003vk3cvnkb4vmr	assistant	Hello! Welcome to our lesson. I'm so glad you're here today. \n\nToday, we are going to master one of the most powerful and elegant concepts in computer science: **recursion**. \n\nTo make this practical and fun, we are going to learn it through a mini-project: **building our own digital file-system search tool (like a mini `find` command in your terminal)**. When you want to search through a folder that contains other folders, which contain *even more* folders, recursion is the exact tool a programmer uses to look inside every single one of them.\n\nLet's start right at the beginning. \n\n### What is Recursion?\n\nIn computer science, **recursion simply means a function calling itself.** \n\nThink of it like standing between two parallel mirrors. You see an reflection of yourself, inside that reflection is another reflection, and so on, getting smaller and smaller. \n\nTo see how this works in code, let's look at the classic non-computer science example: counting down. \n\nImagine you want to write a Python function that counts down from a number to zero. Normally, you might use a `while` loop or a `for` loop. But with recursion, we do it by making the function solve a smaller version of the exact same problem.\n\nHere is what a recursive countdown function looks like in Python:\n\n```python\ndef countdown(n):\n    # 1. The Base Case (stopping condition)\n    if n < 0:\n        return\n    \n    # 2. Print the current number\n    print(n)\n    \n    # 3. The Recursive Step (calling itself with a smaller problem)\n    countdown(n - 1)\n\ncountdown(3)\n```\n\nIf you ran this code, it would print `3`, then `2`, then `1`, then `0`, and then stop.\n\nNotice two vital parts of any recursive function here:\n1. **The Base Case:** If we didn't have `if n < 0: return`, the function would call itself forever, crashing your computer with a `RecursionError` (infinite loop of functions). The base case is our "escape hatch."\n2. **The Recursive Step:** Every time we call `countdown`, we pass `n - 1`. We are making the problem *smaller* so that it eventually hits the base case.\n\n---\n\n### Your Turn to Check Understanding\n\nTo make sure we're on the right track before we build our folder-searcher, I want to ask you a quick question:\n\nLook at the code above. What would happen if we forgot to include the base case (`if n < 0: return`) and called `countdown(3)`? Why do you think that happens in terms of how computers manage memory?\n\nTake your time, give it your best guess, and let me know what you think!	\N	2026-08-04 21:05:22.93	f
cmsfpepoh0007vk941zjgbois	cmsfpeju50005vk94j6030fa0	user	What is photosynthesis?	\N	2026-08-05 06:26:25.02	f
cmsfpepoh0009vk94xtv1z5lh	cmsfpeju50005vk94j6030fa0	assistant	Bonjour ! C'est un réel plaisir de commencer cette leçon avec vous. Aujourd'hui, nous allons découvrir l'un des processus les plus fascinants du vivant : **la photosynthèse**. \n\nPour faire tout à fait simple au début, imaginez que les plantes vertes possèdent une petite cuisine interne. Contrairement à nous, elles ne vont pas au marché pour se nourrir ; elles fabriquent leur propre nourriture directement à partir d'éléments simples qu'elles trouvent dans leur environnement.\n\nPour fabriquer cette nourriture (du sucre, qui leur donne de l'énergie), la plante a besoin de trois ingrédients principaux :\n1. De l'eau (pompée par les racines).\n2. Du gaz carbonique (absorbé par les feuilles dans l'air).\n3. De la lumière du soleil (capturée par une substance verte dans les feuilles, appelée la chlorophylle).\n\nEn combinant ces trois éléments, la plante fabrique son sucre et rejette un gaz dont nous avons besoin pour respirer. \n\nD'après vous, quel est ce gaz précieux que les plantes rejellent ainsi dans l'air ?	\N	2026-08-05 06:26:25.02	f
cmsfpg1i2000jvk94kwsbj8yf	cmsfpfyr1000hvk949ok51x0t	user	Qu'est-ce que la gravité ?	\N	2026-08-05 06:27:26.979	f
cmsfpg1i2000lvk949kf5rym1	cmsfpfyr1000hvk949ok51x0t	assistant	Hello! Welcome to our lesson today. It's wonderful to have you here. \n\nOur goal today is to understand what gravity really is, how it works in our everyday lives, and how we can describe it using physics. \n\nTo start us off simply: imagine you are holding an apple in your hand, and you let it go. What happens to the apple, and why do you think that happens? Give it your best thought!	\N	2026-08-05 06:27:26.979	f
cmsftsllk001ovk94v5psjmrj	cmsfts79v001mvk945ckpmpnr	user	Conjugaison	\N	2026-08-05 08:29:11.345	f
cmsftsllk001qvk94hp687lvw	cmsfts79v001mvk945ckpmpnr	assistant	Welcome to your French lesson! It is wonderful to see you here today. \n\nOur objective for this session is to step into the world of French verb conjugation—specifically, learning how to take regular verbs and make them match who is doing the action. Since we were just looking at notes about communication and conversations [1, 2, 3, 4, 5], knowing how to talk about *who* is speaking is going to be our very first step!\n\nLet's start with the absolute foundation: **subject pronouns** (the words for "I", "you", "he", etc.) in French. Here they are:\n\n*   **Je** = I\n*   **Tu** = You (singular, informal)\n*   **Il / Elle / On** = He / She / One (or "we" in casual speech)\n*   **Nous** = We\n*   **Vous** = You (plural, or formal singular)\n*   **Ils / Elles** = They (masculine/mixed / feminine)\n\nNow, in French, regular verbs change their endings depending on which of these pronouns is doing the action. Let's look at a very common verb: **parler**, which means *to speak* or *to talk* (fitting for our conversation theme!). \n\nFor regular verbs ending in **-er**, the "I" form (**je**) drops the *-er* and takes an **-e**. So, *I speak* becomes:\n**Je parle.**\n\nUsing that pattern, if *parler* means "to speak", how do you think you would say **"You speak"** (using the singular, informal **tu**, where the ending usually adds **-es**)? \n\nTake your time, give it a try, and let me know what you think the French phrase for "You speak" is!	[{"score": 0.5571141, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.5539901, "chunkIndex": 0, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5539901, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.54077613, "chunkIndex": 4, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.53922826, "chunkIndex": 4, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}]	2026-08-05 08:29:11.345	f
cmsg7ceqv000nvkzo3ezhdbtz	cmsfts79v001mvk945ckpmpnr	user	Je veux le cours en français surtout	\N	2026-08-05 14:48:30.586	f
cmsg7ceqw000pvkzomz9rnrmw	cmsfts79v001mvk945ckpmpnr	assistant	Ah, c'est une excellente idée ! You want the course in French, and that is a fantastic way to immerse yourself. I love that enthusiasm. \n\nLet's switch to French for our conversation, while still keeping our explanations clear so you can follow easily. \n\nEarlier, we looked at **je parle** (I speak). Following the pattern we discussed where *tu* adds an *-es* ending, how would you say **"You speak"** in French? \n\nDonnez votre meilleure tentative! (Give it your best try!)	[{"score": 0.5952166, "chunkIndex": 0, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5952166, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.591085, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.5539111, "chunkIndex": 3, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.55249405, "chunkIndex": 3, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}]	2026-08-05 14:48:30.586	f
cmsgx1a1l002avkoowiel776s	cmsgwzfn60028vkoosxhptu82	user	Je veux apprendre l'anglais vu que je connais rien prof	\N	2026-08-06 02:47:41.333	f
cmsgx1a1l002cvkooqlaby48a	cmsgwzfn60028vkoosxhptu82	assistant	Welcome to our lesson! I am so glad you are here. Don't worry at all that you are starting from the very beginning—we will take it one gentle step at a time, and I will be right here to help you.\n\nBased on your notes, we are going to start with the very first pillar of conversation: **Initiation** (starting a conversation) [4]. \n\nImagine you are standing at a bus stop next to a stranger, and it is raining heavily [1], [3]. Instead of staying completely silent, we want to say something friendly and easy to "break the ice" [3], [4]. \n\nIn English, a great way to start is by making a simple observation about the weather or the situation around you. \n\nCan you try to write a very simple English sentence to comment on the rain to the person next to you at the bus stop? (Even just a few words is wonderful—just try your best!)	[{"score": 0.58713204, "chunkIndex": 0, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.58713204, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5811312, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.54115605, "chunkIndex": 4, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.54106325, "chunkIndex": 1, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}]	2026-08-06 02:47:41.333	f
cmsgx38zb002evkoolknlqolh	cmsgwzfn60028vkoosxhptu82	user	Que le cours se donne en français pour les explications et exemples	\N	2026-08-06 02:49:13.251	f
cmsgx38zb002gvkoo2lrxtm5w	cmsgwzfn60028vkoosxhptu82	assistant	Ah, I completely understand! Thank you for letting me know. From now on, I will use French to explain things and give you examples so that you feel totally comfortable and relaxed, while we learn English step by step. \n\nComme nous l'avons vu dans vos notes sur la *Conversation Fundamentals*, la première étape est l'*Initiation* (commencer la conversation) en faisant une simple remarque sur la situation [1], [3]. \n\nImaginez que vous êtes à l'arrêt de bus et qu'il pleut beaucoup [1], [3]. Pour lancer la discussion avec quelqu'un, on peut faire une observation simple sur le temps. \n\nPourriez-vous essayer d'écrire une toute petite phrase en anglais pour dire, par exemple, qu'il pleut beaucoup ? (Essayez avec vos propres mots, il n'y a pas de mauvaise réponse pour commencer !)	[{"score": 0.6006587, "chunkIndex": 0, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.6006587, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5984113, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.5733765, "chunkIndex": 3, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.5707735, "chunkIndex": 3, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}]	2026-08-06 02:49:13.251	f
cmsiasj1m000fvk5gyttmklux	cmsiasdyt000bvk5g8xxbuit5	user	Explique la gravite en une phrase.	\N	2026-08-07 02:00:33.895	f
cmsiasj1m000hvk5gxtd9u1u7	cmsiasdyt000bvk5g8xxbuit5	assistant	Bonjour ! Je suis ravi de t'accompagner aujourd'hui pour explorer les mystères de la physique. \n\nPour répondre à ta question en une seule phrase : **La gravité est une force d'attraction invisible qui pousse tous les objets dotés de masse à s'attirer les uns vers les autres.**\n\nPar exemple, c'est exactement cette force invisible qui retient tes pieds bien ancrés sur le sol et qui fait retomber une pomme de son arbre.\n\nDis-moi, selon toi, si tu lâche en même temps une feuille de papier à plat et une boule de pétanque d'une même hauteur, est-ce que la gravité attire la boule plus fort que la feuille ?	\N	2026-08-07 02:00:33.895	f
cmsibiy0m0013vk5gum0ahyc7	cmsibib9c000zvk5gryjq89vw	user	Du début	\N	2026-08-07 02:21:06.347	f
cmsibiy0m0015vk5gh5p6jkm4	cmsibib9c000zvk5gryjq89vw	assistant	Bonjour ! Je suis ravi de vous retrouver pour notre leçon d'aujourd'hui en physique. Prenez le temps de vous installer confortablement.\n\nMême si vos notes parlent de communication [1], nous sommes ici dans un cours de **physique**. Nous allons donc aborder notre discipline avec toute la rigueur et la méthode nécessaires, en nous concentrant sur la résolution de problèmes pas à pas. C'est en faisant qu'on apprend le mieux !\n\nPour commencer notre session, imaginez un problème classique de mécanique : un objet en mouvement, comme une voiture ou un skieur. \n\nAvant de faire le moindre calcul, quelle est, selon vous, la toute première étape fondamentale lorsqu'on aborde un problème de physique pour ne pas se tromper de formule ? \n\nÀ vous de jouer, dites-moi ce qui vous vient à l'esprit !	[{"score": 0.60238016, "chunkIndex": 0, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.60238016, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5954737, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.57954377, "chunkIndex": 4, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.57275796, "chunkIndex": 2, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}]	2026-08-07 02:21:06.347	f
cmsibki6i001bvk5gwech6cbh	cmsibjun50017vk5g8shbc966	user	Informatique de gestion	\N	2026-08-07 02:22:19.11	f
cmsibki6i001dvk5grn7sk7pf	cmsibjun50017vk5g8shbc966	assistant	Bonjour et bienvenue ! Je suis ravi de vous accompagner. Aujourd'hui, nous allons aborder notre sujet à travers une approche par projet très concrète, en y insufflant toute la rigueur et la structure de l'informatique.\n\nNotre objectif est de concevoir un projet appliqué : nous allons modéliser et développer un **système conversationnel intelligent** — un prototype de chatbot ou d'assistant virtuel structuré — en nous appuyant sur les fondements d'une bonne communication que l'on retrouve dans vos notes [4]. En informatique, pour qu'un système puisse échanger avec un utilisateur de manière fluide, nous devons d'abord comprendre comment structurer logiquement une conversation.\n\nSelon vos notes, une conversation repose sur quatre piliers fondamentaux [4] :\n1. **L'initiation** (le déclenchement de l'échange) ;\n2. **L'écoute active** (la réception et le traitement des données) ;\n3. **Le rythme / Pacing** (l'équilibrage des flux d'informations) ;\n4. **La conclusion** (la fermeture propre de la session).\n\nPour notre première étape de projet, intéressons-nous au tout début : **l'initiation**. \n\nPourriez-vous me dire, selon vous et d'après vos notes, quelle technique principale utilise-t-on pour initier ou "briser la glace" efficacement lors d'une interaction [4] ?	[{"score": 0.54060096, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.5354247, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5354247, "chunkIndex": 0, "documentId": "cmsf6ye63000jvk3cz7d814bi", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5305733, "chunkIndex": 4, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5154368, "chunkIndex": 4, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}]	2026-08-07 02:22:19.11	f
cmsq86x4e0020vknkb4dbhkw1	cmsgwzfn60028vkoosxhptu82	assistant	C'est compris, allons plus vite ! \n\nPuisque nous avons vu le premier pilier, l'**Initiation** (briser la glace avec une remarque contextuelle) [3], passons directement au troisième pilier de vos notes : le **Pacing** (le rythme de la conversation) [5]. \n\nPour garder une conversation vivante, vos notes indiquent qu'il faut utiliser des questions ouvertes qui commencent par **What** (Quoi/Quel), **How** (Comment) ou **Why** (Pourquoi) [1], [5].\n\nSi quelqu'un vous dit : *"I love your jacket!"* (J'adore ta veste !), comment pourriez-vous lui poser une question ouverte en anglais (en utilisant *What*, *How* ou *Why*) pour en savoir plus et continuer la discussion ?	[{"score": 0.6014289, "chunkIndex": 3, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.574149, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.56969345, "chunkIndex": 3, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.56613195, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.56339943, "chunkIndex": 4, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}]	2026-08-12 15:09:55.834	f
cmsq8f9dp0024vknkjsqg234i	cmsgwzfn60028vkoosxhptu82	user	What	\N	2026-08-12 15:16:25.018	f
cmsq8f9dp0026vknkjh28r9fj	cmsgwzfn60028vkoosxhptu82	assistant	C'est un excellent début ! Le mot **"What"** est parfait pour commencer une question ouverte, exactement comme le soulignent vos notes [3], [5].\n\nPour aller un tout petit peu plus loin et former une question complète (par exemple, pour demander où la personne a acheté sa veste, ou ce qu'elle aime dedans), on peut ajouter un mot après "What". \n\nEn vous basant sur vos notes [3], [5], comment utiliseriez-vous **"What"** pour poser une question complète à quelqu'un qui vient de vous dire *"I love your jacket!"* ? (Par exemple : *"What..."*)	[{"score": 0.61920035, "chunkIndex": 0, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.6144126, "chunkIndex": 0, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.59708786, "chunkIndex": 3, "documentId": "cmsf3ajph001lvki88j6p72vk", "documentTitle": "Lesson — Conversation"}, {"score": 0.59658885, "chunkIndex": 3, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}, {"score": 0.5963745, "chunkIndex": 4, "documentId": "cmsfane250030vk3ckp0grfpq", "documentTitle": "Lesson — Conversation Fundamentals"}]	2026-08-12 15:16:25.018	f
cmsqgc42j000fvkog0hjkvobi	cmsqgc1rc000bvkogrhzpjju3	user	Explique-moi les fractions	\N	2026-08-12 18:57:55.079	f
cmsqgc42k000hvkogg1k2x897	cmsqgc1rc000bvkogrhzpjju3	assistant	[echo] I received your request (365 chars). A full model would answer here.	[{"score": 0.6291615, "chunkIndex": 0, "documentId": "cmsq2w7a5000dvkswdndm9jrd", "documentTitle": "Doc pagination 2"}, {"score": 0.62809485, "chunkIndex": 0, "documentId": "cmsq2w7uv000hvkswmabo5p9j", "documentTitle": "Doc pagination 4"}, {"score": 0.62603116, "chunkIndex": 0, "documentId": "cmsq2w6lt000bvksw2opmvb9a", "documentTitle": "Doc pagination 1"}, {"score": 0.6248365, "chunkIndex": 0, "documentId": "cmsq2w7hj000fvkswpw0zk6m4", "documentTitle": "Doc pagination 3"}]	2026-08-12 18:57:55.079	f
\.


--
-- Data for Name: tutor_sessions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.tutor_sessions (id, "userId", title, "createdAt", "updatedAt", "focusConceptId", "languageProfileId", subject, strategy, "strategyReason") FROM stdin;
cmsf1w4uc0007vki8ouvrw0p7	cmsevaz4j0000vkmkl9u1habf	Italian — au cafe	2026-08-04 19:28:07.045	2026-08-04 19:28:07.045	\N	cmsf1w4mz0005vki8r0ksmd9x	\N	\N	\N
cmsf262j1000nvki8lel6j4m2	cmsevaz4j0000vkmkl9u1habf	Italian — at a cafe	2026-08-04 19:35:50.605	2026-08-04 19:36:41.668	\N	cmsf1w4mz0005vki8r0ksmd9x	Italian	\N	\N
cmsf39du7001bvki8h0ajtogq	cmsezu9gz000ivks8r8x63ms4	Conversation	2026-08-04 20:06:24.847	2026-08-04 20:07:11.435	\N	\N	English	\N	\N
cmsf547470003vky8km6rvvx2	cmsevaz4j0000vkmkl9u1habf	Prog	2026-08-04 20:58:22.087	2026-08-04 20:58:30.396	\N	\N	Computer Science	socratic	The teacher leads with guiding questions so you reason your way to understanding.
cmsf54dl80009vky8qernvt1b	cmsevaz4j0000vkmkl9u1habf	Math	2026-08-04 20:58:30.476	2026-08-04 20:58:34.164	\N	\N	Mathematics	problem_solving	This is a problem-driven subject, so the teacher works through problems with you step by step.
cmsf54gi0000fvky88sjttf7p	cmsevaz4j0000vkmkl9u1habf	Philo	2026-08-04 20:58:34.247	2026-08-04 20:58:38.173	\N	\N	Philosophy	socratic	This is a discussion-driven subject, so the teacher leads with guiding questions.
cmsf5cwan0003vk3cvnkb4vmr	cmsevaz4j0000vkmkl9u1habf	Prog2	2026-08-04 21:05:07.962	2026-08-04 21:05:22.93	\N	\N	Computer Science	project_based	Programming sticks when you build something, so the session is organised around a small project.
cmsfpeju50005vk94j6030fa0	cmsevaz4j0000vkmkl9u1habf	Locale test	2026-08-05 06:26:17.453	2026-08-05 06:26:25.02	\N	\N	Biology	socratic	The teacher leads with guiding questions so you reason your way to understanding.
cmsfpfyr1000hvk949ok51x0t	cmsevaz4j0000vkmkl9u1habf	EN test	2026-08-05 06:27:23.437	2026-08-05 06:27:26.979	\N	\N	Physics	problem_solving	This is a problem-driven subject, so the teacher works through problems with you step by step.
cmsfts79v001mvk945ckpmpnr	cmsezu9gz000ivks8r8x63ms4	Français	2026-08-05 08:28:52.816	2026-08-05 08:29:11.345	\N	\N	French	socratic	The teacher leads with guiding questions so you reason your way to understanding.
cmsgwzfn60028vkoosxhptu82	cmsezu9gz000ivks8r8x63ms4	Apprendre l'anglais.	2026-08-06 02:46:15.277	2026-08-06 02:47:41.333	\N	\N	English	socratic	The teacher leads with guiding questions so you reason your way to understanding.
cmsiasdyt000bvk5g8xxbuit5	cmsevaz4j0000vkmkl9u1habf	Usage test	2026-08-07 02:00:27.317	2026-08-07 02:00:33.895	\N	\N	Physics	problem_solving	This is a problem-driven subject, so the teacher works through problems with you step by step.
cmsibib9c000zvk5gryjq89vw	cmsezu9gz000ivks8r8x63ms4	PHYSIQUE	2026-08-07 02:20:36.782	2026-08-07 02:21:06.347	\N	\N	Physics	problem_solving	This is a problem-driven subject, so the teacher works through problems with you step by step.
cmsibjun50017vk5g8shbc966	cmsezu9gz000ivks8r8x63ms4	INFORMATIQUE	2026-08-07 02:21:48.595	2026-08-07 02:22:19.11	\N	\N	Computer Science	project_based	Programming sticks when you build something, so the session is organised around a small project.
cmsqgc1rc000bvkogrhzpjju3	cmsevaz4j0000vkmkl9u1habf	Explique-moi les fractions	2026-08-12 18:57:52.103	2026-08-12 18:57:55.079	\N	\N	[echo] I received your request (26 chars	socratic	The teacher leads with guiding questions so you reason your way to understanding.
\.


--
-- Data for Name: usage_counters; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.usage_counters (id, "userId", metric, period, used, "updatedAt") FROM stdin;
cmsiasj4g000jvk5gkcyiis2x	cmsevaz4j0000vkmkl9u1habf	voice_minutes	2026-08	5	2026-08-07 02:00:34
cmsibiquv0011vk5grdl13uno	cmsezu9gz000ivks8r8x63ms4	ai_questions	2026-08	4	2026-08-12 15:16:21.454
cmsiase8d000dvk5ggu4e9zkr	cmsevaz4j0000vkmkl9u1habf	ai_questions	2026-08	2	2026-08-12 18:57:52.335
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.users (id, email, "passwordHash", "emailVerified", "createdAt", "updatedAt", "twoFactorEnabled", "twoFactorSecret", "isAdmin", "suspendedAt", "lastActiveAt") FROM stdin;
cmsibrdj40008vkg88ef4wjk3	prof@test.local	$argon2id$v=19$m=19456,t=2,p=1$0Nj/TbSecfLqF6AEtkE34Q$8cdM0xiGoLoNUf7kGlj0tBAQWe5h/1cZDNZRnARWlVE	f	2026-08-07 02:27:39.712	2026-08-07 02:27:39.712	f	\N	f	\N	\N
cmsezu9gz000ivks8r8x63ms4	leomiko0001@gmail.com	$argon2id$v=19$m=19456,t=2,p=1$NPaeASlo8ffbxHx7q1cPnQ$8l6MOqBB9Eb9Gij5zhkN8gcOa7fhsvOePsfOb+xyW6M	f	2026-08-04 18:30:40.32	2026-08-13 08:22:27.169	f	\N	f	\N	2026-08-13 08:22:27.153
cmsibrdyu000evkg8o2smybwc	eleve@test.local	$argon2id$v=19$m=19456,t=2,p=1$q2/2q+tYdQRVoBvtIYpneg$6jrxVaH1/pf+B9A3rYxzEPUpwSrklZhW3h9bcQL0FG0	f	2026-08-07 02:27:40.278	2026-08-11 17:54:12.288	f	\N	f	\N	2026-08-11 17:54:12.283
cmsevaz4j0000vkmkl9u1habf	pred@test.local	$argon2id$v=19$m=19456,t=2,p=1$4t3oo9Z9iTcnUylYApBToA$WAppu7wj2SUB8zc4a/l9acyBcoUQcCC//Ew1U4ObMLE	f	2026-08-04 16:23:42.158	2026-08-13 08:23:25.106	f	\N	f	\N	2026-08-13 08:23:25.092
\.


--
-- Data for Name: webhook_events; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.webhook_events (id, provider, "eventId", type, "processedAt") FROM stdin;
cmsg7u8tb0008vkooakoy94tp	fake	fake_e9aaae90-6f16-4811-b2ae-d3c38609cbed	subscription_activated	2026-08-05 15:02:22.752
cmsg7v97g000fvkoou02nrsyc	fake	evt_renew_TEST1	subscription_renewed	2026-08-05 15:03:09.916
cmsg8jzep000zvkooi8lno0i6	fake	fake_7f4a0fdc-dd98-48c0-a47f-a06b4a638e94	subscription_activated	2026-08-05 15:22:23.617
cmsq7oooq001ivknkv42tcbvu	fake	fake_983edbb5-9d8b-4d42-bb88-e25755cac349	subscription_activated	2026-08-12 14:55:45.146
\.


--
-- Data for Name: writing_submissions; Type: TABLE DATA; Schema: public; Owner: secondbrain
--

COPY public.writing_submissions (id, "userId", type, title, text, score, review, "createdAt") FROM stdin;
cmsf0my3b0003vkwc07dv4ua4	cmsevaz4j0000vkmkl9u1habf	redaction	La technologie	La technologie change nos vie. Beaucoup de gens pense que les reseaux sociaux est mauvais mais moi je pense que sa depend. Premierement il y a des avantage comme parler avec des amis. Deuxiemement il y a des inconvenient. En conclusion la technologie c'est bien et mal.	25	{"score": 25, "summary": "Le texte est extrêmement court, rudimentaire et ne répond pas aux exigences d'une dissertation académique. Le vocabulaire est familier, la syntaxe est pauvre et les arguments sont à peine ébauchés sans aucune justification ni illustration.", "strengths": ["Le texte suit une structure narrative basique avec une introduction, deux points de vue et une conclusion.", "L'intention de nuancer le sujet (« ça dépend ») est une bonne base de réflexion."], "dimensions": [{"kind": "structure", "rating": "needs_work", "observation": "Le texte ne comporte qu'un seul bloc de texte sans paragraphes distincts pour l'introduction, le développement et la conclusion.", "howToImprove": "Séparez clairement votre texte en trois paragraphes distincts : un paragraphe d'introduction (présentation du sujet et de la problématique), un paragraphe de développement (les arguments pour et contre) et un paragraphe de conclusion."}, {"kind": "logic", "rating": "needs_work", "observation": "Le passage des avantages aux inconvénients est abrupte et manque de transitions logiques sophistiquées.", "howToImprove": "Utilisez des connecteurs logiques plus variés et soutenus, tels que « d'une part », « en revanche », ou « par conséquent », pour lier vos idées de manière fluide."}, {"kind": "clarity", "rating": "needs_work", "observation": "Le propos est trop vague (« parler avec des amis », « c'est bien et mal »), ce qui nuit à la compréhension précise de la pensée.", "howToImprove": "Développez vos idées en expliquant *pourquoi* c'est un avantage (ex: « maintenir le lien social à distance ») ou un inconvénient."}, {"kind": "spelling", "rating": "needs_work", "observation": "Absence quasi-totale d'accents sur les mots clés (« vie » au lieu de « vies », « pense » au lieu de « pensent », « reseaux », « avantage », « inconvenient »).", "howToImprove": "Relisez-vous attentivement pour vérifier les accords pluriels (ex: « nos vies », « les réseaux sociaux ») et l'orthographe des accents (réseaux, avantages, inconvénients)."}, {"kind": "grammar", "rating": "needs_work", "observation": "Erreurs de grammaire et d'accord fondamentales : « Beaucoup de gens pense » (pluriel manquant), « les reseaux sociaux est » (accord au singulier au lieu du pluriel « sont »), « sa depend » (confusion entre le pronom « ça » et le possessif « sa »).", "howToImprove": "Vérifiez les accords sujets-verbes (les réseaux sociaux *sont*) et apprenez à distinguer « ça » (verbe ou pronom démonstratif) de « sa » (adjectif possessif)."}, {"kind": "argumentation", "rating": "needs_work", "observation": "Les arguments sont inexistants : dire qu'il y a des avantages et des inconvénients sans donner d'exemples concrets ne constitue pas une argumentation.", "howToImprove": "Pour chaque argument avancé, ajoutez une explication approfondie et un exemple concret (par exemple, citez la cyberdépendance ou la désinformation pour les inconvénients)."}, {"kind": "academic_quality", "rating": "needs_work", "observation": "Le registre de langue est familier (« moi je pense que ça dépend », « c'est bien et mal »), ce qui ne correspond pas aux standards académiques.", "howToImprove": "Bannissez la première personne du singulier (« je pense ») au profit d'un ton neutre ou de la première personne du pluriel (« nous pouvons observer »), et utilisez un vocabulaire plus formel."}], "priorities": ["Corriger les fautes de grammaire de base (accords sujets-verbes et pluriels).", "Élever le registre de langue en évitant les tournures familières et le pronom 'je'.", "Développer l'argumentation en étayant les avantages et les inconvénients avec des exemples précis.", "Structurer le devoir en paragraphes distincts avec des connecteurs logiques adaptés."]}	2026-08-04 18:52:58.775
\.


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: achievements achievements_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT achievements_pkey PRIMARY KEY (id);


--
-- Name: ai_initiatives ai_initiatives_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.ai_initiatives
    ADD CONSTRAINT ai_initiatives_pkey PRIMARY KEY (id);


--
-- Name: assessment_submissions assessment_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.assessment_submissions
    ADD CONSTRAINT assessment_submissions_pkey PRIMARY KEY (id);


--
-- Name: assessments assessments_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT assessments_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: cards cards_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT cards_pkey PRIMARY KEY (id);


--
-- Name: coach_profiles coach_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.coach_profiles
    ADD CONSTRAINT coach_profiles_pkey PRIMARY KEY (id);


--
-- Name: collections collections_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT collections_pkey PRIMARY KEY (id);


--
-- Name: concept_cards concept_cards_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_cards
    ADD CONSTRAINT concept_cards_pkey PRIMARY KEY (id);


--
-- Name: concept_documents concept_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_documents
    ADD CONSTRAINT concept_documents_pkey PRIMARY KEY (id);


--
-- Name: concept_edges concept_edges_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_edges
    ADD CONSTRAINT concept_edges_pkey PRIMARY KEY (id);


--
-- Name: concepts concepts_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concepts
    ADD CONSTRAINT concepts_pkey PRIMARY KEY (id);


--
-- Name: consents consents_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.consents
    ADD CONSTRAINT consents_pkey PRIMARY KEY (id);


--
-- Name: daily_plan_items daily_plan_items_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.daily_plan_items
    ADD CONSTRAINT daily_plan_items_pkey PRIMARY KEY (id);


--
-- Name: daily_plans daily_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT daily_plans_pkey PRIMARY KEY (id);


--
-- Name: decks decks_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.decks
    ADD CONSTRAINT decks_pkey PRIMARY KEY (id);


--
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_verification_tokens email_verification_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT email_verification_tokens_pkey PRIMARY KEY (id);


--
-- Name: exams exams_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT exams_pkey PRIMARY KEY (id);


--
-- Name: exercise_attempts exercise_attempts_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.exercise_attempts
    ADD CONSTRAINT exercise_attempts_pkey PRIMARY KEY (id);


--
-- Name: goals goals_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT goals_pkey PRIMARY KEY (id);


--
-- Name: group_members group_members_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT group_members_pkey PRIMARY KEY (id);


--
-- Name: homework homework_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.homework
    ADD CONSTRAINT homework_pkey PRIMARY KEY (id);


--
-- Name: incidents incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.incidents
    ADD CONSTRAINT incidents_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: language_profiles language_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.language_profiles
    ADD CONSTRAINT language_profiles_pkey PRIMARY KEY (id);


--
-- Name: learning_dna learning_dna_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.learning_dna
    ADD CONSTRAINT learning_dna_pkey PRIMARY KEY (id);


--
-- Name: learning_predictions learning_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.learning_predictions
    ADD CONSTRAINT learning_predictions_pkey PRIMARY KEY (id);


--
-- Name: lessons lessons_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT lessons_pkey PRIMARY KEY (id);


--
-- Name: memberships memberships_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT memberships_pkey PRIMARY KEY (id);


--
-- Name: mentor_guidance mentor_guidance_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.mentor_guidance
    ADD CONSTRAINT mentor_guidance_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: org_groups org_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.org_groups
    ADD CONSTRAINT org_groups_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: reading_exercises reading_exercises_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.reading_exercises
    ADD CONSTRAINT reading_exercises_pkey PRIMARY KEY (id);


--
-- Name: recommendations recommendations_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT recommendations_pkey PRIMARY KEY (id);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: review_logs review_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.review_logs
    ADD CONSTRAINT review_logs_pkey PRIMARY KEY (id);


--
-- Name: reviewables reviewables_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.reviewables
    ADD CONSTRAINT reviewables_pkey PRIMARY KEY (id);


--
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- Name: study_resources study_resources_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.study_resources
    ADD CONSTRAINT study_resources_pkey PRIMARY KEY (id);


--
-- Name: study_sessions study_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.study_sessions
    ADD CONSTRAINT study_sessions_pkey PRIMARY KEY (id);


--
-- Name: subscriptions subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT subscriptions_pkey PRIMARY KEY (id);


--
-- Name: success_predictions success_predictions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.success_predictions
    ADD CONSTRAINT success_predictions_pkey PRIMARY KEY (id);


--
-- Name: tutor_messages tutor_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.tutor_messages
    ADD CONSTRAINT tutor_messages_pkey PRIMARY KEY (id);


--
-- Name: tutor_sessions tutor_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.tutor_sessions
    ADD CONSTRAINT tutor_sessions_pkey PRIMARY KEY (id);


--
-- Name: usage_counters usage_counters_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.usage_counters
    ADD CONSTRAINT usage_counters_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webhook_events webhook_events_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.webhook_events
    ADD CONSTRAINT webhook_events_pkey PRIMARY KEY (id);


--
-- Name: writing_submissions writing_submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.writing_submissions
    ADD CONSTRAINT writing_submissions_pkey PRIMARY KEY (id);


--
-- Name: achievements_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "achievements_userId_idx" ON public.achievements USING btree ("userId");


--
-- Name: achievements_userId_kind_threshold_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "achievements_userId_kind_threshold_key" ON public.achievements USING btree ("userId", kind, threshold);


--
-- Name: ai_initiatives_userId_status_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "ai_initiatives_userId_status_idx" ON public.ai_initiatives USING btree ("userId", status);


--
-- Name: assessment_submissions_assessmentId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "assessment_submissions_assessmentId_idx" ON public.assessment_submissions USING btree ("assessmentId");


--
-- Name: assessments_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "assessments_userId_createdAt_idx" ON public.assessments USING btree ("userId", "createdAt");


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: calendar_events_userId_date_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "calendar_events_userId_date_idx" ON public.calendar_events USING btree ("userId", date);


--
-- Name: cards_deckId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "cards_deckId_idx" ON public.cards USING btree ("deckId");


--
-- Name: cards_userId_due_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "cards_userId_due_idx" ON public.cards USING btree ("userId", due);


--
-- Name: coach_profiles_userId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "coach_profiles_userId_key" ON public.coach_profiles USING btree ("userId");


--
-- Name: collections_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "collections_userId_idx" ON public.collections USING btree ("userId");


--
-- Name: concept_cards_cardId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "concept_cards_cardId_idx" ON public.concept_cards USING btree ("cardId");


--
-- Name: concept_cards_conceptId_cardId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "concept_cards_conceptId_cardId_key" ON public.concept_cards USING btree ("conceptId", "cardId");


--
-- Name: concept_documents_conceptId_documentId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "concept_documents_conceptId_documentId_key" ON public.concept_documents USING btree ("conceptId", "documentId");


--
-- Name: concept_documents_documentId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "concept_documents_documentId_idx" ON public.concept_documents USING btree ("documentId");


--
-- Name: concept_edges_sourceId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "concept_edges_sourceId_idx" ON public.concept_edges USING btree ("sourceId");


--
-- Name: concept_edges_sourceId_targetId_relation_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "concept_edges_sourceId_targetId_relation_key" ON public.concept_edges USING btree ("sourceId", "targetId", relation);


--
-- Name: concept_edges_targetId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "concept_edges_targetId_idx" ON public.concept_edges USING btree ("targetId");


--
-- Name: concept_edges_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "concept_edges_userId_idx" ON public.concept_edges USING btree ("userId");


--
-- Name: concepts_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "concepts_userId_idx" ON public.concepts USING btree ("userId");


--
-- Name: concepts_userId_normalizedName_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "concepts_userId_normalizedName_key" ON public.concepts USING btree ("userId", "normalizedName");


--
-- Name: consents_userId_key_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "consents_userId_key_key" ON public.consents USING btree ("userId", key);


--
-- Name: daily_plan_items_planId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "daily_plan_items_planId_idx" ON public.daily_plan_items USING btree ("planId");


--
-- Name: daily_plans_userId_date_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "daily_plans_userId_date_key" ON public.daily_plans USING btree ("userId", date);


--
-- Name: daily_plans_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "daily_plans_userId_idx" ON public.daily_plans USING btree ("userId");


--
-- Name: decks_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "decks_userId_idx" ON public.decks USING btree ("userId");


--
-- Name: document_chunks_documentId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "document_chunks_documentId_idx" ON public.document_chunks USING btree ("documentId");


--
-- Name: document_chunks_vectorId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "document_chunks_vectorId_key" ON public.document_chunks USING btree ("vectorId");


--
-- Name: documents_collectionId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "documents_collectionId_idx" ON public.documents USING btree ("collectionId");


--
-- Name: documents_userId_deletedAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "documents_userId_deletedAt_idx" ON public.documents USING btree ("userId", "deletedAt");


--
-- Name: documents_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "documents_userId_idx" ON public.documents USING btree ("userId");


--
-- Name: email_verification_tokens_tokenHash_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "email_verification_tokens_tokenHash_key" ON public.email_verification_tokens USING btree ("tokenHash");


--
-- Name: email_verification_tokens_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "email_verification_tokens_userId_idx" ON public.email_verification_tokens USING btree ("userId");


--
-- Name: exams_userId_date_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "exams_userId_date_idx" ON public.exams USING btree ("userId", date);


--
-- Name: exercise_attempts_lessonId_exerciseIndex_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "exercise_attempts_lessonId_exerciseIndex_idx" ON public.exercise_attempts USING btree ("lessonId", "exerciseIndex");


--
-- Name: exercise_attempts_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "exercise_attempts_userId_createdAt_idx" ON public.exercise_attempts USING btree ("userId", "createdAt");


--
-- Name: exercise_attempts_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "exercise_attempts_userId_idx" ON public.exercise_attempts USING btree ("userId");


--
-- Name: goals_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "goals_userId_idx" ON public.goals USING btree ("userId");


--
-- Name: group_members_groupId_userId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "group_members_groupId_userId_key" ON public.group_members USING btree ("groupId", "userId");


--
-- Name: group_members_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "group_members_userId_idx" ON public.group_members USING btree ("userId");


--
-- Name: homework_lessonId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "homework_lessonId_key" ON public.homework USING btree ("lessonId");


--
-- Name: homework_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "homework_userId_idx" ON public.homework USING btree ("userId");


--
-- Name: incidents_status_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "incidents_status_createdAt_idx" ON public.incidents USING btree (status, "createdAt");


--
-- Name: invoices_number_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX invoices_number_key ON public.invoices USING btree (number);


--
-- Name: invoices_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "invoices_userId_createdAt_idx" ON public.invoices USING btree ("userId", "createdAt");


--
-- Name: language_profiles_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "language_profiles_userId_idx" ON public.language_profiles USING btree ("userId");


--
-- Name: language_profiles_userId_normalizedLanguage_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "language_profiles_userId_normalizedLanguage_key" ON public.language_profiles USING btree ("userId", "normalizedLanguage");


--
-- Name: learning_dna_userId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "learning_dna_userId_key" ON public.learning_dna USING btree ("userId");


--
-- Name: learning_predictions_userId_kind_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "learning_predictions_userId_kind_key" ON public.learning_predictions USING btree ("userId", kind);


--
-- Name: lessons_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "lessons_userId_idx" ON public.lessons USING btree ("userId");


--
-- Name: memberships_organizationId_userId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "memberships_organizationId_userId_key" ON public.memberships USING btree ("organizationId", "userId");


--
-- Name: memberships_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "memberships_userId_idx" ON public.memberships USING btree ("userId");


--
-- Name: mentor_guidance_userId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "mentor_guidance_userId_key" ON public.mentor_guidance USING btree ("userId");


--
-- Name: notifications_userId_date_slot_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "notifications_userId_date_slot_key" ON public.notifications USING btree ("userId", date, slot);


--
-- Name: notifications_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "notifications_userId_idx" ON public.notifications USING btree ("userId");


--
-- Name: org_groups_organizationId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "org_groups_organizationId_idx" ON public.org_groups USING btree ("organizationId");


--
-- Name: payments_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "payments_userId_createdAt_idx" ON public.payments USING btree ("userId", "createdAt");


--
-- Name: plans_slug_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX plans_slug_key ON public.plans USING btree (slug);


--
-- Name: profiles_userId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "profiles_userId_key" ON public.profiles USING btree ("userId");


--
-- Name: reading_exercises_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "reading_exercises_userId_createdAt_idx" ON public.reading_exercises USING btree ("userId", "createdAt");


--
-- Name: recommendations_userId_status_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "recommendations_userId_status_idx" ON public.recommendations USING btree ("userId", status);


--
-- Name: recovery_codes_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "recovery_codes_userId_idx" ON public.recovery_codes USING btree ("userId");


--
-- Name: reports_status_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "reports_status_createdAt_idx" ON public.reports USING btree (status, "createdAt");


--
-- Name: review_logs_cardId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "review_logs_cardId_idx" ON public.review_logs USING btree ("cardId");


--
-- Name: review_logs_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "review_logs_userId_idx" ON public.review_logs USING btree ("userId");


--
-- Name: reviewables_userId_due_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "reviewables_userId_due_idx" ON public.reviewables USING btree ("userId", due);


--
-- Name: reviewables_userId_kind_refId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "reviewables_userId_kind_refId_key" ON public.reviewables USING btree ("userId", kind, "refId");


--
-- Name: sessions_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "sessions_userId_idx" ON public.sessions USING btree ("userId");


--
-- Name: study_resources_documentId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "study_resources_documentId_idx" ON public.study_resources USING btree ("documentId");


--
-- Name: study_resources_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "study_resources_userId_idx" ON public.study_resources USING btree ("userId");


--
-- Name: study_sessions_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "study_sessions_userId_idx" ON public.study_sessions USING btree ("userId");


--
-- Name: study_sessions_userId_status_completedAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "study_sessions_userId_status_completedAt_idx" ON public.study_sessions USING btree ("userId", status, "completedAt");


--
-- Name: subscriptions_planId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "subscriptions_planId_idx" ON public.subscriptions USING btree ("planId");


--
-- Name: subscriptions_userId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "subscriptions_userId_key" ON public.subscriptions USING btree ("userId");


--
-- Name: success_predictions_examId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "success_predictions_examId_key" ON public.success_predictions USING btree ("examId");


--
-- Name: tutor_messages_sessionId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "tutor_messages_sessionId_idx" ON public.tutor_messages USING btree ("sessionId");


--
-- Name: tutor_sessions_userId_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "tutor_sessions_userId_idx" ON public.tutor_sessions USING btree ("userId");


--
-- Name: usage_counters_userId_metric_period_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "usage_counters_userId_metric_period_key" ON public.usage_counters USING btree ("userId", metric, period);


--
-- Name: users_email_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX users_email_key ON public.users USING btree (email);


--
-- Name: webhook_events_provider_eventId_key; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE UNIQUE INDEX "webhook_events_provider_eventId_key" ON public.webhook_events USING btree (provider, "eventId");


--
-- Name: writing_submissions_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: secondbrain
--

CREATE INDEX "writing_submissions_userId_createdAt_idx" ON public.writing_submissions USING btree ("userId", "createdAt");


--
-- Name: achievements achievements_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.achievements
    ADD CONSTRAINT "achievements_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ai_initiatives ai_initiatives_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.ai_initiatives
    ADD CONSTRAINT "ai_initiatives_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessment_submissions assessment_submissions_assessmentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.assessment_submissions
    ADD CONSTRAINT "assessment_submissions_assessmentId_fkey" FOREIGN KEY ("assessmentId") REFERENCES public.assessments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessment_submissions assessment_submissions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.assessment_submissions
    ADD CONSTRAINT "assessment_submissions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: assessments assessments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.assessments
    ADD CONSTRAINT "assessments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: calendar_events calendar_events_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT "calendar_events_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cards cards_deckId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT "cards_deckId_fkey" FOREIGN KEY ("deckId") REFERENCES public.decks(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: cards cards_sourceDocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT "cards_sourceDocumentId_fkey" FOREIGN KEY ("sourceDocumentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cards cards_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.cards
    ADD CONSTRAINT "cards_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: coach_profiles coach_profiles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.coach_profiles
    ADD CONSTRAINT "coach_profiles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: collections collections_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.collections
    ADD CONSTRAINT "collections_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concept_cards concept_cards_cardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_cards
    ADD CONSTRAINT "concept_cards_cardId_fkey" FOREIGN KEY ("cardId") REFERENCES public.cards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concept_cards concept_cards_conceptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_cards
    ADD CONSTRAINT "concept_cards_conceptId_fkey" FOREIGN KEY ("conceptId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concept_documents concept_documents_conceptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_documents
    ADD CONSTRAINT "concept_documents_conceptId_fkey" FOREIGN KEY ("conceptId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concept_documents concept_documents_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_documents
    ADD CONSTRAINT "concept_documents_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concept_edges concept_edges_sourceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_edges
    ADD CONSTRAINT "concept_edges_sourceId_fkey" FOREIGN KEY ("sourceId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concept_edges concept_edges_targetId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_edges
    ADD CONSTRAINT "concept_edges_targetId_fkey" FOREIGN KEY ("targetId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concept_edges concept_edges_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concept_edges
    ADD CONSTRAINT "concept_edges_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: concepts concepts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.concepts
    ADD CONSTRAINT "concepts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: consents consents_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.consents
    ADD CONSTRAINT "consents_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_plan_items daily_plan_items_conceptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.daily_plan_items
    ADD CONSTRAINT "daily_plan_items_conceptId_fkey" FOREIGN KEY ("conceptId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: daily_plan_items daily_plan_items_deckId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.daily_plan_items
    ADD CONSTRAINT "daily_plan_items_deckId_fkey" FOREIGN KEY ("deckId") REFERENCES public.decks(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: daily_plan_items daily_plan_items_languageProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.daily_plan_items
    ADD CONSTRAINT "daily_plan_items_languageProfileId_fkey" FOREIGN KEY ("languageProfileId") REFERENCES public.language_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: daily_plan_items daily_plan_items_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.daily_plan_items
    ADD CONSTRAINT "daily_plan_items_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.daily_plans(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: daily_plans daily_plans_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.daily_plans
    ADD CONSTRAINT "daily_plans_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: decks decks_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.decks
    ADD CONSTRAINT "decks_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: document_chunks document_chunks_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT "document_chunks_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: documents documents_collectionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_collectionId_fkey" FOREIGN KEY ("collectionId") REFERENCES public.collections(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: documents documents_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT "documents_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: email_verification_tokens email_verification_tokens_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.email_verification_tokens
    ADD CONSTRAINT "email_verification_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exams exams_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.exams
    ADD CONSTRAINT "exams_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exercise_attempts exercise_attempts_conceptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.exercise_attempts
    ADD CONSTRAINT "exercise_attempts_conceptId_fkey" FOREIGN KEY ("conceptId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: exercise_attempts exercise_attempts_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.exercise_attempts
    ADD CONSTRAINT "exercise_attempts_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public.lessons(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: exercise_attempts exercise_attempts_rootCauseConceptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.exercise_attempts
    ADD CONSTRAINT "exercise_attempts_rootCauseConceptId_fkey" FOREIGN KEY ("rootCauseConceptId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: exercise_attempts exercise_attempts_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.exercise_attempts
    ADD CONSTRAINT "exercise_attempts_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: goals goals_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.goals
    ADD CONSTRAINT "goals_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_members group_members_groupId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT "group_members_groupId_fkey" FOREIGN KEY ("groupId") REFERENCES public.org_groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: group_members group_members_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.group_members
    ADD CONSTRAINT "group_members_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: homework homework_lessonId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.homework
    ADD CONSTRAINT "homework_lessonId_fkey" FOREIGN KEY ("lessonId") REFERENCES public.lessons(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: homework homework_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.homework
    ADD CONSTRAINT "homework_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: invoices invoices_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT "invoices_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: language_profiles language_profiles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.language_profiles
    ADD CONSTRAINT "language_profiles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: language_profiles language_profiles_vocabDeckId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.language_profiles
    ADD CONSTRAINT "language_profiles_vocabDeckId_fkey" FOREIGN KEY ("vocabDeckId") REFERENCES public.decks(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: learning_dna learning_dna_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.learning_dna
    ADD CONSTRAINT "learning_dna_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: learning_predictions learning_predictions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.learning_predictions
    ADD CONSTRAINT "learning_predictions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: lessons lessons_conceptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT "lessons_conceptId_fkey" FOREIGN KEY ("conceptId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lessons lessons_languageProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT "lessons_languageProfileId_fkey" FOREIGN KEY ("languageProfileId") REFERENCES public.language_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lessons lessons_sourceDocumentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT "lessons_sourceDocumentId_fkey" FOREIGN KEY ("sourceDocumentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lessons lessons_tutorSessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT "lessons_tutorSessionId_fkey" FOREIGN KEY ("tutorSessionId") REFERENCES public.tutor_sessions(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: lessons lessons_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.lessons
    ADD CONSTRAINT "lessons_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: memberships memberships_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT "memberships_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: memberships memberships_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.memberships
    ADD CONSTRAINT "memberships_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: mentor_guidance mentor_guidance_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.mentor_guidance
    ADD CONSTRAINT "mentor_guidance_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: org_groups org_groups_organizationId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.org_groups
    ADD CONSTRAINT "org_groups_organizationId_fkey" FOREIGN KEY ("organizationId") REFERENCES public.organizations(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: payments payments_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT "payments_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: profiles profiles_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT "profiles_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reading_exercises reading_exercises_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.reading_exercises
    ADD CONSTRAINT "reading_exercises_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recommendations recommendations_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.recommendations
    ADD CONSTRAINT "recommendations_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: recovery_codes recovery_codes_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT "recovery_codes_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: review_logs review_logs_cardId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.review_logs
    ADD CONSTRAINT "review_logs_cardId_fkey" FOREIGN KEY ("cardId") REFERENCES public.cards(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: reviewables reviewables_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.reviewables
    ADD CONSTRAINT "reviewables_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sessions sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT "sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: study_resources study_resources_documentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.study_resources
    ADD CONSTRAINT "study_resources_documentId_fkey" FOREIGN KEY ("documentId") REFERENCES public.documents(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: study_resources study_resources_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.study_resources
    ADD CONSTRAINT "study_resources_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: study_sessions study_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.study_sessions
    ADD CONSTRAINT "study_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: subscriptions subscriptions_planId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_planId_fkey" FOREIGN KEY ("planId") REFERENCES public.plans(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: subscriptions subscriptions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.subscriptions
    ADD CONSTRAINT "subscriptions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: success_predictions success_predictions_examId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.success_predictions
    ADD CONSTRAINT "success_predictions_examId_fkey" FOREIGN KEY ("examId") REFERENCES public.exams(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: success_predictions success_predictions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.success_predictions
    ADD CONSTRAINT "success_predictions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tutor_messages tutor_messages_sessionId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.tutor_messages
    ADD CONSTRAINT "tutor_messages_sessionId_fkey" FOREIGN KEY ("sessionId") REFERENCES public.tutor_sessions(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: tutor_sessions tutor_sessions_focusConceptId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.tutor_sessions
    ADD CONSTRAINT "tutor_sessions_focusConceptId_fkey" FOREIGN KEY ("focusConceptId") REFERENCES public.concepts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tutor_sessions tutor_sessions_languageProfileId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.tutor_sessions
    ADD CONSTRAINT "tutor_sessions_languageProfileId_fkey" FOREIGN KEY ("languageProfileId") REFERENCES public.language_profiles(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: tutor_sessions tutor_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.tutor_sessions
    ADD CONSTRAINT "tutor_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usage_counters usage_counters_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.usage_counters
    ADD CONSTRAINT "usage_counters_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: writing_submissions writing_submissions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: secondbrain
--

ALTER TABLE ONLY public.writing_submissions
    ADD CONSTRAINT "writing_submissions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict fKjJGxwat28OynfjAtJYYcEgCbcCWDLtF3OHKXtw03IiemJ5FGRa5fRLaifyalU

